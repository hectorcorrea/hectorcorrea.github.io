This example shows how to create an Excel Pivot Table
for data in SQL Server's Northwind database using VB.NET.

To run example start with frmDemo.

For more information visit: http://www.hectorcorrea.com

Sincerely,
Hector correa
hector@hectorcorrea.com
Jan/2004