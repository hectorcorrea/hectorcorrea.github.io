' Author: hector@hectorcorrea.com 
'
' This class takes an input file (SourceField) and creates an Excel Pivot 
' table. By default this class assumes that the file is a text file and 
' uses the Jet OLE-DB provider to read it. 
'
' You can use other OLE-DB and ODBC providers to read the data by configuring
' properties ConnType and ConnString.
'
' Although you can also use ODBC providers to read the data, I do not
' recommend it since Excel will prompt you to install an additional
' component in order to read data using ODBC. 
'
' See http://www.utmag.com/June2002/Page13.asp if you want more 
' information about Excel Pivot Tables in general.
'
' Sample of usage (assuming a file c:\sampledata.txt exists)
'
'       Dim p As New PivotTable
'       p.ConnString = p.DefaultConnStringText
'       p.SourceFile = "sampledata.txt"
'       p.Create()
'       'p.SetField( "lastname", "row" )
'       'p.SetField( "linetotal", "data" )
'
Option Strict On
Option Explicit On 

Imports System.IO

Public Class PivotTable

    Const DefaultProviderType As String = "OLEDB"
    Const DefaultConnStringText As String = "Provider=Microsoft.Jet.OLEDB.4.0;" & _
            "Data Source=c:\;" & _
            "Extended Properties=""text;HDR=Yes;FMT=Delimited"""

    Public ShowExcel As Boolean = True
    Public ConnType As String = DefaultProviderType
    Public ConnString As String = DefaultConnStringText
    Public SourceFile As String = "SampleData.txt"
    Public SourceXLT As String
    Public TargetXLS As String
    Public TargetSheet As String = "Sheet1"
    Public TargetRange As String = "A5"

    Private ExcelApp As Excel.ApplicationClass
    Private PivotCache As Excel.PivotCache
    Private PivotTable As Excel.PivotTable


    Public Sub Create()

        Me.ExcelApp = New Excel.ApplicationClass
        Me.ExcelApp.Visible = ShowExcel

        Dim Workbook As Excel.Workbook
        If Me.SourceXLT Is Nothing Then
            Workbook = Me.ExcelApp.Workbooks.Add()
        Else
            Workbook = Me.ExcelApp.Workbooks.Open(Me.SourceXLT)
        End If

        Dim Worksheet As Excel.Worksheet
        Worksheet = CType(Workbook.Sheets.Item(Me.TargetSheet), Excel.Worksheet)

        Me.PivotCache = Workbook.PivotCaches.Add(Excel.XlPivotTableSourceType.xlExternal)
        Me.PivotCache.Connection = ConnType + ";" + Me.ConnString
        Me.PivotCache.CommandType = Excel.XlCmdType.xlCmdSql
        Me.PivotCache.CommandText = "SELECT * FROM " + Me.SourceFile

        Dim oTargetRange As Excel.Range
        oTargetRange = Worksheet.Range(Me.TargetRange)
        PivotTable = PivotCache.CreatePivotTable(oTargetRange, "PivotTable")

    End Sub

    Public Sub SetField(ByVal FieldName As String, ByVal Orientation As String)

        Dim ActualOrientation As Excel.XlPivotFieldOrientation
        Select Case Orientation.ToLower()
            Case "row"
                ActualOrientation = Excel.XlPivotFieldOrientation.xlRowField
            Case "column"
                ActualOrientation = Excel.XlPivotFieldOrientation.xlColumnField
            Case "data"
                ActualOrientation = Excel.XlPivotFieldOrientation.xlDataField
            Case "page"
                ActualOrientation = Excel.XlPivotFieldOrientation.xlPageField
            Case Else
                Throw New Exception("Error in SetField: Invalid Orientation received")
        End Select

        Dim PivotField As Excel.PivotField
        PivotField = CType(Me.PivotTable.PivotFields(FieldName), Excel.PivotField)
        PivotField.Orientation = ActualOrientation

    End Sub

    Public Sub Save()
        If File.Exists(Me.TargetXLS) Then
            File.Delete(Me.TargetXLS)
        End If
        Me.ExcelApp.Workbooks(1).SaveAs(Me.TargetXLS)
    End Sub

End Class
