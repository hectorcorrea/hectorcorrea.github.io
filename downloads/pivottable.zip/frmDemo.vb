Option Strict Off

Imports System.Data.OleDb

Public Class frmDemo
    Inherits System.Windows.Forms.Form

    Dim DataPath As String
    Dim TextFile As String

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents DataGrid1 As System.Windows.Forms.DataGrid
    Friend WithEvents cmdLoad As System.Windows.Forms.Button
    Friend WithEvents cmdPivotTable As System.Windows.Forms.Button
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.cmdLoad = New System.Windows.Forms.Button
        Me.DataGrid1 = New System.Windows.Forms.DataGrid
        Me.cmdPivotTable = New System.Windows.Forms.Button
        Me.cmdClose = New System.Windows.Forms.Button
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdLoad
        '
        Me.cmdLoad.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdLoad.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdLoad.Location = New System.Drawing.Point(8, 296)
        Me.cmdLoad.Name = "cmdLoad"
        Me.cmdLoad.TabIndex = 0
        Me.cmdLoad.Text = "Load Data"
        '
        'DataGrid1
        '
        Me.DataGrid1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGrid1.DataMember = ""
        Me.DataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.DataGrid1.Location = New System.Drawing.Point(8, 8)
        Me.DataGrid1.Name = "DataGrid1"
        Me.DataGrid1.Size = New System.Drawing.Size(360, 280)
        Me.DataGrid1.TabIndex = 1
        '
        'cmdPivotTable
        '
        Me.cmdPivotTable.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.cmdPivotTable.Location = New System.Drawing.Point(96, 296)
        Me.cmdPivotTable.Name = "cmdPivotTable"
        Me.cmdPivotTable.TabIndex = 2
        Me.cmdPivotTable.Text = "Pivot Table"
        '
        'cmdClose
        '
        Me.cmdClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdClose.Location = New System.Drawing.Point(296, 296)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.TabIndex = 3
        Me.cmdClose.Text = "Close"
        '
        'frmDemo
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.cmdClose
        Me.ClientSize = New System.Drawing.Size(384, 326)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.cmdPivotTable)
        Me.Controls.Add(Me.DataGrid1)
        Me.Controls.Add(Me.cmdLoad)
        Me.Name = "frmDemo"
        Me.Text = "Pivot Table Demo"
        CType(Me.DataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Protected Overrides Sub OnLoad(ByVal e As System.EventArgs)
        Me.DataPath = Application.StartupPath + "\"
        Me.TextFile = "SampleData.txt"
    End Sub

    Private Sub cmdLoad_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdLoad.Click

        ' Load the data and show it in the grid. 
        Dim ds As DataSet = Me.GetData()

        Me.DataGrid1.DataMember = "SampleData"
        Me.DataGrid1.DataSource = ds

    End Sub

    Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Me.Close()
    End Sub

    Private Sub cmdPivotTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPivotTable.Click

        ' Get data from database
        Dim ds As DataSet
        ds = Me.GetData()

        ' Show it in a grid
        Me.DataGrid1.DataMember = "SampleData"
        Me.DataGrid1.DataSource = ds

        ' Save data as text file
        Me.DataSetToTextFile(ds, DataPath + TextFile)

        ' Create the pivot table from the text file
        Me.CreatePivotTable(DataPath, TextFile)

    End Sub

    Private Function GetData() As DataSet

        ' Connect to SQL's Northwind database.
        Dim conn As New SqlClient.SqlConnection
        conn.ConnectionString = "server=(local);database=northwind;trusted_connection=yes"
        conn.Open()

        ' Get the information that we want to 
        ' use for the Pivot Table.
        Dim sc As New SqlClient.SqlCommand
        sc.Connection = conn
        sc.CommandText = "SELECT Employees.LastName, " + _
                "Employees.FirstName, " + _
                "convert( varchar(10), Orders.OrderDate, 101 ) as 'Order  Date', " + _
                "Customers.CompanyName as 'Company Name', " + _
                "Customers.Region, " + _
                "Customers.Country, " + _
                "Products.ProductName as 'Product Name', " + _
                "[Order Details].UnitPrice * [Order Details].Quantity as 'Line Total' " + _
            "FROM Employees " + _
            "   INNER JOIN Orders ON Employees.EmployeeID = Orders.EmployeeID " + _
            "INNER JOIN Customers ON Orders.CustomerID = Customers.CustomerID " + _
            "INNER JOIN [Order Details] ON Orders.OrderID = [Order Details].OrderID " + _
            "INNER JOIN Products ON [Order Details].ProductID = Products.ProductID "

        Dim sa As New SqlClient.SqlDataAdapter(sc)
        Dim ds As New DataSet
        sa.Fill(ds, "SampleData")

        Return ds

    End Function

    Private Sub DataSetToTextFile(ByVal ds As DataSet, ByVal FileName As String)
        DataSetToTextFile(ds, FileName, ",")
    End Sub

    ' Converts a dataset to a text file.
    Private Sub DataSetToTextFile(ByVal ds As DataSet, ByVal FileName As String, ByVal Delimiter As String)

        Dim ColumnCount As Integer = ds.Tables(0).Columns.Count

        ' Create text file
        Dim sw As New System.IO.StreamWriter(FileName)

        ' Write header record
        Dim i As Integer
        For i = 0 To ColumnCount - 1
            sw.Write(ds.Tables(0).Columns(i).ColumnName)
            If i = ColumnCount - 1 Then
                sw.WriteLine()
            Else
                sw.Write(Delimiter)
            End If
        Next

        ' Write content
        Dim r As DataRow
        For Each r In ds.Tables(0).Rows

            For i = 0 To ColumnCount - 1
                sw.Write(r.Item(i))
                If i = ColumnCount - 1 Then
                    sw.WriteLine()
                Else
                    sw.Write(Delimiter)
                End If
            Next

        Next

        ' Done
        sw.Close()

    End Sub

    Private Sub CreatePivotTable(ByVal DataPath As String, ByVal TextFile As String)

        Dim p As New PivotTable
        p.ConnString = "Provider=Microsoft.Jet.OLEDB.4.0;" & _
                       "Data Source=" & DataPath & ";" & _
                        "Extended Properties=""text;HDR=Yes;FMT=Delimited"""

        p.SourceFile = TextFile
        p.SourceXLT = DataPath + "SampleTemplate.xlt"
        p.TargetXLS = DataPath + "SamplePivot.xls"
        p.Create()
        p.SetField("Country", "row")
        p.SetField("Line Total", "data")
        p.SetField("Product Name", "page")
        p.SetField("Lastname", "column")
        p.Save()

    End Sub

End Class

