﻿/*
 * Copyright 2008 - HectorCorrea.com
 */
namespace FlickrLib
{
    public class PhotoSetInfo
    {
        public string PhotoSetID { get; set; }
        public string Title { get; set; }

        public PhotoSetInfo(string photoSetID, string title)        
        {
            PhotoSetID = photoSetID;
            Title = title;
        }
    }
}
