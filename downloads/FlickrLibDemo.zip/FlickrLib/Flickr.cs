﻿/*
 * Copyright 2008 - HectorCorrea.com
 */
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Xml.Linq;

namespace FlickrLib
{
    /// <summary>
    /// This is a light weight class to communicate with Flick's API basic features.
    /// </summary>
    /// 
    /// <example>
    ///  
    /// // Instantiate the Flickr class
    /// Flickr flickr = new Flickr("YourApiKey", "YourUserId");
    /// 
    /// // Get a list of your photosets
    /// List<PhotoSetInfo> photosets = flickr.GetPhotoSets(); 
    /// 
    /// // Get a list of the photos inside a photoset
    /// List<PhotoInfo> photos = flickr.GetPhotosInSet(photosets[0].PhotoSetID);
    /// 
    /// // Get the complete URL for a particular photo's thumbnail 
    /// string photoUrl = Flickr.GetPhotoUrl(photos[0], PhotoSizeNum.Thumbnail);
    /// 
    /// </example>
    public class Flickr
    {
        private const string defaultUrl = "http://api.flickr.com/services/rest/";
        public string Url { get; set; }
        public string ApiKey { get; set; }
        public string UserId { get; set; }

        private Flickr() {} /* force use of public constructor with parameters */

        /// <summary>
        /// Creates an instance of the Flickr class. 
        /// </summary>
        /// <param name="url">Flickr's API URL</param>
        /// <param name="apiKey">Your API key with Flickr. 
        /// See Flick's API documentation at http://www.flickr.com/services/ if you 
        /// don't know what this is.</param>
        /// <param name="userId">Your Flick user ID.</param>
        public Flickr(string url, string apiKey, string userId)
        {
            Url = url;
            ApiKey = apiKey;
            UserId = userId;
        }

        /// <summary>
        /// Creates an instance of the Flickr class. 
        /// This method has the URL to Flick hardcoded to http://api.flickr.com/services/rest/
        /// </summary>
        /// <param name="apiKey">Your API key with Flickr. 
        /// See Flick's API documentation at http://www.flickr.com/services/ if you 
        /// don't know what this is.</param>
        /// <param name="userId">Your Flick user ID.</param>
        public Flickr(string apiKey, string userId) :
            this(Flickr.defaultUrl, apiKey, userId)
        {
        }

        /// <summary>
        /// Submits a request to a URL and reads the response to a string.
        /// </summary>
        /// <param name="requestUrl">The URL to submit.</param>
        /// <returns>The content of the response.</returns>
        private static string SubmitRequest(string requestUrl)
        {
            string textResponse = string.Empty;
            WebRequest request = WebRequest.Create(requestUrl);
            request.Proxy = null;
            using (WebResponse response = request.GetResponse())
            {
                using (Stream stream = response.GetResponseStream())
                {
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        textResponse = reader.ReadToEnd();
                    }
                }
            }
            return textResponse;
        }

        /// <summary>
        /// Fills the details about a picture. At this time the only value that
        /// it fills is the description. Typically you call GetPhotosInSet first
        /// and then this method to populate the description of an individual 
        /// picture. 
        /// </summary>
        /// <param name="photo">A PhotoInfo with information about the picture to fill.
        /// </param>
        public void FillPhotoDetails(ref PhotoInfo photo)
        {
            string getInfoMethod = "flickr.photos.getInfo";
            string url = string.Format("{0}?method={1}&api_key={2}&photo_id={3}&secret={4}",
                Url, getInfoMethod, ApiKey, photo.Id, photo.Secret);
            string response = Flickr.SubmitRequest(url);

            XElement responseXml = XElement.Parse(response);
            XElement photoElement = responseXml.Element("photo");
            if (photoElement != null)
            {
                XElement descriptionElement = photoElement.Element("description");
                if (descriptionElement != null)
                {
                    photo.Description = descriptionElement.Value;
                }
            }
        }

        /// <summary>
        /// Returns the URL for a particular picture. 
        /// Typically you call GetPhotosInSet first and then this method 
        /// to get the complete URL for a picture in the set in a 
        /// particular size.
        /// </summary>
        /// <param name="photo">Details of the photo</param>
        /// <param name="size">The size requested for the picture </param>
        /// <returns></returns>
        public static string GetPhotoUrl(PhotoInfo photo, PhotoSizeEnum size)
        {
            string baseUrl = string.Format("http://farm{0}.static.flickr.com", photo.Farm);

            string url = string.Format("{0}/{1}/{2}_{3}[SIZETOKEN].jpg",
                baseUrl, photo.Server, photo.Id, photo.Secret);

            string sizeStr = (size == PhotoSizeEnum.Thumbnail) ? "_m" : "";
            url = url.Replace("[SIZETOKEN]",sizeStr);

            return url;
        }

        /// <summary>
        /// Returns the list of photos in a set.
        /// </summary>
        /// <param name="photoSetID">ID of the set. Typically a value returned by GetPhotoSets</param>
        /// <returns></returns>
        public List<PhotoInfo> GetPhotosInSet(string photoSetID)
        {
            string getPhotosMethod = "flickr.photosets.getPhotos";
            string url = string.Format("{0}?method={1}&api_key={2}&photoset_id={3}",
                Url, getPhotosMethod, ApiKey, photoSetID);

            string response = Flickr.SubmitRequest(url);
            XElement responseXml = XElement.Parse(response);
            //XElement xml = XElement.Load(@"c:\Dev\FlickrViewer\photos.xml");

            IEnumerable<XElement> photosetXml = responseXml.Elements("photoset");
            IEnumerable<XElement> photosXml = photosetXml.Elements("photo");

            List<PhotoInfo> photos = (from p in photosXml
                                            select new PhotoInfo
                                            {
                                                Id = p.Attribute("id").Value,
                                                Secret = p.Attribute("secret").Value,
                                                Server = p.Attribute("server").Value,
                                                Farm = p.Attribute("farm").Value,
                                                Title = p.Attribute("title").Value,
                                                IsPrimary = (p.Attribute("isprimary").Value == "1")
                                            }).ToList();

            foreach (PhotoInfo photo in photos)
            {
                photo.Url = GetPhotoUrl(photo, PhotoSizeEnum.Normal);
                photo.UrlThumb = GetPhotoUrl(photo, PhotoSizeEnum.Thumbnail);
            }
            return photos;
        }

        /// <summary>
        /// Returns a list of photoset for the current user.
        /// </summary>
        public List<PhotoSetInfo> GetPhotoSets()
        {
            List<PhotoSetInfo> list = new List<PhotoSetInfo>();

            string getListMethod = "flickr.photosets.getList";
            string url = string.Format("{0}?method={1}&api_key={2}&user_id={3}",
                Url, getListMethod, ApiKey, UserId);

            string response = Flickr.SubmitRequest(url);
            XElement xml = XElement.Parse(response);
            //XElement xml = XElement.Load(@"c:\Dev\FlickrViewer\photosets.xml");

            IEnumerable<XElement> photosetsRoot = xml.Elements("photosets");
            foreach (XElement xmlPhotoSet in photosetsRoot.Elements("photoset"))
            {
                string photosetID = xmlPhotoSet.Attribute("id").Value;
                string title = xmlPhotoSet.Elements("title").First().Value;
                PhotoSetInfo photoset = new PhotoSetInfo(photosetID, title);
                list.Add(photoset);
            }
            return list;
        }

    }
}
