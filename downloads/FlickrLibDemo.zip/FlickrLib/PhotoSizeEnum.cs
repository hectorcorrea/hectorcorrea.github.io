﻿/*
 * Copyright 2008 - HectorCorrea.com
 */
namespace FlickrLib
{
    public enum PhotoSizeEnum
    {
        Thumbnail,
        Normal
    }
}
