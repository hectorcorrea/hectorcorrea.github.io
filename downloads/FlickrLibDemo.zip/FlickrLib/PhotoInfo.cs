﻿/*
 * Copyright 2008 - HectorCorrea.com
 */
namespace FlickrLib
{
    public class PhotoInfo
    {

        public string Id { get; set; }
        public string Server { get; set; }
        public string Secret { get; set; }
        public string Farm { get; set; }
        public string Title { get; set; }
        public bool IsPrimary { get; set; }
        public string Url { get; set; }
        public string UrlThumb{ get; set; }
        public string Description { get; set; }
    }

}
