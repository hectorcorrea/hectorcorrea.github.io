﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FlickrLib;
using System.Configuration;

namespace FlickrLibDemo
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadPhotoSets();
            }
            else
            {
                lblPhotosMsg.Text = "(your photos will show up here)";
            }
        }

        private Flickr ConnectToFlickr()
        {
            string apiKey = ConfigurationManager.AppSettings["ApiKey"].ToString();
            string userID = ConfigurationManager.AppSettings["UserID"].ToString();

            if (apiKey.ToLower().Contains("yourkeyhere"))
                throw new Exception("Make sure you update the web.config with your Flickr API key");

            if (userID.ToLower().Contains("youridhere"))
                throw new Exception("Make sure you update the web.config with your Flickr User ID");

            return new Flickr(apiKey, userID);
        }

        private void LoadPhotoSets()
        {
            Flickr flickr = ConnectToFlickr();
            List<PhotoSetInfo> photosets = flickr.GetPhotoSets();

            cboPhotoSets.DataSource = photosets;
            cboPhotoSets.DataTextField = "Title";
            cboPhotoSets.DataValueField = "PhotoSetID";
            cboPhotoSets.DataBind();

            LoadPhotos();
        }

        private void LoadPhotos()
        {
            Flickr flickr = ConnectToFlickr();
            List<PhotoInfo> photos = flickr.GetPhotosInSet(cboPhotoSets.SelectedValue);
            listPhotos.DataSource = photos;
            listPhotos.DataBind();
            lblPhotosMsg.Text = (photos.Count == 0) ? "No photos in this photoset" : "";
        }

        private void FillPhotoDetails(ref PhotoInfo photo)
        {
            if (photo.Description == null)
            {
                Flickr flickr = ConnectToFlickr();
                flickr.FillPhotoDetails(ref photo); // populates photo.Description 
            }
        }

        protected void cboPhotoSets_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadPhotos();
        }

        protected void listPhotos_ItemDataBound(object sender, System.Web.UI.WebControls.DataListItemEventArgs e)
        {
            //System.Web.UI.WebControls.Image image = (System.Web.UI.WebControls.Image)e.Item.FindControl("Image2");
            return;
        }

    }
}
