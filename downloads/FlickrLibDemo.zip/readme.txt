﻿-----------------------------------------------------------------------
Prerequisites:

* You need to have your own Flickr API key to be able to use this demo. 

  Set your API key and User ID in the web.app config under FlickrLibDemo.

  See http://www.flickr.com/services/api/ for more information about Flickr's API.

* Code was compiled with .NET 3.5 SP1



-----------------------------------------------------------------------
Contents

* FlickrLib: Code for the library to pull photos from Flickr
* FlickrLibDemo: A sample web page to show the usage of the class library



-----------------------------------------------------------------------
Known issues

* Description of the picture is not displayed on pop up window

* If you scroll down the page and pop up a picture the picture is still 
  opened at the top of the page and you might not see it unless you
  scroll up. Only happens if you scroll down to pick a picture below 
  initial visible area.

	
		
-----------------------------------------------------------------------
Questions, comments?

Feel free to contact me at http://hectorcorrea.com


