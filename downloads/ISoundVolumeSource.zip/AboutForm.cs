using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace ISoundVolume
{
	/// <summary>
	/// Summary description for AboutForm.
	/// </summary>
	public class AboutForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox txtInfo;
		private System.Windows.Forms.Button cmdOK;
		private System.Windows.Forms.LinkLabel linkMoreInfo;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public AboutForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}


		public AboutForm( string appName )
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			this.Text = appName;
		}


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtInfo = new System.Windows.Forms.TextBox();
			this.cmdOK = new System.Windows.Forms.Button();
			this.linkMoreInfo = new System.Windows.Forms.LinkLabel();
			this.SuspendLayout();
			// 
			// txtInfo
			// 
			this.txtInfo.Location = new System.Drawing.Point(8, 8);
			this.txtInfo.Multiline = true;
			this.txtInfo.Name = "txtInfo";
			this.txtInfo.ReadOnly = true;
			this.txtInfo.Size = new System.Drawing.Size(232, 48);
			this.txtInfo.TabIndex = 0;
			this.txtInfo.TabStop = false;
			this.txtInfo.Text = "";
			// 
			// cmdOK
			// 
			this.cmdOK.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.cmdOK.Location = new System.Drawing.Point(88, 96);
			this.cmdOK.Name = "cmdOK";
			this.cmdOK.TabIndex = 3;
			this.cmdOK.Text = "OK";
			this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
			// 
			// linkMoreInfo
			// 
			this.linkMoreInfo.Location = new System.Drawing.Point(144, 64);
			this.linkMoreInfo.Name = "linkMoreInfo";
			this.linkMoreInfo.Size = new System.Drawing.Size(96, 23);
			this.linkMoreInfo.TabIndex = 4;
			this.linkMoreInfo.TabStop = true;
			this.linkMoreInfo.Text = "More Information";
			this.linkMoreInfo.TextAlign = System.Drawing.ContentAlignment.TopRight;
			this.linkMoreInfo.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkMoreInfo_LinkClicked);
			// 
			// AboutForm
			// 
			this.AcceptButton = this.cmdOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.cmdOK;
			this.ClientSize = new System.Drawing.Size(250, 128);
			this.Controls.Add(this.linkMoreInfo);
			this.Controls.Add(this.cmdOK);
			this.Controls.Add(this.txtInfo);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "AboutForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "AboutForm";
			this.Load += new System.EventHandler(this.AboutForm_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void AboutForm_Load(object sender, System.EventArgs e)
		{
			this.txtInfo.Text = "A small application to control Apple's iTunes volume";		
		}

		private void cmdOK_Click(object sender, System.EventArgs e)
		{
			this.Dispose();
		}

		private void linkMoreInfo_LinkClicked(object sender, System.Windows.Forms.LinkLabelLinkClickedEventArgs e)
		{
			string url = "http://www.hectorcorrea.com/DotWiki.htm?Topic=ISoundVolume";
			System.Diagnostics.Process.Start(url);		
		}
	}
}
