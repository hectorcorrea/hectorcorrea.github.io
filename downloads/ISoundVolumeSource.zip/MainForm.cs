using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;

namespace ISoundVolume
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		const string WindowsTitle = "iSoundVolume";
		private iTunesLib.IiTunes iTunes;

		private Point m_pointClicked;
		private bool m_formDragging = false;
		private Button m_buttonClicked = null;

		private System.Windows.Forms.Button cmdPlay;
		private System.Windows.Forms.Button cmdPause;
		private System.Windows.Forms.Button cmdVolDown;
		private System.Windows.Forms.Button cmdVolUp;
		private System.Windows.Forms.NotifyIcon notifyIcon;
		private System.Windows.Forms.ContextMenu contextMenu;
		private System.Windows.Forms.MenuItem mnuAbout;
		private System.Windows.Forms.MenuItem mnuExit;
		private System.Windows.Forms.MenuItem mnuOpen;
		private System.Windows.Forms.Timer timer;
		private System.ComponentModel.IContainer components;

		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
			this.cmdPlay = new System.Windows.Forms.Button();
			this.cmdPause = new System.Windows.Forms.Button();
			this.cmdVolDown = new System.Windows.Forms.Button();
			this.cmdVolUp = new System.Windows.Forms.Button();
			this.notifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
			this.contextMenu = new System.Windows.Forms.ContextMenu();
			this.mnuAbout = new System.Windows.Forms.MenuItem();
			this.mnuOpen = new System.Windows.Forms.MenuItem();
			this.mnuExit = new System.Windows.Forms.MenuItem();
			this.timer = new System.Windows.Forms.Timer(this.components);
			this.SuspendLayout();
			// 
			// cmdPlay
			// 
			this.cmdPlay.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.cmdPlay.Image = ((System.Drawing.Image)(resources.GetObject("cmdPlay.Image")));
			this.cmdPlay.Location = new System.Drawing.Point(4, 2);
			this.cmdPlay.Name = "cmdPlay";
			this.cmdPlay.Size = new System.Drawing.Size(20, 20);
			this.cmdPlay.TabIndex = 0;
			this.cmdPlay.TabStop = false;
			this.cmdPlay.Click += new System.EventHandler(this.cmdPlay_Click);
			// 
			// cmdPause
			// 
			this.cmdPause.BackColor = System.Drawing.SystemColors.Control;
			this.cmdPause.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.cmdPause.Image = ((System.Drawing.Image)(resources.GetObject("cmdPause.Image")));
			this.cmdPause.Location = new System.Drawing.Point(22, 2);
			this.cmdPause.Name = "cmdPause";
			this.cmdPause.Size = new System.Drawing.Size(20, 20);
			this.cmdPause.TabIndex = 1;
			this.cmdPause.TabStop = false;
			this.cmdPause.Click += new System.EventHandler(this.cmdPause_Click);
			// 
			// cmdVolDown
			// 
			this.cmdVolDown.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.cmdVolDown.Image = ((System.Drawing.Image)(resources.GetObject("cmdVolDown.Image")));
			this.cmdVolDown.Location = new System.Drawing.Point(40, 2);
			this.cmdVolDown.Name = "cmdVolDown";
			this.cmdVolDown.Size = new System.Drawing.Size(20, 20);
			this.cmdVolDown.TabIndex = 2;
			this.cmdVolDown.TabStop = false;
			this.cmdVolDown.Click += new System.EventHandler(this.cmdVolDown_Click);
			this.cmdVolDown.MouseUp += new System.Windows.Forms.MouseEventHandler(this.cmdVolDown_MouseUp);
			this.cmdVolDown.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cmdVolDown_MouseDown);
			// 
			// cmdVolUp
			// 
			this.cmdVolUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.cmdVolUp.Image = ((System.Drawing.Image)(resources.GetObject("cmdVolUp.Image")));
			this.cmdVolUp.Location = new System.Drawing.Point(58, 2);
			this.cmdVolUp.Name = "cmdVolUp";
			this.cmdVolUp.Size = new System.Drawing.Size(20, 20);
			this.cmdVolUp.TabIndex = 3;
			this.cmdVolUp.TabStop = false;
			this.cmdVolUp.Click += new System.EventHandler(this.cmdVolUp_Click);
			this.cmdVolUp.MouseUp += new System.Windows.Forms.MouseEventHandler(this.cmdVolUp_MouseUp);
			this.cmdVolUp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cmdVolUp_MouseDown);
			// 
			// notifyIcon
			// 
			this.notifyIcon.ContextMenu = this.contextMenu;
			this.notifyIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon.Icon")));
			this.notifyIcon.Text = "notifyIcon1";
			this.notifyIcon.Visible = true;
			// 
			// contextMenu
			// 
			this.contextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						this.mnuAbout,
																						this.mnuOpen,
																						this.mnuExit});
			// 
			// mnuAbout
			// 
			this.mnuAbout.Index = 0;
			this.mnuAbout.Text = "About";
			this.mnuAbout.Click += new System.EventHandler(this.mnuAbout_Click);
			// 
			// mnuOpen
			// 
			this.mnuOpen.Index = 1;
			this.mnuOpen.Text = "Open";
			this.mnuOpen.Click += new System.EventHandler(this.mnuOpen_Click);
			// 
			// mnuExit
			// 
			this.mnuExit.Index = 2;
			this.mnuExit.Text = "Exit";
			this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
			// 
			// timer
			// 
			this.timer.Interval = 50;
			this.timer.Tick += new System.EventHandler(this.timer_Tick);
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(84, 24);
			this.ContextMenu = this.contextMenu;
			this.Controls.Add(this.cmdVolUp);
			this.Controls.Add(this.cmdVolDown);
			this.Controls.Add(this.cmdPause);
			this.Controls.Add(this.cmdPlay);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "MainForm";
			this.Opacity = 0.75;
			this.ShowInTaskbar = false;
			this.Text = "iTunes Volume Controller";
			this.TopMost = true;
			this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseDown);
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseUp);
			this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseMove);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			MainForm form = new MainForm();
			form.Visible = true;
			Application.Run();
		}

		private void MainForm_Load(object sender, System.EventArgs e)
		{
			LoadITunes();
			this.Width = 84;
			this.Height = 24;
		}

		private void LoadITunes()
		{
			iTunes = new iTunesLib.iTunesAppClass();
			notifyIcon.Text = WindowsTitle;
		}

		private void cmdPlay_Click(object sender, System.EventArgs e)
		{
			iTunes.Play();
		}

		private void cmdPause_Click(object sender, System.EventArgs e)
		{
			iTunes.Pause();
		}

		private void cmdVolDown_Click(object sender, System.EventArgs e)
		{
			VolumeDown();
		}

		private void cmdVolUp_Click(object sender, System.EventArgs e)
		{
			VolumeUp();
		}

		private void VolumeDown()
		{
			if (iTunes.SoundVolume > 0)
			{
				int currentVolume = iTunes.SoundVolume;
				for (int i = currentVolume - 1; i >= 0; i--)
				{
					iTunes.SoundVolume = i;
					if (iTunes.SoundVolume != currentVolume)
					{
						break;
					}
				}
			}
			else
			{
				QuickFlashButton(cmdVolDown);
			}
		}

		private void VolumeUp()
		{
			if (iTunes.SoundVolume < 100)
			{
				int currentVolume = iTunes.SoundVolume;
				for (int i = currentVolume + 1; i <= 100; i++)
				{
					iTunes.SoundVolume = i;
					if (iTunes.SoundVolume != currentVolume)
					{
						break;
					}
				}
			}
			else
			{
				QuickFlashButton(cmdVolUp);
			}
		}

		private void QuickFlashButton( Button button )
		{
			Color originalForeColor = button.ForeColor;
			button.ForeColor = Color.Red;
			button.Update();
			button.ForeColor = originalForeColor;
			System.Threading.Thread.Sleep(35);
			button.Update();
		}

		private void cmdClose_Click(object sender, System.EventArgs e)
		{
			this.Dispose();
		}

		private void MainForm_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			m_formDragging = true;
			m_pointClicked = new Point(e.X, e.Y);
		}

		private void MainForm_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			m_formDragging = false;
		}

		private void MainForm_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (m_formDragging)
			{
				Point moveToPoint = PointToScreen(new Point(e.X, e.Y));;
				moveToPoint.Offset(m_pointClicked.X * -1, 
					(m_pointClicked.Y + SystemInformation.BorderSize.Height) * -1);
				this.Location = moveToPoint;
			}
		}

		private void MakeVisible()
		{
			this.Visible = true;
			Color originalBackColor = this.BackColor;
			for( int i = 0; i < 5; i++)
			{
				this.BackColor = Color.Red;
				System.Threading.Thread.Sleep(100);
				this.Update();
				this.BackColor = originalBackColor;
				System.Threading.Thread.Sleep(35);
				this.Update();
			}
		}

		private void mnuExit_Click(object sender, System.EventArgs e)
		{
			notifyIcon.Visible = false;
			this.Close();
			Application.Exit();
		}

		private void mnuOpen_Click(object sender, System.EventArgs e)
		{
			MakeVisible();
		}

		private void mnuAbout_Click(object sender, System.EventArgs e)
		{
			AboutForm form = new AboutForm( WindowsTitle );
			form.ShowDialog();
		}

		private void cmdVolUp_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			m_buttonClicked = cmdVolUp;
			timer.Enabled = true;
		}

		private void cmdVolUp_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			m_buttonClicked = null;	
			timer.Enabled = false;
		}
		
		private void cmdVolDown_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			m_buttonClicked = cmdVolDown;
			timer.Enabled = true;
		}

		private void cmdVolDown_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			m_buttonClicked = null;	
			timer.Enabled = false;
		}

		private void timer_Tick(object sender, System.EventArgs e)
		{
			if(m_buttonClicked == cmdVolDown)
			{
				VolumeDown();
			}
			else if( m_buttonClicked == cmdVolUp)
			{
				VolumeUp();
			}
		}

	}
}
