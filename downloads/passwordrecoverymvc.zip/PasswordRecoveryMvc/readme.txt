﻿This code is the companion to the blog post "Password Recovery in an ASP.NET MVC Project" 
at http://www.hectorcorrea.com/Blog/Password-Recovery-in-an-ASP.NET-MVC-Project

The code in this project is a brand new ASP.NET MVC 2 Web Application updated to implement 
the password recovery feature missing from the default project.

Before you use this project you'll need to make a few changes in the web.config to point
to your own Membership database. Basically you need to update two settings in the web.config:

	* Under configuration/connectionStrings make sure the connection string for the ApplicationServices 
	points to your own database (the one with the aspnet_* tables.)
	
	* Under configuration/system.web/membership/providers make sure the ApplicationName indicated on the 
	AspNetSqlMembershipProvider matches your application name. 

The changes that I made to the code to support the password recovery feature are marked with 
"//Hector was here" in both the AccountController.cs and AccountModel.cs files. 

The LogOn.aspx view (under Views\Account) was also updated to have an option to trigger the 
password recovery process.

The Register.aspx view (unders Views\Account) was updated to allow the user to indicate a security
question/answer if the membership provider is configured to require them.

In the web.config notice also that the value of the enablePasswordReset under configuration/system.web/membership/providers
has been set to true. 

There are three new views to support the password recovery process (PasswordReset.aspx, 
PasswordResetFinal.aspx, and QuestionAndAnswer.aspx) and they are under Views\Account.

Most likely you want to e-mail your users their new password once the password has been reset.
The code in this project does NOT e-mail the user but rather just logs the new password to
a text file (see EmailNewPassword method inside the AccountModel). Addressing how to send 
e-mails from C# is outside of the scope of this project.

This project does not include instructions on how to configure the ASP.NET Membership provider.
This code picks up after you've got the membership provider working and want to add the password
recovery feature.

To see the password recovery feature in action:

	* Update the web.config as described above
	* Run the project
	* Click the login to your account link
	* Create a new user 
	* Log out
	* Click the login to your account again
	* Click on the password recovery link in the login page and follow the instructions on the screen.

If you have any questions feel free to reach me at hector@hectorcorrea.com

