﻿namespace mynamespace
{
    public class myclass
    {
        public static string mymethod() 
        { 
            return "hello world"; 
        }
    }
}