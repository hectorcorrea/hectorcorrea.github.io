Public Class NewTopic
    Inherits System.Web.UI.Page
    Protected WithEvents txtTopicName As System.Web.UI.WebControls.TextBox
    Protected WithEvents cmdAddIt As System.Web.UI.WebControls.Button
    Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub cmdAddIt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAddIt.Click
        Me.AddTopic()
    End Sub

    Private Sub AddTopic()
        Dim TopicName As String = Me.txtTopicName.Text
        Select Case TopicName.Length
            Case Is = 0
                Me.lblMessage.Text = "Please indicate the name of the topic to add."
            Case Is > 50
                Me.lblMessage.Text = "Topic Name cannot be longer than 50 characters."
            Case Else
                If Wiki.IsCamelCaseWord(TopicName) Then
                    Dim URL As String = "Default.aspx?topic=" + TopicName + "&mode=Edit"
                    Me.Response.Redirect(URL)
                Else
                    Me.lblMessage.Text = "Cannot add topic Name [" + TopicName + "] " + _
                                        "since it is not in CamelCase notation."
                End If
        End Select
    End Sub

End Class
