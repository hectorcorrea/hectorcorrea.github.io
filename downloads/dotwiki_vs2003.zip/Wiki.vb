' description:  Wiki Engine class for DotWiki project. This
'               is the class that parses wiki web pages.
' author:       Sept/2002 - hcorrea@visionds.com 
'
Imports Microsoft.VisualBasic
Imports System.Text.RegularExpressions

Public Class Wiki

    ' Regular Expressions references:
    '   http://www.fawcette.com/vsm/2003_01/magazine/features/balena/default.asp
    '   http://sitescooper.org/tao_regexps.html
    '
    ' CamelCaseRegExp explanation (sort of):
    '   [A-Z]\w+            Must begin with an upper case character 
    '                       and zero or more words.
    '   [A-Z][a-z,0-9]\w+   Must be followed by an upper case character 
    '                       plus lower case characters or digirs, and 
    '                       zero or more words.
    '   (?=\b)              Ends with a word boundary.
    '   (?![\\]|[/]|[\.]\w) Cannot include a "\" or "/" (like in paths), 
    '                       or a dot followed by characters (like file 
    '                       extensions.)
    '
    'Const CamelCaseRegExp As String = "[A-Z]\w+[A-Z][a-z,0-9]\w+\s"
    'Const CamelCaseRegExp As String = "[A-Z]\w+[A-Z][a-z,0-9]\w+(?=\s|\W)(?![\\]|[/]|[\.])"
    'Const ConstCamelCaseRegExp As String = "[A-Z]\w+[A-Z][a-z,0-9]\w+(?=\b)(?![\\]|[/]|[\.]\w)"

    Const ConstCamelCaseRegExp As String = "[A-Z]\w*[a-z]\w*[A-Z]\w*(?=\b)(?![\\]|[/]|[\.]\w)"  ' Special thanks to Glen Taylor for this version.
    Const CamelCaseOptions As RegexOptions = RegexOptions.Compiled Or RegexOptions.Multiline


    ' Jan/2003 - hcorrea@visionds.com
    ' Parses an HTML text and creates formated version ready for display.
    '
    ' This version uses regular expressions instead of a customized parser.
    ' I still need to research how to optimize the use of the parser. Current
    ' version is making too many calls to regular expression Replace method.
    ' Need to benchmark it before modifying it, though.
    Public Shared Function MakeDisplayableText( _
                            ByRef CamelCaseRegExp As String, _
                            ByRef WebPage As String, _
                            ByRef TextToProcess As String, _
                            ByRef TargetFrame As String) As String

        Dim re As New Regex(CamelCaseRegExp, CamelCaseOptions)
        Dim DisplayableText As String

        ' Prevent existing HREF references from being processed.
        DisplayableText = re.Replace(TextToProcess, "<a href=http://[^\s]+", AddressOf MaskHttpReference)
        DisplayableText = re.Replace(DisplayableText, "<a href=" + Chr(34) + "http://[^\s]+", AddressOf MaskHttpReferenceWithQuote)

        ' Hyperlink HTTP references.
        DisplayableText = re.Replace(DisplayableText, "http://[^\s]+", AddressOf EvaluateHttpReference)

        ' Hyperlink e-mail addresses
        DisplayableText = re.Replace(DisplayableText, "\w+[@][^\s]+", AddressOf EvaluateEmailAddress)

        ' Hyperlink CamelCase words.
        Select Case TargetFrame
            Case Is = Nothing
                DisplayableText = re.Replace(DisplayableText, AddressOf EvaluateCamelCaseWord)
            Case Is = "content"
                DisplayableText = re.Replace(DisplayableText, AddressOf EvaluateCamelCaseWordContentFrame)
        End Select

        ' Restore existing HREF references.
        DisplayableText = re.Replace(DisplayableText, "<a href=xttp://[^\s]+", AddressOf UnMaskHttpReference)
        DisplayableText = re.Replace(DisplayableText, "<a href=" + Chr(34) + "xttp://[^\s]+", AddressOf UnMaskHttpReferenceWithQuote)

        ' Replace carriage returns and line feeds.
        DisplayableText = re.Replace(DisplayableText, "\r\n", "<br>", CamelCaseOptions)
        'DisplayableText = re.Replace(DisplayableText, "\r", "<br>", CamelCaseOptions)
        'DisplayableText = re.Replace(DisplayableText, "\n", "<br>", CamelCaseOptions)

        ' Prevent new line tag after table tags.
        DisplayableText = re.Replace(DisplayableText, "<table border=1><br>", "<table border=1>", CamelCaseOptions)
        DisplayableText = re.Replace(DisplayableText, "<table><br>", "<table>", CamelCaseOptions)
        DisplayableText = re.Replace(DisplayableText, "</table><br>", "</table>", CamelCaseOptions)
        DisplayableText = re.Replace(DisplayableText, "<tr><br>", "<tr>", CamelCaseOptions)
        DisplayableText = re.Replace(DisplayableText, "<td><br>", "<td>", CamelCaseOptions)

        ' Prevent new lines tag after horizontal line tag.
        DisplayableText = re.Replace(DisplayableText, "<hr><br>", "<hr>", CamelCaseOptions)

        ' Prevent new lines tag after <pre> tags.
        DisplayableText = re.Replace(DisplayableText, "<pre><br>", "<pre>", CamelCaseOptions)
        DisplayableText = re.Replace(DisplayableText, "</pre><br>", "</pre>", CamelCaseOptions)

        ' Prevent new lines tag after header tag.
        ' This should be changed to use a named expression.
        DisplayableText = re.Replace(DisplayableText, "</h1><br>", "</h1>", CamelCaseOptions)
        DisplayableText = re.Replace(DisplayableText, "</h2><br>", "</h2>", CamelCaseOptions)
        DisplayableText = re.Replace(DisplayableText, "</h3><br>", "</h3>", CamelCaseOptions)
        DisplayableText = re.Replace(DisplayableText, "</h4><br>", "</h4>", CamelCaseOptions)

        Return DisplayableText

    End Function

    ' Jan/2003 - hcorrea@visionds.com
    Public Shared Function MakeDisplayableText( _
                            ByRef WebPage As String, _
                            ByRef TextToProcess As String, _
                                  Optional ByRef TargetFrame As String = Nothing) As String

        Return MakeDisplayableText(ConstCamelCaseRegExp, WebPage, TextToProcess, TargetFrame)

    End Function

    ' Jan/2003 - hcorrea@visionds.com
    ' To do: 
    '   * How can I pass "default.aspx" as a parameter?
    '   * Add code to detect whether the topic already exist or not.
    '     Existing topics should be rendered as hyperlinks while non-existing
    '     topics should be rendered with a '?' at the end.
    Public Shared Function EvaluateCamelCaseWord(ByVal m As Match) As String
        Return "<a href=default.aspx?topic=" + _
                m.Value + ">" + m.Value + "</a>"
    End Function

    Public Shared Function EvaluateCamelCaseWordContentFrame(ByVal m As Match) As String
        Return "<a href=default.aspx?topic=" + _
                m.Value + " target=content>" + m.Value + "</a>"
    End Function

    ' Feb/2003 - hcorrea@visionds.com
    ' Notice that I am forcing the link to lower case from prevent 
    ' them from being considered as CamelCase word should the come
    ' in CamelCase notation. I might need to change this later on.
    Public Shared Function EvaluateHttpReference(ByVal m As Match) As String
        Return "<a href=" + Chr(34) + m.Value.ToLower() + Chr(34) + _
            " target=" + Chr(34) + "other" + Chr(34) + ">" + _
            m.Value.ToLower() + "</a>"
    End Function

    ' Feb/2003 - hcorrea@visionds.com
    ' Notice that I am forcing the link to lower case from prevent 
    ' them from being considered as CamelCase word should the come
    ' in CamelCase notation. I might need to change this later on.
    Public Shared Function EvaluateEmailAddress(ByVal m As Match) As String
        Return "<a href=" + Chr(34) + "mailto:" + m.Value.ToLower() + Chr(34) + ">" + _
            m.Value.ToLower() + "</a>"
    End Function

    ' m.value is equal to <a href=http...
    '                     012345678901
    Public Shared Function MaskHttpReference(ByVal m As Match) As String
        Return "<a href=xttp" + m.Value.Substring(12)
    End Function

    ' m.value is equal to <a href=xttp...
    '                     012345678901
    Public Shared Function UnMaskHttpReference(ByVal m As Match) As String
        Return "<a href=http" + m.Value.Substring(12)
    End Function

    ' m.value is equal to <a href="http...
    '                     0123456789012
    Public Shared Function MaskHttpReferenceWithQuote(ByVal m As Match) As String
        Return "<a href=" + Chr(34) + "xttp" + m.Value.Substring(13)
    End Function

    ' m.value is equal to <a href="xttp...
    '                     0123456789012
    Public Shared Function UnMaskHttpReferenceWithQuote(ByVal m As Match) As String
        Return "<a href=" + Chr(34) + "http" + m.Value.Substring(13)
    End Function

    Public Shared Function IsCamelCaseWord(ByRef Word As String)
        Dim re As New Regex(ConstCamelCaseRegExp)
        Return (re.Matches(Word).Count = 1)
    End Function

#Region "Parser Version One (before regular expression)"

    ' Takes a text and converts all CamelCase words to hyperlinks.
    '
    ' This is version 1.0 - It does the job without any optimizations.
    ' Should we use StringBuilder instead of String to optimize speed?
    '
    ' Sample Input:
    '   WebPage = "Default.aspx"
    '   TextToProcess = "HelloDolly by LouisArmstrong"
    ' Sample Output:
    '   "<a href=Default.aspx?topic=HelloDolly>HelloDolly</a> by <a href=Default.aspx?topic=LouisArmstrong>LouisArmstrong</a>"
    '
    Public Shared Function MakeDisplayableText_version1( _
                            ByRef WebPage As String, _
                            ByRef TextToProcess As String)
        Dim DisplayableText As New String("")
        Dim i As Integer
        Dim ThisCharIsAlpha, ThisCharIsUpper, ThisCharIsLower As Boolean
        Dim LastCharWasAlpha, LastCharWasLower As Boolean
        Dim CamelWordInProgress, CamelWordWasInProgress As Boolean
        Dim CamelWord As New String("")
        Dim UpperChars As Integer = 0
        Dim ThisChar As Char
        Dim ThisAscii, LastAscii As Integer

        For i = 0 To TextToProcess.Length - 1
            ThisChar = TextToProcess.Chars(i)
            ThisAscii = AscW(ThisChar)

            If CamelWordInProgress Then
                ThisCharIsAlpha = Char.IsLetter(ThisChar) Or Char.IsDigit(ThisChar) Or ThisChar = "_"
                ThisCharIsUpper = Char.IsUpper(ThisChar) Or Char.IsDigit(ThisChar) Or ThisChar = "_"
            Else
                ThisCharIsAlpha = Char.IsLetter(ThisChar)
                ThisCharIsUpper = Char.IsUpper(ThisChar)
            End If
            ThisCharIsLower = Char.IsLower(ThisChar)

            If ThisCharIsAlpha Then
                If ThisCharIsUpper Then
                    UpperChars += 1
                    If CamelWordInProgress Then
                        CamelWord += ThisChar
                    Else
                        CamelWordInProgress = True
                        CamelWord = ThisChar
                    End If
                Else
                    If ThisCharIsLower Then
                        If CamelWordInProgress Then
                            CamelWord += ThisChar
                        Else
                            If CamelWordWasInProgress Then
                                If UpperChars > 1 And _
                                    CamelWord <> CamelWord.ToUpper() Then
                                    DisplayableText += Wiki.HyperLinkWord(WebPage, CamelWord)
                                Else
                                    DisplayableText += CamelWord
                                End If
                                CamelWord = ""
                                UpperChars = 0
                            End If
                            DisplayableText += ThisChar
                        End If
                    Else
                        CamelWordInProgress = False
                        DisplayableText += ThisChar
                    End If
                End If
            Else
                CamelWordInProgress = False
                If CamelWordWasInProgress Then
                    If UpperChars > 1 And _
                        CamelWord <> CamelWord.ToUpper() Then
                        DisplayableText += Wiki.HyperLinkWord(WebPage, CamelWord)
                    Else
                        DisplayableText += CamelWord
                    End If
                    CamelWord = ""
                    UpperChars = 0
                End If
                Select Case ThisAscii
                    Case 10
                        'ignore
                    Case 13
                        DisplayableText += "<br>"
                    Case Else
                        DisplayableText += ThisChar
                End Select
            End If
            CamelWordWasInProgress = CamelWordInProgress
        Next

        If CamelWordWasInProgress Then
            If UpperChars > 1 And _
                CamelWord <> CamelWord.ToUpper() Then
                DisplayableText += Wiki.HyperLinkWord(WebPage, CamelWord)
            Else
                DisplayableText += CamelWord
            End If
        End If

        Return DisplayableText
    End Function

    Public Shared Function HyperLinkWord(ByRef WebPage As String, ByRef Word As String) As String
        Return "<a href=" + WebPage + "?topic=" + Word + ">" + Word + "</a>"
    End Function
#End Region

#Region "Parser Version Two (with regular expression without stringbuilder)"
    ' Jan/2003 - hcorrea@visionds.com
    ' Converts a text with CamelCase words to its equivalent with
    ' hyperlinks on each CamelCase word.
    '
    ' This version uses regular expressions instead of a customized parser.
    Public Shared Function MakeDisplayableText_version2( _
                            ByRef WebPage As String, _
                            ByRef TextToProcess As String) As String

        Dim re As New Regex(ConstCamelCaseRegExp, RegexOptions.Compiled)
        Dim DisplayableText As String

        DisplayableText = re.Replace(TextToProcess, AddressOf EvaluateCamelCaseWord)

        ' Replace carriage returns and line feeds.
        DisplayableText = re.Replace(DisplayableText, "\r\n", "<br>", RegexOptions.Compiled)
        DisplayableText = re.Replace(DisplayableText, "\r", "<br>", RegexOptions.Compiled)
        DisplayableText = re.Replace(DisplayableText, "\n", "<br>", RegexOptions.Compiled)

        ' Prevent new line tag after table tags.
        DisplayableText = re.Replace(DisplayableText, "<table><br>", "<table>", RegexOptions.Compiled)
        DisplayableText = re.Replace(DisplayableText, "</table><br>", "</table>", RegexOptions.Compiled)
        DisplayableText = re.Replace(DisplayableText, "</tr><br>", "</tr>", RegexOptions.Compiled)
        DisplayableText = re.Replace(DisplayableText, "</td><br>", "</td>", RegexOptions.Compiled)

        ' Prevent new lines tag after horizontal line tag.
        DisplayableText = re.Replace(DisplayableText, "<hr><br>", "<hr>", RegexOptions.Compiled)

        ' Prevent new lines tag after <pre> tags.
        DisplayableText = re.Replace(DisplayableText, "<pre><br>", "<pre>", RegexOptions.Compiled)
        DisplayableText = re.Replace(DisplayableText, "</pre><br>", "</pre>", RegexOptions.Compiled)

        ' Prevent new lines tag after header tag.
        ' This should be changed to use a named expression.
        DisplayableText = re.Replace(DisplayableText, "</h1><br>", "</h1>", RegexOptions.Compiled)
        DisplayableText = re.Replace(DisplayableText, "</h2><br>", "</h2>", RegexOptions.Compiled)
        DisplayableText = re.Replace(DisplayableText, "</h3><br>", "</h3>", RegexOptions.Compiled)
        DisplayableText = re.Replace(DisplayableText, "</h4><br>", "</h4>", RegexOptions.Compiled)

        ' to do: parse e-mail addresses 
        ' to do: parse HTTP references

        Return DisplayableText

    End Function

#End Region

End Class
