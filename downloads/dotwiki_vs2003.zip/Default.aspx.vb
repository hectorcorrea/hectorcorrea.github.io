' description:  Web page where wiki web pages are rendered.
' author:       Sept/2002 - hcorrea@visionds.com 
' updated:
Imports DotWiki.BusinessServices
Imports DotWiki.Wiki
Imports DotWiki.WikiPage

Public Class WikiTopicPage
    Inherits System.Web.UI.Page
    Protected WithEvents lblPageContent As System.Web.UI.WebControls.Label
    Protected WithEvents cmdEdit As System.Web.UI.WebControls.Button
    Protected WithEvents txtPageContent As System.Web.UI.WebControls.TextBox
    Protected WithEvents cmdSave As System.Web.UI.WebControls.Button
    Protected WithEvents cmdHistory As System.Web.UI.WebControls.Button
    Protected WithEvents txtViewHistory As System.Web.UI.WebControls.HyperLink
    Protected WithEvents chkPageInEditMode As System.Web.UI.WebControls.CheckBox
    Protected WithEvents lblPageTopic As System.Web.UI.WebControls.Label
    Protected WithEvents cmdSaveAndContinue As System.Web.UI.WebControls.Button
    Protected WithEvents txtAddPicture As System.Web.UI.WebControls.HyperLink
    Protected WithEvents cmdCancel As System.Web.UI.WebControls.Button

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Not Me.IsPostBack() Then

            If Me.Request.QueryString.Item("topic") Is Nothing Then
                Me.lblPageTopic.Text = "HomeWiki"
            Else
                Me.lblPageTopic.Text = Me.Request.QueryString.Item("topic").ToString()
            End If

            If Not Me.Request.QueryString.Item("mode") Is Nothing Then
                If Me.Request.QueryString.Item("mode").ToUpper() = "EDIT" Then
                    Me.chkPageInEditMode.Checked = True
                End If
            End If

            Me.InitialializePage()

        End If
    End Sub

    Private Sub cmdEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        Me.EditPage()
    End Sub

    Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Me.SaveChanges()
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        Me.CancelChanges()
    End Sub

    Private Sub cmdSaveAndContinue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSaveAndContinue.Click
        Me.SaveAndContinue()
    End Sub

    Private Sub cmdEdit2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.EditPage()
    End Sub

    Private Sub cmdSave2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.SaveChanges()
    End Sub

    Private Sub cmdCancel2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.CancelChanges()
    End Sub

    Private Sub InitialializePage()
        Dim WikiSet As String
        WikiSet = ConfigurationSettings.AppSettings("WikiSet")
        Me.txtPageContent.Text = ReadTopic(Me.lblPageTopic.Text, WikiSet)
        Dim HomePage As String
        HomePage = ConfigurationSettings.AppSettings("HomePage")
        Me.lblPageContent.Text = MakeDisplayableText(HomePage, Me.txtPageContent.Text)
        Me.DisplayContent()
    End Sub

    Private Sub DisplayContent()
        If Me.chkPageInEditMode.Checked Then
            Me.txtPageContent.Visible = True
            Me.lblPageContent.Visible = False
            Me.cmdEdit.Visible = False
            Me.cmdSave.Visible = True
            Me.cmdSaveAndContinue.Visible = True
            Me.cmdCancel.Visible = True
            Me.txtViewHistory.Visible = False
            Me.txtAddPicture.Visible = False
            'Me.cmdEdit2.Visible = False
            'Me.cmdSave2.Visible = True
            'Me.cmdCancel2.Visible = True
        Else
            Me.txtPageContent.Visible = False
            Me.lblPageContent.Visible = True
            Me.cmdEdit.Visible = True
            Me.cmdSave.Visible = False
            Me.cmdSaveAndContinue.Visible = False
            Me.cmdCancel.Visible = False
            Me.txtViewHistory.Visible = True
            Me.txtAddPicture.Visible = True
            'Me.cmdEdit2.Visible = True
            'Me.cmdSave2.Visible = False
            'Me.cmdCancel2.Visible = False
        End If

        ' Oct/2002 - HJC
        ' Disabled this until I have finished EnableControls 
        ' method. Also, be aware that call to FindHeaderControl 
        ' could impose a big performance hit on this page -- 
        ' still is pending to do some benchmarking on this.
        '
        ' Is there any mechanism to point to the PageHeader 
        ' control at design time (e.g. me.PageHeader)?
        '
        'Dim Header As DotWiki.PageHeader
        'Header = FindHeaderControl()
        'If Not IsNothing(Header) Then
        '   Header.EnableControls(Not Me.chkPageInEditMode.Checked)
        'End If

    End Sub

    Public Function FindHeaderControl() As DotWiki.PageHeader
        Dim RetVal As DotWiki.PageHeader
        RetVal = Nothing
        Dim PageControl As System.Web.UI.Control
        For Each PageControl In Me.Controls
            If PageControl.ID = "Form1" Then
                Dim FormControl As System.Web.UI.Control
                For Each FormControl In PageControl.Controls
                    If FormControl.ID = "PageHeader1" Then
                        RetVal = FormControl
                    End If
                Next
            End If
        Next
        Return RetVal
    End Function


    Private Sub CancelChanges()
        Me.chkPageInEditMode.Checked = False
        Me.DisplayContent()
    End Sub

    Private Sub SaveChanges()
        Me.chkPageInEditMode.Checked = False
        Dim HomePage As String
        HomePage = ConfigurationSettings.AppSettings("HomePage")
        Me.lblPageContent.Text = MakeDisplayableText(HomePage, Me.txtPageContent.Text)
        Dim WikiSet As String
        WikiSet = ConfigurationSettings.AppSettings("WikiSet")
        SaveTopic(Me.lblPageTopic.Text, Me.txtPageContent.Text, WikiSet)
        Me.DisplayContent()
    End Sub

    Private Sub SaveAndContinue()
        Dim HomePage As String
        HomePage = ConfigurationSettings.AppSettings("HomePage")
        Dim WikiSet As String
        WikiSet = ConfigurationSettings.AppSettings("WikiSet")
        SaveTopic(Me.lblPageTopic.Text, Me.txtPageContent.Text, WikiSet)
    End Sub

    Private Sub EditPage()
        Me.chkPageInEditMode.Checked = True
        Me.DisplayContent()
    End Sub

    Private Sub txtViewHistory_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtViewHistory.PreRender
        txtViewHistory.NavigateUrl = "TopicHistory.aspx?topic=" + Me.lblPageTopic.Text
    End Sub

    Private Sub txtAddPicture_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtViewHistory.PreRender
        txtAddPicture.NavigateUrl = "FileUpload.aspx?topic=" + Me.lblPageTopic.Text
    End Sub

End Class
