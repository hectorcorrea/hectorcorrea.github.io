-- Create database
use master 
go

create database dotwikihector
go

-- Create an initial copy of the database
use master 
go

restore database dotwikihector from disk = 'c:\DotWiki\database\DotWikiHector.bak'
go

-- Create user
use master 
go

exec sp_addlogin 'dotwikiuser', 'dotwikipwd', 'dotwikihector'
go

-- Grant user access to database
use dotwikihector
go

exec sp_grantdbaccess 'dotwikiuser'
go

exec sp_addrolemember 'db_owner', 'dotwikiuser'
go

use master 
go
