Public MustInherit Class PageHeader
    Inherits System.Web.UI.UserControl
    Protected WithEvents lblHome As System.Web.UI.WebControls.HyperLink
    Protected WithEvents lblIndex As System.Web.UI.WebControls.HyperLink
    Protected WithEvents lblRecentChanges As System.Web.UI.WebControls.HyperLink
    Protected WithEvents lblSearch As System.Web.UI.WebControls.HyperLink
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not Me.IsPostBack() Then
            Dim HomePage As String
            HomePage = ConfigurationSettings.AppSettings("HomePage")
            Me.lblHome.NavigateUrl = HomePage
        End If
    End Sub

    Public Sub EnableControls(ByRef NewStatus As Boolean)
        ' Oct/2002 - HJC
        ' As odd as it sounds, disabling these guys does not 
        ' prevent the user from clicking on these hyperlinks.
        ' To do: 
        '   Modify this method to clear the NavigationURL
        '   property (when NewStatus=false) to effectively 
        '   prevent user from clicking on these links. Doing 
        '   this (without hard-coding the URLs) is a little 
        '   bit trickier than it seems.
        '
        Me.lblHome.Enabled = NewStatus
        Me.lblIndex.Enabled = NewStatus
        Me.lblRecentChanges.Enabled = NewStatus
        Me.lblSearch.Enabled = NewStatus
    End Sub

End Class

