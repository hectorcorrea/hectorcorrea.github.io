' description:  Business services for DotWiki project.
' author:       Sept/2002 - hcorrea@visionds.com 
' updated:      

Imports System.Data.SqlClient
Imports DotWiki.DataServices

Public Class BusinessServices

    Public Shared Function AddPictureToTopic(ByRef TopicName As String, _
        ByRef Picture As String, _
        ByRef WikiSet As String)

        Dim TopicContent As String
        TopicContent = ReadTopic(TopicName, WikiSet)
        TopicContent += Chr(13) + Chr(10) + "<img src=" + Picture + " border=1>"

        SaveTopic(TopicName, TopicContent, WikiSet)

    End Function

    Public Shared Function GetIndexDS(ByRef SearchString As String, _
        ByRef WikiSet As String) As DataSet
        Dim ds As DataSet
        Dim oConn As SqlConnection
        oConn = ConnectToDB()
        If Not IsNothing(oConn) Then
            Try
                Dim HomePage As String
                HomePage = ConfigurationSettings.AppSettings("HomePage")
                Dim sc As New SqlCommand()
                sc.Parameters.Add("@WikiSet", WikiSet)
                sc.Parameters.Add("@SearchString", "%" + SearchString + "%")
                sc.Parameters.Add("@HomePageLink", HomePage + "?topic=")
                If SearchString Is Nothing OrElse SearchString.Length = 0 Then
                    sc.CommandText = _
"select name, updatedon, " + _
"@HomePageLink + name as link " + _
"from topic " + _
"where wikiset = @WikiSet " + _
"order by name"
                Else
                    sc.CommandText = _
"select name, updatedon, " + _
"@HomePageLink + name as link " + _
"from topic " + _
"where wikiset = @WikiSet and " + _
"( name like @SearchString or content like @SearchString ) " + _
"order by name"
                End If
                sc.Connection = oConn
                Dim da As New SqlDataAdapter(sc)
                ds = New DataSet()
                da.Fill(ds, "topic")
            Catch
            End Try
        End If
        Return ds
    End Function

    Public Shared Function GetRecentChangesDS(ByVal Days As Integer, _
        ByRef WikiSet As String) As DataSet
        Dim ds As DataSet
        Dim oConn As SqlConnection
        oConn = ConnectToDB()
        If Not IsNothing(oConn) Then
            Try
                Dim HomePage As String
                HomePage = ConfigurationSettings.AppSettings("HomePage")
                Dim sc As New SqlCommand()
                sc.Parameters.Add("@WikiSet", WikiSet)
                sc.Parameters.Add("@Days", Days)
                sc.Parameters.Add("@HomePageLink", HomePage + "?topic=")
                sc.CommandText = _
"select name, updatedon, " + _
"@HomePageLink + name as link " + _
"from topic " + _
"where wikiset = @WikiSet and " + _
"DateDiff(d, updatedon, getdate()) <= @Days " + _
"order by updatedon desc"
                sc.Connection = oConn
                Dim da As New SqlDataAdapter(sc)
                ds = New DataSet()
                da.Fill(ds, "topic")
            Catch
            End Try
        End If
        Return ds
    End Function

    Public Shared Function ReadTopicHistory(ByRef PK As String, _
                                            ByRef DateTime As String) As String
        Dim oConn As SqlConnection
        Dim TopicContent As String

        oConn = ConnectToDB()
        If Not IsNothing(oConn) Then
            Try
                Dim sc As New SqlCommand()
                sc.Parameters.Add("@PK", PK)
                sc.CommandText = "select content, updatedon from topichistory where topichistorypk = @PK"
                sc.Connection = oConn
                Dim da As New SqlDataAdapter(sc)
                Dim ds As New DataSet()
                da.Fill(ds, "topichistory")
                If ds.Tables(0).Rows.Count <> 1 Then
                    Throw New System.Exception("Incorrect number of records found in topichistory")
                End If
                TopicContent = CType(ds.Tables(0).Rows(0).Item("content"), String)
                DateTime = CType(ds.Tables(0).Rows(0).Item("updatedon"), String)
            Finally
                oConn.Close()
            End Try
        Else
            TopicContent = ""
            DateTime = ""
        End If

        Return TopicContent

    End Function

    Public Shared Function ReadTopic(ByRef TopicName As String, _
                                    ByRef WikiSet As String) As String
        Dim oConn As SqlConnection
        Dim TopicContent As String

        oConn = ConnectToDB()
        If Not IsNothing(oConn) Then
            Try
                Dim sc As New SqlCommand()
                sc.Parameters.Add("@TopicName", TopicName)
                sc.Parameters.Add("@WikiSet", WikiSet)
                sc.CommandText = "select content from topic " + _
                                 "where name = @TopicName and wikiset = @WikiSet"
                sc.Connection = oConn
                TopicContent = CType(sc.ExecuteScalar(), String)
            Finally
                oConn.Close()
            End Try
        Else
            TopicContent = ""
        End If

        Return TopicContent

    End Function

    Public Shared Function SaveTopic(ByRef TopicName As String, _
                                    ByRef TopicContent As String, _
                                    ByRef WikiSet As String) As String
        Dim oConn As SqlConnection
        Dim RetVal As String

        oConn = ConnectToDB()
        If Not IsNothing(oConn) Then

            Try
                Dim sc As New SqlCommand()
                sc.Parameters.Add("@TopicName", TopicName)
                sc.Parameters.Add("@WikiSet", WikiSet)
                sc.CommandText = "select content, name, topicpk, updatedon, wikiset " + _
                                 "from topic " + _
                                 "where name = @TopicName and wikiset = @WikiSet"
                sc.Connection = oConn
                Dim da As New SqlDataAdapter(sc)
                Dim cb As New SqlCommandBuilder(da)
                Dim ds As New DataSet()
                da.Fill(ds, "topic")
                If ds.Tables("topic").Rows.Count = 0 Then
                    ' new topic
                    Dim NewRow As DataRow
                    NewRow = ds.Tables("topic").NewRow()
                    ds.Tables("topic").Rows.Add(NewRow)
                    ds.Tables("topic").Rows(0).Item("name") = TopicName
                    ds.Tables("topic").Rows(0).Item("wikiset") = WikiSet
                Else
                    BackupTopic(ds.Tables("topic").Rows(0).Item("topicpk").ToString(), oConn)
                End If
                ds.Tables("topic").Rows(0).Item("content") = TopicContent
                ds.Tables("topic").Rows(0).Item("updatedon") = Date.Now()
                da.Update(ds, "topic")

            Catch e As Exception
                RetVal = e.Message
            Finally
                oConn.Close()
            End Try

        Else
            RetVal = "Could not connect to database"
        End If

        Return RetVal
    End Function

    Public Shared Function BackupTopic(ByRef TopicPK As String, ByRef oConn As SqlConnection) As String
        Dim sc As New SqlCommand()
        sc.Parameters.Add("@TopicPK", TopicPK)
        sc.CommandText = "insert into topichistory( " + _
                         "topicfk, name, content, updatedon, wikiset ) " + _
                         "select topicpk, name, content, updatedon, wikiset " + _
                         "from topic " + _
                         "where topicpk = @TopicPK"
        sc.Connection = oConn
        sc.ExecuteNonQuery()
    End Function

    Public Shared Function CreateHistoryTable( _
            ByRef TopicName As String, _
            ByRef WikiSet As String) As String

        Dim TableHeader As String
        TableHeader = "<tr><td><b>Topic</b></td>" + _
                    "<td><b>Updated On </b><img border=0 src=images/uparrow.jpg></td></tr>"

        Dim TopicTable As String
        TopicTable = ""

        Dim oConn As SqlConnection
        oConn = ConnectToDB()
        If Not IsNothing(oConn) Then
            Try

                Dim sc As New SqlCommand()
                sc.Parameters.Add("@WikiSet", WikiSet)
                sc.Parameters.Add("@Name", TopicName)
                sc.CommandText = "select name, updatedon, topichistorypk " + _
                                "from topichistory " + _
                                "where name = @Name and wikiset = @WikiSet " + _
                                "order by updatedon desc"
                sc.Connection = oConn
                Dim da As New SqlDataAdapter(sc)
                Dim ds As New DataSet()
                da.Fill(ds, "topic")
                If ds.Tables(0).Rows.Count > 0 Then
                    TopicTable += "<table>" + TableHeader
                    Dim dr As DataRow
                    For Each dr In ds.Tables(0).Rows
                        Dim ThisTopic, ThisPK, LastUpdate As String
                        ThisTopic = dr.Item("name").ToString().TrimEnd()
                        ThisPK = dr.Item("topichistorypk").ToString()
                        LastUpdate = dr.Item("updatedon").ToString()
                        TopicTable += "<tr>" + _
                                      "<td>" + _
                                      ThisTopic + _
                                      "</td>" + _
                                      "<td>" + _
                                      "<a href=TopicHistory.aspx" + _
                                      "?topic=" + ThisTopic + "&pk=" + ThisPK + ">" + _
                                      LastUpdate + "</a> " + _
                                      "</td>" + _
                                      "</tr>"
                    Next
                    TopicTable += "</table>"
                End If
            Finally
                oConn.Close()
            End Try
        End If

        Return TopicTable

    End Function

#Region "Methods used to create index tables with strings instead of data sets"
    Public Shared Function CreateIndex(ByRef SearchString As String, _
                                        ByRef WikiSet As String) As String
        Dim sc As New SqlCommand()
        sc.Parameters.Add("@WikiSet", WikiSet)
        sc.Parameters.Add("@SearchString", "%" + SearchString + "%")
        If SearchString Is Nothing Or SearchString.Length = 0 Then
            sc.CommandText = "select name, updatedon " + _
                            "from topic " + _
                            "where wikiset = @WikiSet " + _
                            "order by Name"
        Else
            sc.CommandText = "select name, updatedon " + _
                            "from topic " + _
                            "where wikiset = @WikiSet and " + _
                            "( name like @SearchString or content like @SearchString ) " + _
                            "order by name"
        End If
        Return CreateTopicTable(sc, "NAME")
    End Function

    Public Shared Function CreateRecentChanges(ByVal Days As Integer, _
                                ByVal WikiSet As String) As String
        Dim sc As New SqlCommand()
        sc.Parameters.Add("@WikiSet", WikiSet)
        sc.Parameters.Add("@Days", Days)
        sc.CommandText = "select name, updatedon " + _
                        "from topic " + _
                        "where wikiset = @WikiSet and " + _
                        "DateDiff(d, updatedon, getdate()) <= @Days " + _
                        "order by updatedon desc"
        Return CreateTopicTable(sc, "DATE")
    End Function


    Public Shared Function CreateTopicTable(ByRef sc As SqlCommand, _
                                    ByVal Order As String) As String
        Dim HomePage As String
        HomePage = ConfigurationSettings.AppSettings("HomePage")
        Return CreateTopicTable(sc, Order, HomePage)
    End Function

    Public Shared Function CreateTopicTable(ByRef sc As SqlCommand, _
                                    ByVal Order As String, _
                                    ByRef WebPage As String) As String
        Dim TopicTable As String
        Dim TableHeader As String

        If Order <> "NAME" And Order <> "DATE" Then
            Order = "DATE"
        End If

        Select Case Order
            Case "NAME"
                TableHeader = "<tr><td><b>Name </b><img border=0 src=images/uparrow.jpg></td><td><b>Last Updated On</b></td></tr>"
            Case "DATE"
                TableHeader = "<tr><td><b>Name</b></td><td><b>Last Updated On </b><img border=0 src=images/uparrow.jpg></td></tr>"
        End Select

        TopicTable = ""
        sc.Connection = ConnectToDB()
        If Not IsNothing(sc.Connection) Then
            Try
                Dim da As New SqlDataAdapter(sc)
                Dim ds As New DataSet()
                da.Fill(ds, "topic")
                If ds.Tables(0).Rows.Count > 0 Then

                    TopicTable += "<table>" + TableHeader
                    Dim dr As DataRow
                    For Each dr In ds.Tables(0).Rows
                        Dim ThisTopic, LastUpdate As String
                        ThisTopic = dr.Item("name").ToString().TrimEnd()
                        LastUpdate = dr.Item("updatedon").ToString()
                        TopicTable += "<tr>" + _
                                        "<td>" + _
                                        "<a href=" + _
                                        WebPage + _
                                        "?topic=" + ThisTopic + ">" + _
                                        ThisTopic + "</a> " + _
                                        "</td>" + _
                                        "<td>" + _
                                        LastUpdate + _
                                        "</td>" + _
                                        "</tr>"
                    Next
                    TopicTable += "</table>"
                End If
            Finally
                sc.Connection.Close()
            End Try
        End If

        Return TopicTable
    End Function
#End Region
End Class
