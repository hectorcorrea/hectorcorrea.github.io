' March/2003 - hcorrea@visionds.com
' Class not in use. Created as a test only.
Public Class WikiPage
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region


    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Trace.Warn("Loading base class...")

        'Trace.Warn("Loading user control...")
        'Dim x As Control
        'x = LoadControl("SimpleControl.ascx")
        'Dim y As DotWiki.SimpleControl
        'y = CType(x, DotWiki.SimpleControl)
        'y.lblTheLabel.Text = "my text" + Now
        'Me.Controls.Add(x)
    End Sub
End Class
