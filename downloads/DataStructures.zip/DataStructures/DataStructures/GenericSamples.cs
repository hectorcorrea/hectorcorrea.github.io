using System;
using System.Collections.Generic;
using System.Text;

namespace DataStructures.Generic.Samples
{

    public class Col<T>
    {
        T t;
        public T Val 
        { 
            get { return t; } 
            set { t = value; } 
        }
    }

    public class SimpleGeneric
    {

        public void Run()
        {
            Col<int> i = new Col<int>();
            i.Val = 3;
            Console.WriteLine(i.Val);

            Col<string> s = new Col<string>();
            s.Val = "hello";
            Console.WriteLine(s.Val);

            Col<float> f = new Col<float>();
            f.Val = 4.5F;
            Console.WriteLine(f.Val);
            return;
        }
    }

    public class GenericCollection
    {
        public void Run()
        {
            Employee e1 = new Employee("hector", 33);
            Employee e2 = new Employee("karla", 32);

            List<Employee> l = new List<Employee>();
            l.Add(e1);
            l.Add(e2);

            foreach (Employee e in l)
            {
                Console.WriteLine("name: {0} age {1}", e.Name, e.Age);
            }

            return;
        }
    }

    public class Employee : IComparable
    { 
        private string _name;
        private int _age;

        public Employee(string name, int age)
        {
            _name = name;
            _age = age;
        }

        public int CompareTo(object o)
        {
            Employee e2 = (Employee)o;            
            if (_age > e2.Age) return 1;
            if (_age < e2.Age) return -1;
            return 0; 
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }

        public override string ToString()
        {
            return _name;
        }
    }

    public class Node<T>
    {
        private Node<T> _next;
        private T _data;
        public Node(T t)
        {
            _next = null;
            _data = t;
        }

        public Node<T> Next
        {
            get { return _next; }
            set { _next = value; }
        }

        public T Data
        {
            get { return _data; }
            set { _data = value; }
        }

    }

    public class GenericList<T> where T : IComparable
    {

        private Node<T> _head;

        public GenericList()
        {
            _head = null;
        }

        public void AddHead(T t)
        {
            Node<T> n = new Node<T>(t);
            n.Next = _head;
            _head = n;
        }

        public IEnumerator<T> GetEnumerator()
        {
            Node<T> current = _head;
            while (current != null)
            {
                yield return current.Data;
                current = current.Next;
            }
        }

        public T FindOldest()
        {
            Node<T> current = _head;
            T oldest = current.Data;
            while (current != null)
            {
                int x = current.Data.CompareTo(oldest);
                if (x>0) oldest = current.Data;
                current = current.Next;
            }
            return oldest;
        }

    }

    public class TestList
    {
        public void Run()
        {
            GenericList<Employee> g = new GenericList<Employee>();
            g.AddHead(new Employee("hector", 33));
            g.AddHead(new Employee("karla",132));
            foreach (Employee i in g)
            {
                Console.WriteLine("{0}, {1}", i.Name, i.Age);
            }

            Employee oldest = g.FindOldest();
            Console.WriteLine("Oldest is {0} ({1})", oldest.Name, oldest.Age);

            GenericList<int> g2 = new GenericList<int>();
            g2.AddHead(4);
            g2.AddHead(100);
            g2.AddHead(5);
            foreach (int i2 in g2)
            {
                Console.WriteLine(i2);
            }
            int largest = g2.FindOldest();
            Console.WriteLine("Largest is {0}", largest);
            
            return;
        }
    }
}