using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace DataStructures
{
    [TestFixture]
    public class BinaryTreeTest
    {
        private string onWalk = "";
        private string leftChargedListOrdered = "1, 3, 10, 10, 10, 10, 15, 21, 23, 40, 50, 55, 60, 65, 91, 96";
        private string leftChargedListUnordered = "96, 21, 65, 55, 23, 91, 60, 15, 10, 50, 10, 3, 10, 1, 40, 10";

        [Test]
        public void TestSimpleBinaryTree()
        {
            BinaryTree b = new BinaryTree();
            b.Add(10);
            b.Add(5);
            b.Add(15);
            Assert.AreEqual("5, 10, 15", b.ToString());
            Assert.AreEqual("5, 10, 15", b.WalkInOrder());
        }

        private BinaryTree SetUpLeftChargedTree()
        {
            BinaryTree b = new BinaryTree();

            int[] nodes = {96, 21, 65, 55, 23, 91, 60, 15, 10, 50, 10, 3, 10, 1, 40, 10};
            for (int i = 0; i < nodes.Length; i++)
            {
                b.Add(nodes[i]);
            }
            return b;
        }

        [Test]
        public void TestWalkLeftLoadedTree()
        {
            BinaryTree b = SetUpLeftChargedTree();
            //Assert.AreEqual(leftChargedListUnordered, b.ToString());
            Assert.AreEqual(leftChargedListOrdered, b.WalkInOrder());
        }

        [Test]
        public void TestOnWalkLeftLoadedTree()
        {
            BinaryTree b = SetUpLeftChargedTree();
            b.onNodeWalkedInOrder += new NodeWalkedInOrder(OnWalkLeftLoadedTree);
//            Assert.AreEqual(leftChargedListUnordered, b.ToString());
            onWalk = "";
            b.WalkInOrder();
            Assert.AreEqual(leftChargedListOrdered, b.ToString());
            Assert.AreEqual("on walk called", onWalk);
        }

        private void OnWalkLeftLoadedTree(BinaryNode node, BinaryNode parent)
        {
            onWalk = "on walk called";
        }
        
        [Test]
        public void TestToString()
        {
            BinaryTree b = SetUpLeftChargedTree();
            b.onNodeWalkedInOrder += new NodeWalkedInOrder(OnWalkLeftLoadedTree);
            //Assert.AreEqual(leftChargedListUnordered, b.ToString());
            Assert.AreEqual(leftChargedListOrdered, b.ToString());
        }

    }
}
