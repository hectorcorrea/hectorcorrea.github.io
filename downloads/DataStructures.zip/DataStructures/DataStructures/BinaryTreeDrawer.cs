using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace DataStructures 
{
    enum BinaryTreeDrawerDirection
    {
        Center = 1,
        Left = 2,
        Right = 3
    }

    public class BinaryTreeDrawer<T> where T : IComparable
    {
        private int _nodeWidth = 20;
        private int _nodeHeight = 20;
        private int _nodeToNodeDistance = 10;
        private int _nodeDepth = 35;
        private Brush _nodeFillColor = Brushes.LimeGreen;
        private Brush _nodeLineColor = Brushes.Black;
        private Brush _nodeTextColor = Brushes.Black;
        private Brush _nodeToNodeLineColor = Brushes.Blue;

        private Graphics _gr;
        private Size _nodeSize;
        private Size _maxImageSize;
        private Size _minImageSize;
        private Point _initPos;

        public void Draw(BinaryTree<T> binaryTree, Graphics g, ref Point initPos, out Size imageSize)
        {
            _gr = g;
            _maxImageSize = new Size(0, 0);
            _minImageSize = new Size(0, 0);

            _nodeSize = new Size(_nodeWidth, _nodeHeight);
            _initPos = initPos;
            Draw(binaryTree.Center, _initPos, BinaryTreeDrawerDirection.Center);

            int width = _maxImageSize.Width + Math.Abs(_minImageSize.Width) + 100;
            int height = _maxImageSize.Height + Math.Abs(_maxImageSize.Height) + 100;
            imageSize = new Size(width, height);
            initPos = new Point(Math.Abs(_minImageSize.Width) + 100, 25);

        }

        private void Draw(BinaryTreeNode<T> node, Point lastPos, BinaryTreeDrawerDirection direction)
        {
            if (direction == BinaryTreeDrawerDirection.Center)
            {
                if (node != null)
                {
                    DrawNode(lastPos, _nodeSize, node);
                    if (node.Left != null) Draw(node.Left, lastPos, BinaryTreeDrawerDirection.Left);
                    if (node.Right != null) Draw(node.Right, lastPos, BinaryTreeDrawerDirection.Right);
                }
            }
            else
            {
                int count = 0;
                Point newPos = new Point(lastPos.X, lastPos.Y);
                newPos.Y = node.Depth * _nodeDepth;

                if (direction == BinaryTreeDrawerDirection.Left)
                {
                    count = 1 + WalkNode(node.Right);
                    newPos.X -= (count * 2) * _nodeToNodeDistance;
                }
                else
                {
                    count = 1 + WalkNode(node.Left);
                    newPos.X += (count * 2) * _nodeToNodeDistance;
                }

                if (newPos.X > _maxImageSize.Width) _maxImageSize.Width = newPos.X;
                if (newPos.Y > _maxImageSize.Height) _maxImageSize.Height = newPos.Y;

                if (newPos.X < _minImageSize.Width) _minImageSize.Width = newPos.X;
                if (newPos.Y < _minImageSize.Height) _minImageSize.Height = newPos.Y;

                Pen pen = new Pen(_nodeToNodeLineColor);
                Point p1 = new Point(lastPos.X + (_nodeSize.Width / 2), lastPos.Y + _nodeSize.Height);
                Point p2 = new Point(newPos.X + (_nodeSize.Width / 2), newPos.Y);
                _gr.DrawLine(pen, p1, p2);

                DrawNode(newPos, _nodeSize, node);
                if (node.Left != null) Draw(node.Left, newPos, BinaryTreeDrawerDirection.Left);
                if (node.Right != null) Draw(node.Right, newPos, BinaryTreeDrawerDirection.Right);

            }

            return;
        }

        private int WalkNode(BinaryTreeNode<T> node)
        {
            int count = 0;
            if (node != null)
            {
                count = 1;
                if (node.Left != null) count += WalkNode(node.Left);
                if (node.Right != null) count += WalkNode(node.Right);
            }
            return count;
        }

        private void FindLeftCount(BinaryTreeNode<T> node, ref int rCount, ref int lCount)
        {
            if (node == null)
            {
                return;
            }

            if (node.Left != null)
            {
                lCount++;
                FindLeftCount(node.Left, ref rCount, ref lCount);
            }

            if (node.Right != null)
            {
                FindLeftCount(node.Right, ref lCount, ref rCount);
            }
            return;
        }

        private void FindRightCount(BinaryTreeNode<T> node, ref int rCount, ref int lCount)
        {
            if (node == null)
            {
                return;
            }

            if (node.Right != null)
            {
                rCount++;
                FindRightCount(node.Right, ref rCount, ref lCount);
            }

            if (node.Left != null)
            {
                int rCount2 = 0;
                FindRightCount(node.Left, ref rCount2, ref lCount);
                if (rCount2 > rCount)
                    rCount = rCount2;
            }
        }

        private void DrawNode(Point pos, Size size, BinaryTreeNode<T> node)
        {
            // inner circle
            Size fillSize = new Size(size.Width, size.Height);
            Point fillPos = new Point(pos.X + 2, pos.Y + 2);
            Rectangle fillRect = new Rectangle(fillPos, fillSize);
            _gr.FillEllipse(_nodeFillColor, fillRect);

            // outer circle
            Pen pen = new Pen(_nodeLineColor);
            Rectangle outerRect = new Rectangle(pos, size);
            _gr.DrawEllipse(pen, outerRect);

            try
            {
                // text
                PointF textPos = new PointF(pos.X + 2, pos.Y + 5);
                //string text = string.Format("{0} ({1},{2}) {3}", node.value, textPos.X, textPos.Y, node.offset);
                string text = string.Format("{0}", node.Data);
                Font f = new Font(FontFamily.GenericSerif, 11);
                _gr.DrawString(text, f, _nodeTextColor, textPos);
                f.Dispose();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("ex:" + ex.Message);
            }

        }
    }
}


