using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace DataStructuresDemo
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            //DataStructures.BinaryTreeTest t = new DataStructures.BinaryTreeTest();
            //t.TestOnWalkLeftLoadedTree();

            //DataStructures.SimpleGeneric t = new DataStructures.SimpleGeneric();
            //t.Run();

            //DataStructures.GenericCollection t = new DataStructures.GenericCollection();
            //t.Run();

            //DataStructures.TestList t = new DataStructures.TestList();
            //t.Run();

            //DataStructures.Generic.TestBinaryTree t = new DataStructures.Generic.TestBinaryTree();
            //t.Run();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new BinaryTreeDemo());
        }
    }
}