using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DataStructures;

namespace DataStructuresDemo
{
    public partial class BinaryTreeDemo : Form
    {
        BinaryTree<int> binaryTree;
        
        public BinaryTreeDemo()
        {
            InitializeComponent();
        }

        private void BinaryTreeForm_Load(object sender, EventArgs e)
        {
            Sample2();
        }
        
        private void cmdAdd_Click(object sender, EventArgs e)
        {
            try
            {
                AddIt(Convert.ToInt32(txtValue.Text));
//                AddIt(txtValue.Text);
            }
            catch
            {
                MessageBox.Show("Invalid value entered. Please enter a number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            txtValue.Text = "";
            txtValue.Focus();
        }

        private void cmdRandom_Click(object sender, EventArgs e)
        {
            try
            {
                Random r = new Random();
                int howMany = Convert.ToInt32(txtRandom.Text);
                for (int i = 0; i < howMany; i++)
                {
                    AddIt(r.Next(1000));
                }
                //GraphIt();
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid value entered. Please enter a positive number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);            
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            txtRandom.Text = "";
            txtRandom.Focus();

        }

        //private void AddIt(string value)
        //{
        //    binaryTree.Add(value);
        //    listUnsorted.Items.Add(value);
        //    lblStatus.Text = string.Format("Total Elements:{0}", listUnsorted.Items.Count);
        //}

        private void AddIt(int value)
        {
            binaryTree.Add(value);
            listUnsorted.Items.Add(value);
            lblStatus.Text = string.Format("Total Elements:{0}", listUnsorted.Items.Count);
        }
        
        private void OnNodeWalkedInOrder(BinaryTreeNode<int> node, BinaryTreeNode<int> parent)
        {
            listSorted.Items.Add(node.Data);
        }
        
        private void ResetTree()
        {
            binaryTree = new BinaryTree<int>();
            binaryTree.onNodeWalkedInOrder = OnNodeWalkedInOrder;   // method group conversion syntax
            listUnsorted.Items.Clear();
            listSorted.Items.Clear();
            lblStatus.Text = string.Format("Total Elements:{0}", listUnsorted.Items.Count);
        }

        private void GraphIt()
        {
            GraphForm gf = new GraphForm();
            gf.Image = DrawImage(binaryTree, gf.CreateGraphics());
            gf.Show();
        }

        public Image DrawImage(BinaryTree<int> Tree, Graphics g0)
        {
            BinaryTreeDrawer<int> drawer = new BinaryTreeDrawer<int>();

            // first shot - just to get the size of the image
            Image i = new Bitmap(100, 100, g0);
            Graphics g1 = Graphics.FromImage(i);
            Size size;
            Point pos = new Point(50, 25);
            drawer.Draw(Tree, g1, ref pos, out size);

            // second shot - draw it for real
            Image i2 = new Bitmap(size.Width, size.Height, g0);
            Graphics g2 = Graphics.FromImage(i2);
            Rectangle rect = new Rectangle(new Point(0, 0), size);
            g2.FillRectangle(Brushes.White, rect);
            drawer.Draw(Tree, g2, ref pos, out size);
            return i2;
        }

        /* 
         * Samples 
         */
        private void Sample1()
        {
            ResetTree();
            int[] values = { 100, 50, 180, 40, 60, 61, 62, 63, 150, 200 };
            AddArrayToTree(values);
        }

        private void Sample2()
        {
            ResetTree();
            int[] values = { 10, 1, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 14, 13, 12, 11, 2, 3, 4, 9, 6, 7, 2 };
            AddArrayToTree(values);
        }

        private void Sample3()
        {
            ResetTree();
            int[] values = { 100, 50, 150, 25, 75, 12, 40, 60, 90 };
            AddArrayToTree(values);
        }

        private void Sample4()
        {
            ResetTree();
            int[] values = { 50, 25, 75, 40, 60 };
            AddArrayToTree(values);
        }

        private void AddArrayToTree(int[] values)
        {
            for (int i = 0; i < values.Length; i++)
            {
                AddIt(values[i]);
            }
        }
        
        /* 
         * Toolbar and menu 
         */
        private void cmdClear_Click(object sender, EventArgs e)
        {
            ResetTree();
        }

        private void cmdSortX_Click(object sender, EventArgs e)
        {
            listSorted.Items.Clear();
            binaryTree.WalkInOrder();
        }

        private void cmdGraphX_Click(object sender, EventArgs e)
        {
            GraphIt();
        }
        
        private void mnuFileSample1_Click(object sender, EventArgs e)
        {
            Sample1();
        }

        private void mnuFileSample2_Click(object sender, EventArgs e)
        {
            Sample2();
        }

        private void mnuFileSample3_Click(object sender, EventArgs e)
        {
            Sample3();
        }

        private void mnuFileSample4_Click(object sender, EventArgs e)
        {
            Sample4();
        }

        private void mnuFileExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void mnuEditClear_Click(object sender, EventArgs e)
        {
            ResetTree();
        }

        private void mnuViewGraph_Click(object sender, EventArgs e)
        {
            GraphIt();
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ShowAbout();
        }

        private void ShowAbout()
        {
            AboutForm f = new AboutForm();
            f.ShowDialog();
        }
    }
}