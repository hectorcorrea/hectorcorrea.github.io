using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
//using DataStructures.Generic;

namespace DataStructuresDemo
{
    public partial class GraphForm : Form 
    {
        private bool _needRepaint = false;
        private string _imageFile = null;
        private Image _image = null;

        public Image Image
        {
            get 
            { 
                return _image; 
            }

            set
            {
                _image = value;
                RepaintImage();
            }
        }

        public GraphForm()
        {
            InitializeComponent();
        }

        private void GraphForm_Load(object sender, EventArgs e)
        {
            pictureBox1.Left = 0;
            pictureBox1.Top = 0;
            RepaintImage();
        }

        private void GraphForm_Paint(object sender, PaintEventArgs e)
        {
            if (_needRepaint)
            {
                RepaintImageCore();
            }
        }

        private void RepaintImageCore()
        {
            _needRepaint = false;
            if (_image != null)
            {
                _imageFile = NextFileName(Application.StartupPath + @"\binarytree_", ".png");
                _image.Save(_imageFile);
                pictureBox1.Image = _image;
                pictureBox1.Width = pictureBox1.Image.Width;
                pictureBox1.Height = pictureBox1.Image.Height;
            }
        }

        private void RepaintImage()
        {
            _needRepaint = true;
            this.Invalidate(true);
        }

        private string NextFileName(string baseName, string ext)
        {
            int sequence = 0;
            string nextFileName;
            while(true)
            {
                sequence++;
                nextFileName = baseName + sequence.ToString() + ext;
                if (!System.IO.File.Exists(nextFileName))
                {
                    break;
                }
            }
            return nextFileName;
        }

        private void NormalGraph()
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Normal;
            pictureBox1.Width = pictureBox1.Image.Width;
            pictureBox1.Height = pictureBox1.Image.Height; 
            RepaintImage();
        }

        private void StretchGraph()
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.Width = this.Width;
            pictureBox1.Height = this.Height;
            RepaintImage();
        }

        private void ZoomGraph()
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.Width = this.Width;
            pictureBox1.Height = this.Height;
            RepaintImage();
        }

        private void SaveGraph()
        {
            saveFileDialog1.FileName = "MyGraph";
            saveFileDialog1.Filter = "Portable Network Graphics files (*.png)|*.png";
            saveFileDialog1.DefaultExt = "png";
            saveFileDialog1.Title = "Save Graph As";
            DialogResult r = saveFileDialog1.ShowDialog();
            if (r == DialogResult.OK)
            {
                pictureBox1.Image.Save(saveFileDialog1.FileName);
            }
        }

        private void GraphForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (System.IO.File.Exists(_imageFile))
            {
                try
                {
                    System.IO.File.Delete(_imageFile);
                }
                catch 
                {   
                    // ignore it 
                }
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void normalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NormalGraph();
        }

        private void stretchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StretchGraph();
        }

        private void zoomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ZoomGraph();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveGraph();
        }
      
    }
}