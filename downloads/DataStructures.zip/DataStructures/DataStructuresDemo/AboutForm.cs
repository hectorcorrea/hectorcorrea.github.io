using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace DataStructuresDemo
{
    public partial class AboutForm : Form
    {
        public AboutForm()
        {
            InitializeComponent();
        }

        private void cmdOK_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AboutForm_Load(object sender, EventArgs e)
        {
            lblAbout1.Text = "This program is part of the Data Structures series that I posted in June/2006.";
            lblAbout2.Text = "For more information visit: ";
            linkAbout.Text = "http://hectorcorrea.com/datastructures.htm";
        }

        private void linkAbout_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(linkAbout.Text);
        }
    }
}