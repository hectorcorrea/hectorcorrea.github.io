Unzip this file to a folder called:
	C:\CodeDownloadDemo. 

Using IIS, create a new Virtual Directory. Name it CodeDownloadDemo and point it to your C:\CodeDownloadDemo\Loader\bin folder. 

Using VS.NET, open Loader Solution located in C:\CodeDownloadDemo\Loader\Loader.sln 

Enjoy it!
Hector Correa
hector@hectorcorrea.com
August/2002

 
