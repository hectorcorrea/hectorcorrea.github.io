Imports System.Data.SqlClient
Imports System.Data

Public Class EmployeeForm
    Inherits System.Windows.Forms.Form

    Public DataConn As String
    Public CodeConn As String
    Dim Version As Integer

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents ButtonLoadData As System.Windows.Forms.Button
    Friend WithEvents EmployeesGrid As System.Windows.Forms.DataGrid
    Friend WithEvents DataGridTableStyle1 As System.Windows.Forms.DataGridTableStyle
    Friend WithEvents DataGridTextBoxColumn2 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn3 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents DataGridTextBoxColumn4 As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents LabelVersion As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.LabelVersion = New System.Windows.Forms.Label()
        Me.ButtonLoadData = New System.Windows.Forms.Button()
        Me.EmployeesGrid = New System.Windows.Forms.DataGrid()
        Me.DataGridTableStyle1 = New System.Windows.Forms.DataGridTableStyle()
        Me.DataGridTextBoxColumn2 = New System.Windows.Forms.DataGridTextBoxColumn()
        Me.DataGridTextBoxColumn3 = New System.Windows.Forms.DataGridTextBoxColumn()
        Me.DataGridTextBoxColumn4 = New System.Windows.Forms.DataGridTextBoxColumn()
        CType(Me.EmployeesGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LabelVersion
        '
        Me.LabelVersion.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.LabelVersion.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelVersion.Location = New System.Drawing.Point(9, 9)
        Me.LabelVersion.Name = "LabelVersion"
        Me.LabelVersion.Size = New System.Drawing.Size(363, 37)
        Me.LabelVersion.TabIndex = 0
        Me.LabelVersion.Text = "Version N"
        Me.LabelVersion.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'ButtonLoadData
        '
        Me.ButtonLoadData.Anchor = (System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right)
        Me.ButtonLoadData.Location = New System.Drawing.Point(298, 169)
        Me.ButtonLoadData.Name = "ButtonLoadData"
        Me.ButtonLoadData.TabIndex = 1
        Me.ButtonLoadData.Text = "Load Data"
        '
        'EmployeesGrid
        '
        Me.EmployeesGrid.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.EmployeesGrid.CaptionText = "Employees"
        Me.EmployeesGrid.DataMember = ""
        Me.EmployeesGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.EmployeesGrid.Location = New System.Drawing.Point(3, 57)
        Me.EmployeesGrid.Name = "EmployeesGrid"
        Me.EmployeesGrid.Size = New System.Drawing.Size(370, 106)
        Me.EmployeesGrid.TabIndex = 2
        Me.EmployeesGrid.TableStyles.AddRange(New System.Windows.Forms.DataGridTableStyle() {Me.DataGridTableStyle1})
        '
        'DataGridTableStyle1
        '
        Me.DataGridTableStyle1.DataGrid = Me.EmployeesGrid
        Me.DataGridTableStyle1.GridColumnStyles.AddRange(New System.Windows.Forms.DataGridColumnStyle() {Me.DataGridTextBoxColumn2, Me.DataGridTextBoxColumn3, Me.DataGridTextBoxColumn4})
        Me.DataGridTableStyle1.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.DataGridTableStyle1.MappingName = "employees"
        '
        'DataGridTextBoxColumn2
        '
        Me.DataGridTextBoxColumn2.Format = ""
        Me.DataGridTextBoxColumn2.FormatInfo = Nothing
        Me.DataGridTextBoxColumn2.HeaderText = "Last name"
        Me.DataGridTextBoxColumn2.MappingName = "lastname"
        Me.DataGridTextBoxColumn2.Width = 80
        '
        'DataGridTextBoxColumn3
        '
        Me.DataGridTextBoxColumn3.Format = ""
        Me.DataGridTextBoxColumn3.FormatInfo = Nothing
        Me.DataGridTextBoxColumn3.HeaderText = "First name"
        Me.DataGridTextBoxColumn3.MappingName = "firstname"
        Me.DataGridTextBoxColumn3.Width = 80
        '
        'DataGridTextBoxColumn4
        '
        Me.DataGridTextBoxColumn4.Format = ""
        Me.DataGridTextBoxColumn4.FormatInfo = Nothing
        Me.DataGridTextBoxColumn4.HeaderText = "Home phone #"
        Me.DataGridTextBoxColumn4.MappingName = "homephone"
        Me.DataGridTextBoxColumn4.Width = 90
        '
        'ClientForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(376, 194)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.EmployeesGrid, Me.ButtonLoadData, Me.LabelVersion})
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ClientForm"
        Me.Text = "Employees Form"
        CType(Me.EmployeesGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ButtonLoadData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonLoadData.Click

        If Version = 1 Then
            MessageBox.Show("Feature not yet implemented", "Sorry")
        Else
            Dim EmpData As DataSet
            EmpData = GetEmployeeList(DataConn)
            EmployeesGrid.DataSource = EmpData.Tables("employees")
        End If

    End Sub

    Protected Shared Function GetEmployeeList(ByRef DataConn As String) As DataSet
        Dim Conn As SqlConnection
        Dim Sql As String
        Dim da As SqlDataAdapter
        Dim ds As New DataSet()

        Try
            ' Define SQL statement.
            Sql = "select * from employees"

            ' Go get them!
            Conn = ConnectToDB(DataConn)
            If Not IsNothing(Conn) Then
                da = New SqlDataAdapter(Sql, Conn)
                da.Fill(ds, "employees")
            End If
            Conn.Close()
        Catch ex As Exception
            System.Windows.Forms.MessageBox.Show(ex.ToString)
        End Try

        Return ds
    End Function

    Protected Shared Function ConnectToDB(ByRef DataConn As String) As SqlConnection
        Dim Conn As SqlConnection

        If DataConn Is Nothing Or DataConn.Length = 0 Then
            Return Nothing
        End If

        Try
            Conn = New SqlConnection(DataConn)
            Conn.Open()
        Catch ex As Exception
            Conn = Nothing
        End Try

        Return Conn

    End Function

    Protected Overrides Sub OnLoad(ByVal e As System.EventArgs)
        Version = 2
        Me.Version.ToString()
        LabelVersion.Text = "Version " + Version.ToString()
    End Sub
End Class
