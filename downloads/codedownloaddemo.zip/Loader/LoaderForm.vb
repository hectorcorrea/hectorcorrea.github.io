Imports System.Reflection

Public Class LoaderForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents HelpAbout As System.Windows.Forms.MenuItem
    Friend WithEvents FileExit As System.Windows.Forms.MenuItem
    Friend WithEvents FileLoadForm As System.Windows.Forms.MenuItem
    Friend WithEvents FileSettings As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.FileLoadForm = New System.Windows.Forms.MenuItem()
        Me.FileSettings = New System.Windows.Forms.MenuItem()
        Me.MenuItem5 = New System.Windows.Forms.MenuItem()
        Me.FileExit = New System.Windows.Forms.MenuItem()
        Me.MenuItem2 = New System.Windows.Forms.MenuItem()
        Me.HelpAbout = New System.Windows.Forms.MenuItem()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FileLoadForm, Me.FileSettings, Me.MenuItem5, Me.FileExit})
        Me.MenuItem1.Text = "&File"
        '
        'FileLoadForm
        '
        Me.FileLoadForm.Index = 0
        Me.FileLoadForm.Text = "&Load Form"
        '
        'FileSettings
        '
        Me.FileSettings.Index = 1
        Me.FileSettings.Text = "Settings"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 2
        Me.MenuItem5.Text = "-"
        '
        'FileExit
        '
        Me.FileExit.Index = 3
        Me.FileExit.Text = "E&xit"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.HelpAbout})
        Me.MenuItem2.Text = "&Help"
        '
        'HelpAbout
        '
        Me.HelpAbout.Index = 0
        Me.HelpAbout.Text = "&About"
        '
        'LoaderForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(433, 266)
        Me.IsMdiContainer = True
        Me.Menu = Me.MainMenu1
        Me.Name = "LoaderForm"
        Me.Text = "Loader Application"

    End Sub

#End Region

    Dim DataConn As String
    Dim CodeConn As String

    Protected Overrides Sub OnLoad(ByVal e As System.EventArgs)
        Me.DataConn = "server=(local);database=northwind;Trusted_Connection=Yes"
        'Me.CodeConn = "http://localhost/codedownloaddemo/"
        Me.CodeConn = "http://127.0.0.1/codedownloaddemo/"
    End Sub

    Private Sub LoadApp(ByRef AssemblyURL As String, ByRef ClassName As String)

        Try

            'Load assembly (DLL/EXE) requested from URL
            Dim a As [Assembly] = [Assembly].LoadFrom(AssemblyURL)

            'Get class type
            Dim t As Type = a.GetType(ClassName)

            'Create an instance of the class (form) requested.
            Dim o As Object = Activator.CreateInstance(t)

            Try
                ' set data connection string
                o.DataConn = DataConn
            Catch e As Exception
                ' ignore error
            End Try

            Try
                ' set code connection url
                o.CodeConn = CodeConn
            Catch e As Exception
                ' ignore error
            End Try

            If Me.IsMdiContainer Then
                o.MdiParent = Me
            End If
            o.Show()

        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try

    End Sub

    Private Sub FileExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileExit.Click
        Application.Exit()
    End Sub

    Private Sub FileLoadForm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileLoadForm.Click
        ' URL = "http://localhost/codedownloaddemo/modulea.dll"
        Dim URL As New String(CodeConn + "modulea.dll")
        LoadApp(URL, "ModuleA.EmployeeForm")
    End Sub

    Private Sub HelpAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelpAbout.Click
        Dim About As New AboutForm()
        About.ShowDialog()
    End Sub

    Private Sub FileSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileSettings.Click
        Dim Settings As New SettingsForm()
        Settings.InitValues(DataConn, CodeConn)
        Settings.ShowDialog()
    End Sub
End Class