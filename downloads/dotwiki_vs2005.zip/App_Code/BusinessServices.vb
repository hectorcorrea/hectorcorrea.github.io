' description:  Business services for DotWiki project.
' author:       Sept/2002 - hector@hectorcorrea.com 
' updated:      

Imports System.Data.SqlClient
Imports DotWiki.DataServices
'Imports System.Configuration.ConfigurationSettings
Imports System.Configuration.ConfigurationManager
Imports System.Text.RegularExpressions


Namespace DotWiki


    Public Class BusinessServices

        Const Quote As Char = Chr(34)

        Public Shared Sub AddPictureToTopic(ByRef TopicName As String, _
        ByRef Picture As String)

            Dim TopicContent As String
            TopicContent = ReadTopic(TopicName, "")
            TopicContent += vbCrLf + "<img src=" + Picture + " border=1/>"

            SaveTopic(TopicName, TopicContent)

        End Sub

        Public Shared Function Search(ByVal SearchString As String) As DataSet

            Dim SearchMethod As String = AppSettings("SearchMethod")

            ' If search string is empty, return all topics.
            ' (We might want to prevent this in the future)
            If SearchString Is Nothing Then
                Return SearchAll(RootObject.WikiSet)
            End If

            SearchString = SearchString.Trim()
            If SearchString.Length = 0 Then
                Return SearchAll(RootObject.WikiSet)
            End If

            ' Do the actual search
            Select Case SearchMethod.ToUpper()
                Case "FULLTEXT"
                    Return SearchFullText(SearchString, RootObject.WikiSet)
                Case "FULLTEXTWITHRANKS"
                    Return SearchFullTextWithRanking(SearchString, RootObject.WikiSet)
                Case Else
                    Return SearchNormal(SearchString, RootObject.WikiSet)
            End Select
        End Function

        Public Shared Function SearchFullTextWithRanking(ByVal SearchString As String, ByVal WikiSet As String) As DataSet
            ' To do: Actually implement this method.
            ' For now, just use other full text search method.
            Return SearchFullText(SearchString, WikiSet)

            ' Here is a sample SQL SELECT that uses FreeTextTable
            'select name, content, rank
            'from topic 
            'inner join freetexttable( topic, *, 'wiki diagram' ) as ft on topic.topicpk = ft.[key]
            'order by rank

        End Function

        Public Shared Function SearchFullText(ByVal SearchString As String, ByVal WikiSet As String) As DataSet

            Dim ds As DataSet = Nothing
            Dim oConn As SqlConnection
            oConn = ConnectToDB()
            If Not IsNothing(oConn) Then
                Try

                    ' Build a where clause with the following format:
                    '   contains( *, 'FormsOf( inflectional, "word1" ) and FormsOf( inflectional, "word2" )' )
                    Dim WhereClause As String
                    WhereClause = "contains( *, '"

                    Dim Words() As String
                    Words = Split(SearchString, " ")
                    For i As Integer = 0 To Words.Length - 1
                        Dim SearchTerm As String
                        SearchTerm = "FormsOf( inflectional, " + Quote + Words(i) + Quote + ") "
                        If i < Words.Length - 1 Then
                            SearchTerm += " AND "
                        End If
                        WhereClause += SearchTerm
                    Next

                    WhereClause += "' )"

                    Dim sc As New SqlCommand
                    sc.Connection = oConn
                    sc.Parameters.AddWithValue("@WikiSet", WikiSet)
                    sc.CommandText = "select name, updatedon " + _
                                    "from topic " + _
                                    "where wikiset = @WikiSet and " + _
                                    WhereClause + " " + _
                                    "order by name"

                    Dim da As New SqlDataAdapter(sc)
                    ds = New DataSet
                    da.Fill(ds, "topic")
                    ds.Tables(0).Columns(0).Caption = "Name"
                    ds.Tables(0).Columns(1).Caption = "Updated On"

                Catch ex As Exception
                    ' to do: tell the user that something went wrong
                    ' (e.g. maybe the user entered only non-searchable words, like "the")
                Finally
                    oConn.Close()
                End Try
            Else
                Throw New Exception("Could not connect to the database")
            End If
            Return ds

        End Function

        Public Shared Function SearchNormal(ByVal SearchString As String, ByVal WikiSet As String) As DataSet

            Dim ds As DataSet
            Dim oConn As SqlConnection
            oConn = ConnectToDB()
            If Not IsNothing(oConn) Then
                Try

                    ' Make sure there are no wildcards embedded in the search string 
                    ' that can mess up our LIKE statement below.
                    SearchString = SearchString.Replace("%", "")
                    SearchString = SearchString.Replace("[", "")
                    SearchString = SearchString.Replace("]", "")
                    SearchString = SearchString.Replace("_", "")
                    SearchString = SearchString.Replace("^", "")

                    Dim sc As New SqlCommand
                    sc.Connection = oConn
                    sc.Parameters.AddWithValue("@WikiSet", WikiSet)
                    sc.Parameters.AddWithValue("@SearchString", "%" + SearchString + "%")
                    sc.CommandText = "SELECT name, updatedon " + _
                        "FROM " + _
                        "( " + _
                        "    SELECT name, updatedon, 100 AS rank " + _
                        "    FROM topic " + _
                        "    WHERE wikiset = @WikiSet AND name LIKE @SearchString " + _
                        "    UNION " + _
                        "    SELECT name, updatedon, 50 AS rank " + _
                        "    FROM topic " + _
                        "    WHERE wikiset = @WikiSet AND content LIKE @SearchString " + _
                        ") topics " + _
                        "GROUP BY name, updatedon " + _
                        "ORDER BY SUM(rank) DESC, name"

                    Dim da As New SqlDataAdapter(sc)
                    ds = New DataSet
                    da.Fill(ds, "topic")
                    ds.Tables(0).Columns(0).Caption = "Name"
                    ds.Tables(0).Columns(1).Caption = "Updated On"

                Finally
                    oConn.Close()
                End Try
            Else
                Throw New Exception("Could not connect to the database")
            End If
            Return ds

        End Function

        Public Shared Function SearchAll(ByVal WikiSet As String) As DataSet
            Dim ds As DataSet
            Dim oConn As SqlConnection
            oConn = ConnectToDB()
            If Not IsNothing(oConn) Then
                Try
                    Dim sc As New SqlCommand
                    sc.Connection = oConn
                    sc.Parameters.AddWithValue("@WikiSet", WikiSet)
                    sc.CommandText = "select name, updatedon " + _
                                    "from topic " + _
                                    "where wikiset = @WikiSet " + _
                                    "order by name"
                    Dim da As New SqlDataAdapter(sc)
                    ds = New DataSet
                    da.Fill(ds, "topic")
                    ds.Tables(0).Columns(0).Caption = "Name"
                    ds.Tables(0).Columns(1).Caption = "Updated On"
                Finally
                    oConn.Close()
                End Try
            Else
                Throw New Exception("Could not connect to the database")
            End If
            Return ds
        End Function

        '   Function to check if a topic exists.
        Public Shared Function CheckTopicExists(ByVal Topic As String) As Boolean
            Dim oConn As SqlConnection

            oConn = ConnectToDB()
            If Not IsNothing(oConn) Then
                Try
                    Dim sc As New SqlCommand
                    sc.Connection = oConn
                    sc.Parameters.AddWithValue("@TopicName", Topic)
                    sc.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet)
                    sc.CommandText = "select 'true' as TopicExists from topic " + _
                                     "where name = @TopicName and wikiset = @WikiSet"
                    CheckTopicExists = CType(sc.ExecuteScalar(), Boolean)
                Finally
                    oConn.Close()
                End Try
            Else
                CheckTopicExists = False
            End If

            Return CheckTopicExists

        End Function

        Public Shared Function GetIndexDS() As DataSet
            ' Index page currently displays all topics. Eventually
            ' we'll probably need to break down the topics by some
            ' criteria (by letter)
            Return SearchAll(RootObject.WikiSet)
        End Function

        Public Shared Function GetRecentChangesDS(ByVal Days As Integer) As DataSet
            Dim ds As DataSet
            Dim oConn As SqlConnection
            oConn = ConnectToDB()
            If Not IsNothing(oConn) Then
                Try
                    Dim sc As New SqlCommand
                    sc.Connection = oConn
                    sc.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet)
                    sc.Parameters.AddWithValue("@Days", Days)
                    sc.CommandText = _
                        "select name, updatedon " + _
                        "from topic " + _
                        "where wikiset = @WikiSet and " + _
                        "DateDiff(d, updatedon, getdate()) <= @Days " + _
                        "order by updatedon desc"

                    Dim da As New SqlDataAdapter(sc)
                    ds = New DataSet
                    da.Fill(ds, "topic")
                    ds.Tables(0).Columns(0).Caption = "Name"
                    ds.Tables(0).Columns(1).Caption = "Updated On"
                Finally
                    oConn.Close()
                End Try
            Else
                Throw New Exception("Could not connect to the database.")
            End If
            Return ds
        End Function

        Public Shared Function ReadTopicHistory(ByRef PK As String, _
                                                ByRef DateTime As String) As String
            Dim oConn As SqlConnection
            Dim TopicContent As String

            oConn = ConnectToDB()
            If Not IsNothing(oConn) Then
                Try
                    Dim sc As New SqlCommand
                    sc.Connection = oConn
                    sc.Parameters.AddWithValue("@PK", PK)
                    sc.CommandText = "select content, updatedon from topichistory where topichistorypk = @PK"
                    Dim da As New SqlDataAdapter(sc)
                    Dim ds As New DataSet
                    da.Fill(ds, "topichistory")
                    If ds.Tables(0).Rows.Count <> 1 Then
                        Throw New System.Exception("Incorrect number of records found in topichistory")
                    End If
                    TopicContent = CType(ds.Tables(0).Rows(0).Item("content"), String)
                    DateTime = CType(ds.Tables(0).Rows(0).Item("updatedon"), String)
                Finally
                    oConn.Close()
                End Try
            Else
                TopicContent = ""
                DateTime = ""
            End If

            Return TopicContent

        End Function

        Public Shared Function ReadTopic(ByRef TopicName As String, ByRef UpdatedOn As String) As String
            Dim oConn As SqlConnection
            Dim TopicContent As String

            oConn = ConnectToDB()
            If Not IsNothing(oConn) Then
                Try
                    Dim sc As New SqlCommand
                    sc.Connection = oConn
                    sc.Parameters.AddWithValue("@TopicName", TopicName)
                    sc.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet)
                    sc.CommandText = "select content, updatedon from topic " + _
                                     "where name = @TopicName and wikiset = @WikiSet"

                    Dim da As New SqlDataAdapter(sc)
                    Dim ds As New DataSet
                    da.Fill(ds)
                    If ds.Tables.Count <> 1 Then
                        Throw New Exception("unexpected number of tables")
                    ElseIf ds.Tables(0).Rows.Count = 0 Then
                        TopicContent = ""
                        UpdatedOn = ""
                    ElseIf ds.Tables(0).Rows.Count = 1 Then
                        TopicContent = CType(ds.Tables(0).Rows(0)(0), String)
                        UpdatedOn = "Updated on: " & ds.Tables(0).Rows(0)(1)
                    Else
                        Throw New Exception("unexpected number of topics found")
                    End If

                Catch
                    TopicContent = "<p class=dotwikierror>Error reading topic: " & TopicName & ".</p>"
                    UpdatedOn = ""
                Finally
                    oConn.Close()
                End Try
            Else
                Dim setting As String = "<font face=""Courier New"">ConnectionString</font>"
                Dim webConfig As String = "<font face=""Courier New"">web.config</font>"
                TopicContent = String.Format("<p><font color=""Red"">Error connecting to the database.</font></p>" & _
                    "<p>Make sure the values specified in the {0} setting of the {1} file " & _
                    "are correct for your server.</p>" & _
                    "<p>The most common reason for this error is that one or more of the " & _
                    "values in the {0} (server, database, uid, or pwd) don't match with " & _
                    "your server's settings.</p>" & _
                    "<p>Correct the {0} settings in your {1} and run the DotWiki again.</p>" & _
                    "<p>If this error persists, make sure you can connect to the DotWiki database " & _
                    "(using the credentials specified in the {0} setting) with a tool like " & _
                    "SQL Server Management Studio or SQL Query Analyzer.</p>", setting, webConfig)
                UpdatedOn = ""
            End If

            Return TopicContent

        End Function

        Public Shared Function ReadTopicPictures(ByRef TopicName As String) As String

            Dim TopicPictures As String = ""
            Dim TopicContent As String = ReadTopic(TopicName, "")
            Dim match As Match

            Dim Thumbnails As MatchCollection = Regex.Matches(TopicContent, "\<thumbnail=.+?\>")
            For Each match In Thumbnails
                Dim item As String = match.Value.Substring(11)
                If TopicPictures.Length > 0 Then
                    TopicPictures += "|"
                End If
                TopicPictures += item.Substring(0, item.Length - 1)
            Next

            Dim Pictures As MatchCollection = Regex.Matches(TopicContent, "\<img.*?src=.+?\>")
            For Each match In Pictures
                Try
                    Dim match2 As Match = Regex.Match(match.Value, "src=[\""]*.*?[\""|\s|\>]")
                    Dim fileName As String = match2.Value.Substring(4)
                    fileName = fileName.Replace("""", "").Trim()
                    fileName = fileName.Replace("\", "/")
                    fileName = fileName.Replace("_thumb.", ".")
                    If TopicPictures.Length > 0 Then
                        TopicPictures += "|"
                    End If
                    TopicPictures += fileName
                Catch ex As Exception
                    ' ignore the error/ignore this picture
                    ' TODO: log the error somewhere
                End Try
            Next

            Return TopicPictures

        End Function

        Public Shared Function SaveTopic(ByRef TopicPK As Guid, _
                                ByRef TopicName As String, _
                                ByRef TopicContent As String) As String
            Dim oConn As SqlConnection
            Dim RetVal As String = ""

            If AppSettings.Item("AllowEdit") <> "true" Then
                Return "no changes allowed"
            End If

            oConn = ConnectToDB()
            If Not IsNothing(oConn) Then

                Try
                    Dim sc As New SqlCommand
                    sc.Connection = oConn
                    sc.Parameters.AddWithValue("@TopicPK", TopicPK.ToString())
                    sc.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet)
                    sc.CommandText = "select content, name, topicpk, updatedon, wikiset " + _
                                     "from topic " + _
                                     "where topicpk = @TopicPK"

                    Dim da As New SqlDataAdapter(sc)
                    Dim cb As New SqlCommandBuilder(da)
                    Dim ds As New DataSet
                    da.Fill(ds, "topic")
                    If ds.Tables("topic").Rows.Count = 0 Then
                        Throw New Exception("Topic PK not found")
                    Else
                        BackupTopic(TopicPK.ToString(), oConn)
                    End If
                    ds.Tables("topic").Rows(0).Item("name") = TopicName
                    ds.Tables("topic").Rows(0).Item("content") = TopicContent
                    ds.Tables("topic").Rows(0).Item("updatedon") = Date.Now()
                    da.Update(ds, "topic")

                Catch e As Exception
                    RetVal = e.Message
                Finally
                    oConn.Close()
                End Try

            Else
                RetVal = "Could not connect to database"
            End If

            Return RetVal
        End Function

        Public Shared Function SaveTopic(ByRef TopicName As String, _
                                        ByRef TopicContent As String) As String
            Dim oConn As SqlConnection
            Dim RetVal As String = ""

            If AppSettings.Item("AllowEdit") <> "true" Then
                Return "no changes allowed"
            End If

            oConn = ConnectToDB()
            If Not IsNothing(oConn) Then

                Try
                    Dim sc As New SqlCommand
                    sc.Connection = oConn
                    sc.Parameters.AddWithValue("@TopicName", TopicName)
                    sc.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet)
                    sc.CommandText = "select content, name, topicpk, updatedon, wikiset " + _
                                     "from topic " + _
                                     "where name = @TopicName and wikiset = @WikiSet"

                    Dim da As New SqlDataAdapter(sc)
                    Dim cb As New SqlCommandBuilder(da)
                    Dim ds As New DataSet
                    da.Fill(ds, "topic")
                    If ds.Tables("topic").Rows.Count = 0 Then
                        ' new topic
                        Dim NewRow As DataRow
                        NewRow = ds.Tables("topic").NewRow()
                        ds.Tables("topic").Rows.Add(NewRow)
                        ds.Tables("topic").Rows(0).Item("name") = TopicName
                        ds.Tables("topic").Rows(0).Item("wikiset") = RootObject.WikiSet
                    Else
                        BackupTopic(ds.Tables("topic").Rows(0).Item("topicpk").ToString(), oConn)
                    End If
                    ds.Tables("topic").Rows(0).Item("content") = TopicContent
                    ds.Tables("topic").Rows(0).Item("updatedon") = Date.Now()
                    da.Update(ds, "topic")

                Catch e As Exception
                    RetVal = e.Message
                Finally
                    oConn.Close()
                End Try

            Else
                RetVal = "Could not connect to database"
            End If

            Return RetVal
        End Function

        Public Shared Sub BackupTopic(ByRef TopicPK As String, ByRef oConn As SqlConnection) 'As String
            Dim sc As New SqlCommand
            sc.Parameters.AddWithValue("@TopicPK", TopicPK)
            sc.CommandText = "insert into topichistory( " + _
                             "topicfk, name, content, updatedon, wikiset ) " + _
                             "select topicpk, name, content, updatedon, wikiset " + _
                             "from topic " + _
                             "where topicpk = @TopicPK"
            sc.Connection = oConn
            sc.ExecuteNonQuery()
        End Sub

        Public Shared Function CreateHistoryTableDS(ByRef TopicName As String) As DataSet

            Dim ds As New DataSet
            Dim oConn As SqlConnection
            oConn = ConnectToDB()
            If Not IsNothing(oConn) Then

                Dim sc As New SqlCommand
                sc.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet)
                sc.Parameters.AddWithValue("@Name", TopicName)
                sc.CommandText = "select [name], updatedon, topichistorypk as pk " + _
                                "from topichistory " + _
                                "where wikiset = @WikiSet and " + _
                                "topicfk in (select topicpk from topic where [name] = @Name) " + _
                                "order by updatedon desc"
                sc.Connection = oConn
                Dim da As New SqlDataAdapter(sc)
                da.Fill(ds, "topic")
                ds.Tables(0).Columns(0).Caption = "Name"
                ds.Tables(0).Columns(1).Caption = "Updated On"
                oConn.Close()

            Else
                ds = Nothing
            End If

            Return ds

        End Function

        Public Shared Function ReadAll(ByVal WikiSet As String) As DataSet
            Dim ds As DataSet
            Dim oConn As SqlConnection
            oConn = ConnectToDB()
            If Not IsNothing(oConn) Then
                Try
                    Dim sc As New SqlCommand
                    sc.Connection = oConn
                    sc.Parameters.AddWithValue("@WikiSet", WikiSet)
                    sc.CommandText = "select name, content, topicpk " + _
                                    "from topic " + _
                                    "where wikiset = @WikiSet " + _
                                    "order by name"
                    Dim da As New SqlDataAdapter(sc)
                    ds = New DataSet
                    da.Fill(ds, "topic")
                Finally
                    oConn.Close()
                End Try
            Else
                Throw New Exception("Could not connect to the database")
            End If
            Return ds
        End Function

    End Class

End Namespace
