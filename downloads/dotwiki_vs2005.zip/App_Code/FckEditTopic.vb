Imports Microsoft.VisualBasic
Imports System.Text.RegularExpressions

Namespace DotWiki

    Public Class FckEditTopic

        ' This method parses topics that were edited before the integration 
        ' with FckEditor so that they parse correctly with it. 
        '
        ' For example, in the pass a fake <thumbnail> tag was used to 
        ' handle thumbnail for pictures. This was needed because it 
        ' simplified what users needed to type to represent thumnails. 
        ' Now that we use the FckEditor we need to replace the fake 
        ' tags with valid HTML tags so that they render correctly 
        ' even on edit mode.
        Public Shared Function ParseTopic(ByRef TopicName As String, ByVal TopicContent As String) As String
            Dim ParsedTopic As String = TopicContent
            ParsedTopic = ParsedTopic.Replace(Chr(13), "<br>")
            ParsedTopic = ParsedTopic.Replace(Chr(10), "")
            ParsedTopic = Regex.Replace(ParsedTopic, "\<thumbnail=.+?\>", AddressOf ThumbnailReplacer)
            ParsedTopic = ParsedTopic.Replace("<CDE>", "<CODE>")
            ParsedTopic = ParsedTopic.Replace("</CDE>", "</CODE>")
            ParsedTopic = ParsedTopic.Replace("@TopicName", TopicName.ToLower())
            Return ParsedTopic
        End Function

        Public Shared Function ThumbnailReplacer(ByVal m As Match) As String
            Dim picture As String = m.Value.Replace("<thumbnail=", "")
            picture = picture.Replace(">", "")
            picture = picture.ToLower()
            Dim thumbnail As String = picture.ToLower.Replace(".jpg", "_thumb.jpg")
            Dim imageTag As String
            imageTag = String.Format("<a href=""javascript:viewpicture('@TopicName','{0}')"" > ", picture)
            imageTag += String.Format("<img src={0} border=1>", thumbnail)
            imageTag += "</a>"
            Return imageTag
        End Function

    End Class

End Namespace