' description:  Wiki Engine class for DotWiki project. This
'               is the class that parses wiki web pages.
' author:       Sept/2002 - hector@hectorcorrea.com
' includes contributions from other people. 
Imports Microsoft.VisualBasic
Imports System.Text.RegularExpressions
Imports System.Data.SqlClient
Imports DotWiki.DataServices
Imports System.Configuration.ConfigurationManager
Imports System.Web
Imports System.Web.SessionState


Namespace DotWiki


    Public Class Wiki

        ' Regular expression to detect e-mail addresses:
        ' \w+                   One or more word characters (a-z, 0-9, _)
        ' [@]                   One @
        ' [\w|\.]'              One or more word characters or a dot.
        ' [^\s|\<|\>|\""]+      One or more non-space characters or < or > or a double quote
        'Const EmailRegEx As String = "\w+[@][^\s|\<|\>|\""]+"
        Const EmailRegEx As String = "\w+[@][\w|\.]+"

        ' Regular expression to detect HTTP links:
        ' (?<=[^\=|\<|\>|\""]\s*)  Ignore links that are prefixed with =, ", <, >, or spaces
        ' http://[^\s|\<]+         http:// followed by one or more non-space characters or an <
        Const HttpRegEx As String = "(?<=[^\=|\<|\>|\""]\s*)http://[^\s|\<]+"

        ' Regular expression to detect words in CamelCase notation:
        ' (?<!\[\[\[)           Don't have 3 preceding "[" (see free link below)
        ' [A-Z|\?]              Begins with an upper case character or a question mark
        ' [A-Za-z0-9]*          Zero or more word characters (does not include underscores)
        ' [a-z]                 A lower case character
        ' [A-Za-z0-9]*          Zero or more word characters (does not include underscores)
        ' [A-Z]                 An upper case character
        ' [A-Za-z0-9]*          Zero or more word characters (does not include underscores)
        ' (?!\]\]\])            Not 3 "]" following 
        ' (?=\b)                Ends with a word boundary
        ' (?![\\]|[/]|[\.]\w)   Cannot include a "\" or "/" (like in paths), 
        '                       or a "." followed by characters (like file 
        '                       extensions.)
        'Const CamelCaseRegEx As String = "(?<!\[\[\[)[A-Z|\?]\w*[a-z]\w*[A-Z]\w*(?!\]\]\])(?=\b)(?![\\]|[/]|[\.]\w)"
        Const CamelCaseRegEx As String = "(?<!\[\[\[)[A-Z|\?][A-Za-z0-9]*[a-z][A-Za-z0-9]*[A-Z][A-Za-z0-9]*(?!\]\]\])(?=\b)(?![\\]|[/]|[\.]\w)"
        Const CamelCaseOptions As RegexOptions = RegexOptions.Compiled Or RegexOptions.Multiline

        '(?<!topic\=)   does not start with "topic=" (to prevent nested free links)
        '\[\[\[         3 open square brackets
        '.*?            plus any character (non-greedy)
        '\]\]\]         3 close square brackets
        Const FreeLinkWordRegEx As String = "(?<!topic\=)\[\[\[.*?\]\]\]" '.*? means any character (non-greedy)

        ' Parses a string and returns its Wiki equivalent.
        Public Shared Function WikiText(ByRef RawText As String) As String
            ' Use our predefined CamelCase regular expression.
            Return WikiText(CamelCaseRegEx, RawText)
        End Function

        ' Parses a string and returns its Wiki equivalent.
        Private Shared Function WikiText( _
                                ByRef CamelCaseRegExp As String, _
                                ByRef RawText As String) As String

            ' We need to process different pages edited with the FCKEditor
            Dim FckEdited As Boolean = RawText.IndexOf(RootObject.FckEditorMark) > -1
            Dim ReplaceCR As Boolean = Not FckEdited
            Dim AutoParseEmailAddresses As Boolean = Not FckEdited
            Dim AutoParseHttpReferences As Boolean = Not FckEdited

            'Add extra carriage return, so that regex parse functions work on the last line of the file.
            Dim ParsedText As String = RawText & vbCrLf & vbCrLf

            If (AutoParseHttpReferences) Then
                ParsedText = Regex.Replace(" " + ParsedText, HttpRegEx, AddressOf EvaluateHttpReference, CamelCaseOptions Or RegexOptions.IgnoreCase)
            End If

            If (AutoParseEmailAddresses) Then
                ParsedText = Regex.Replace(ParsedText, EmailRegEx, AddressOf HyperlinkEmailAddress)
            Else
                ParsedText = Regex.Replace(ParsedText, EmailRegEx, AddressOf EncodeEmailAddress)
            End If

            If (RootObject.UseCamelCaseTopics) Then
                ParsedText = Regex.Replace(ParsedText, CamelCaseRegEx, AddressOf EvaluateCamelCaseWord, CamelCaseOptions)
            End If

            ' Hyperlink FreeLink Words
            ParsedText = Regex.Replace(ParsedText, FreeLinkWordRegEx, AddressOf EvaluateFreeLinkWord, CamelCaseOptions)

            ' Remove the FreeLink tags 
            ParsedText = Regex.Replace(ParsedText, "\[\[\[(.*?)\]\]\]", "$1")

            ' Process tables
            ' (             find groups of rows
            '   (               find groups of cells
            '     [^\|^\r|^\n]*       0 or more characters that are not a pipe (nor \r nor \n)
            '     \|                  followed by a pipe
            '   )+              
            '   \r\n            \r\n after the cells marks the end of the row
            ' )+                
            ParsedText = Regex.Replace(ParsedText, "(([^\|^\r|^\n]*\|)+\r\n)+", AddressOf EvaluateTables)

            ' Replace carriage returns with <br> 
            If (ReplaceCR) Then
                ParsedText = Replace(ParsedText, Chr(13), "<br>")
            End If

            ParsedText = Regex.Replace(ParsedText, "\<img.*?src=.+?\>", AddressOf EvaluatePopUpImage)

            ParsedText = Regex.Replace(ParsedText, "\<thumbnail=.+?\>", AddressOf EvaluateThumbnail)

            ' Don't format programming code
            If (FckEdited) Then
                ParsedText = Regex.Replace(ParsedText, "<code>.*?</code>", AddressOf EvaluateCode, RegexOptions.Singleline) ' .*? means any character (non-greedy)
            Else
                ParsedText = Regex.Replace(ParsedText, "<CDE>.*?</CDE>", AddressOf EvaluateCDE, RegexOptions.Singleline) ' .*? means any character (non-greedy)
            End If

            Return ParsedText

        End Function

        Public Shared Function EvaluateCamelCaseWord(ByVal m As Match) As String
            Dim LinkText As String = m.Value

            If LinkText.Substring(0, 1) = "?" Then
                ' Don't render as hyperlink if it starts with a ?
                Return HttpUtility.UrlEncode(LinkText.Substring(1))
            Else
                If LinkText.StartsWith("Category") Then
                    Return RenderCategory(LinkText)
                Else
                    If BusinessServices.CheckTopicExists(m.Value) Then
                        Return String.Format("<a href=""{0}?topic={1}"">{2}</a>", RootObject.HomePage, HttpUtility.UrlEncode(LinkText), LinkText)

                    Else
                        Return RenderNonExistingTopic(LinkText)
                    End If

                End If
            End If

        End Function

        Public Shared Function EvaluateFreeLinkWord(ByVal m As Match) As String
            Dim LinkText As String = CleanTopicName(m.Value)
            If BusinessServices.CheckTopicExists(LinkText) Then
                Return String.Format("<a href=""{0}?topic={1}"">{2}</a>", RootObject.HomePage, HttpUtility.UrlEncode(LinkText), LinkText)
            Else
                If LinkText.StartsWith("Category") Then
                    Return RenderCategory(LinkText)
                Else
                    Return RenderNonExistingTopic(LinkText)
                End If
            End If
        End Function

        Public Shared Function DashedHyperlink(ByVal url As String)
            Return NonExistingTopicHyperlink(url, "<span class=""dashedlink"">", "</span>")
        End Function

        Public Shared Function BoldHyperlink(ByVal url As String)
            Return NonExistingTopicHyperlink(url, "<b>", "</b>")
        End Function

        Public Shared Function QuestionMarkHyperlink(ByVal url As String)
            Return url + String.Format("<a href=""{0}?topic={1}"" title=""Click to add topic"">?</a>", RootObject.HomePage, HttpUtility.UrlEncode(url))
        End Function

        Public Shared Function NonExistingTopicHyperlink(ByVal url As String, ByVal beginStyle As String, ByVal endStyle As String)
            Return String.Format("<a href=""{0}?topic={1}"" title=""Click to add topic"">{2}</a>", _
                    RootObject.HomePage, HttpUtility.UrlEncode(url), beginStyle & url & endStyle) ' See EvaluateCode if you change this line
        End Function

        Public Shared Function RenderNonExistingTopic(ByVal url As String) As String
            If RootObject.NewLinkFormat = 0 Then
                Return QuestionMarkHyperlink(url)
            ElseIf RootObject.NewLinkFormat = 2 Then
                Return BoldHyperlink(url)
            Else
                Return DashedHyperlink(url)
            End If
        End Function

        Public Shared Function RenderCategory(ByVal url As String)
            Return String.Format("<a href=""{0}?SearchString={1}"" " & _
            "title=""Click to search all topics in this category""> " & _
            "<span class=""categorylink"">{2}</span></a>", _
            RootObject.SearchPage, HttpUtility.UrlEncode(url), url) ' See EvaluateCode if you change this line
        End Function


        Public Shared Function EvaluateHttpReference(ByVal m As Match) As String
            Return String.Format("<a href=""{0}"" target=""_blank"">{0}</a>", m.Value)
        End Function

        ' Notice that I am forcing the link to lower case to prevent 
        ' them from being considered as CamelCase words should they come
        ' in CamelCase notation. I might need to change this later on.
        '
        ' Also notice that we HTML-encode e-mail addresses to prevent
        ' spammers from picking them up from our web site.
        Public Shared Function HyperlinkEmailAddress(ByVal m As Match) As String
            Dim EmailAddress As String = m.Value.ToLower()
            Dim MailTo As String = "mailto:" + EmailAddress
            Return "<a href=" + Chr(34) + ForceHtmlEncoded(MailTo) + Chr(34) + ">" + ForceHtmlEncoded(EmailAddress) + "</a>"
        End Function

        Public Shared Function EncodeEmailAddress(ByVal m As Match) As String
            Return ForceHtmlEncoded(m.Value)
        End Function

        ' Parses text that reprents tables like this:
        '   text|text|...|
        '   text|text|...|
        ' and returns its HTML equivalent.
        Public Shared Function EvaluateTables(ByVal m As Match) As String

            Dim HtmlTable As String

            Try
                HtmlTable = "<table border=""1"" class=""regularTable"">"

                Dim Lines As String() = Split(m.Value.Replace(Chr(10), ""), Chr(13))
                For i As Integer = 0 To Lines.Length - 2
                    If Lines(i).Trim.Length > 0 Then
                        HtmlTable += "<tr class=""regularTableRow"">"
                        Dim Columns As String() = Split(Lines(i), "|")
                        For j As Integer = 0 To Columns.Length - 2
                            If i = 0 Then
                                HtmlTable += "<th class=""regularTableHeader"">" + Columns(j) + "</th>"
                            Else
                                HtmlTable += "<td class=""regularTableCell"">" + Columns(j) + "</td>"
                            End If
                        Next
                        HtmlTable += "</tr>"
                    End If

                Next

                HtmlTable += "</table>"

            Catch ex As Exception
                HtmlTable = m.Value

            End Try

            Return HtmlTable

        End Function

        ' Parses HTML IMG SRC tags and surrounds them with an anchor tag.
        ' If m.value is equal to <img src=folder\file.ext>
        ' Result is equal to <a href=...><img src=folder\file.ext></a>
        Public Shared Function EvaluatePopUpImage(ByVal m As Match) As String

            Dim NewImgTag As String

            Try
                ' Extract image file name from HTML IMG tag.
                Dim match2 As Match = Regex.Match(m.Value, "src=[\""]*.*?[\""|\s|\>]")
                Dim PictureFile As String = match2.Value.Substring(4)
                PictureFile = PictureFile.Replace("""", "").Trim()
                PictureFile = PictureFile.Replace("\", "/")
                PictureFile = PictureFile.Replace("_thumb.", ".")

                ' Define HREF to pop up the image
                Dim ViewPicture As String = "javascript:viewpicture('{TopicName}','" + PictureFile + "')"

                ' Define the new text to render
                NewImgTag = "<a href=" + Chr(34) + ViewPicture + Chr(34) + ">" + m.Value + "</a>"

            Catch ex As Exception
                ' Something went wrong...don't do any translation.
                NewImgTag = m.Value

            End Try

            Return NewImgTag

        End Function

        ' Code tags to make sure they are preserved.
        Public Shared Function EvaluateCDE(ByVal m As Match) As String

            Dim CodeReturn As String

            CodeReturn = Replace(m.Value, "<br>", Chr(13))
            CodeReturn = Replace(CodeReturn, "<CDE>", "")                       ' remove opening tag
            CodeReturn = Replace(CodeReturn, "</CDE>", "")                      ' remove closing tag
            CodeReturn = Regex.Replace(CodeReturn, "<a[^>]*>\?</a>", "")        ' ???
            CodeReturn = Regex.Replace(CodeReturn, "<a[^>]*>(.*?)</a>", "$1")   ' remove <a> </a> to prevent links
            CodeReturn = Regex.Replace(CodeReturn, "<span class=\""dashedlink\""[^>]*>(.*?)</span>", "$1") ' remove dashedlink span (used for non-existing topics)
            CodeReturn = Regex.Replace(CodeReturn, "<span class=\""categorylink\""[^>]*>(.*?)</span>", "$1") ' remove categorylink span (used for categories)

            CodeReturn = "<table class=""sourcecode""><tr><td><PRE>" & _
                HttpUtility.HtmlEncode(CodeReturn) & _
                "</PRE></td></tr></table>"

            Return CodeReturn

        End Function

        ' Code tags to make sure they are preserved.
        Public Shared Function EvaluateCode(ByVal m As Match) As String
            Dim CodeReturn As String = m.Value

            ' Remove all HMTL encoding...
            CodeReturn = Regex.Replace(CodeReturn, "<a[^>]*>\?</a>", "")        ' ???
            CodeReturn = Regex.Replace(CodeReturn, "<a[^>]*>(.*?)</a>", "$1")   ' remove <a> </a> to prevent links
            CodeReturn = Regex.Replace(CodeReturn, "<span class=\""dashedlink\""[^>]*>(.*?)</span>", "$1") ' remove dashedlink span (used for non-existing topics)
            CodeReturn = Regex.Replace(CodeReturn, "<span class=\""categorylink\""[^>]*>(.*?)</span>", "$1") ' remove categorylink span (used for categories)
            CodeReturn = HttpUtility.HtmlEncode(CodeReturn)

            ' ...and then add the ones that we want to preserve
            CodeReturn = Replace(CodeReturn, "&lt;br /&gt;", "<br />")
            CodeReturn = Replace(CodeReturn, "&lt;code&gt;", "<code>")
            CodeReturn = Replace(CodeReturn, "&lt;/code&gt;", "</code>")
            CodeReturn = Replace(CodeReturn, "&amp;quot;", """")

            Return CodeReturn
        End Function

        ' Parses "thumbnail" tags and surrounds them with an anchor tag.
        ' If m.value is equal to <img src=folder\file.ext>
        ' Result is equal to <a href=...><img src=folder\file.ext></a>
        Public Shared Function EvaluateThumbnail(ByVal m As Match) As String

            Dim NewTag As String

            Try

                Dim m2 As Match = Regex.Match(m.Value, "=[\w\.\\//]*(?=\b)")
                Dim PictureFile As String = m2.Value.Substring(1)
                PictureFile = PictureFile.Replace("\", "/")

                Dim ThumbnailPicture As String = PictureFile.Replace(".", "_thumb.")
                Dim ViewPicture As String = "javascript:viewpicture('{TopicName}','" + PictureFile + "')"
                Dim ImgTag As String = "<img src=" + ThumbnailPicture + " border=1>"

                NewTag = "<a href=" + Chr(34) + ViewPicture + Chr(34) + ">" + ImgTag + "</a>"

            Catch ex As Exception
                ' Something went wrong...don't do any translation.
                NewTag = m.Value

            End Try

            Return NewTag

        End Function

        ' Returns an HTML-encoded version of the OriginalText.
        ' For example "ABC" becomes "&#65;&#66;&#67;"
        Public Shared Function ForceHtmlEncoded(ByVal OriginalText As String)
            Dim encoded As String = String.Empty
            Dim len As Integer = OriginalText.Length
            Dim i As Integer = 0
            For i = 0 To len - 1
                encoded += "&#" & Asc(OriginalText.Substring(i)) & ";"
            Next
            Return encoded
        End Function

        Public Shared Function CleanTopicName(ByRef topicName As String) As String

            Dim cleanName As String = ""
            For i As Integer = 0 To topicName.Length - 1
                Dim c As Char = topicName.Substring(i, 1)
                If Char.IsLetterOrDigit(c) Then
                    cleanName += c
                Else
                    cleanName += " "
                End If
            Next

            'Dim invalidCharacters As String = "[]<>?+=.%:/#;"
            'If cleanName.IndexOfAny(invalidCharacters) > -1 Then
            '    For i As Integer = 0 To invalidCharacters.Length - 1
            '        Dim c As Char = invalidCharacters.Substring(i, 1)
            '        cleanName = cleanName.Replace(c, "")
            '    Next
            'End If

            While cleanName.Contains("  ")
                cleanName = cleanName.Replace("  ", " ")
            End While

            Return cleanName.Trim()
        End Function

    End Class

End Namespace
