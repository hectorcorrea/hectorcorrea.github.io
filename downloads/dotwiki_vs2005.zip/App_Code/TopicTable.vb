Namespace DotWiki

    Public Enum TopicTableType
        ByName = 1
        ByDate = 2
        ByDateHistory = 3
    End Enum

    Public Class TopicTable

        Public Shared Function FromDS(ByVal ds As DataSet, ByVal type As Integer) As String

            Dim t As String = ""
            t += "<table class=""topicTable"">" & vbCrLf

            Dim dc As DataColumn
            For Each dc In ds.Tables(0).Columns
                If dc.Caption.ToLower <> "pk" Then
                    t += "<th class=""topicTableHeader"">" + dc.Caption + "</th>"
                End If
            Next

            Dim dr As DataRow
            Dim oddRow As Boolean = True
            Dim nbsp As String = "&nbsp;"
            For Each dr In ds.Tables(0).Rows

                Dim name As String = dr.Item("name").ToString().TrimEnd()
                Dim updatedon As String = dr.Item("updatedon").ToString()
                Dim rowStyle As String = IIf(oddRow, "topicTableRow", "topicTableRowAlternate")
                Dim encodedName As String = HttpUtility.UrlEncode(name)

                Dim col1 As String
                Dim col2 As String

                If type = TopicTableType.ByDate Then
                    col1 = nbsp + name + nbsp
                    col2 = "<a href=Default.aspx?topic=" + encodedName + ">" + updatedon + "</a>" + nbsp + nbsp
                ElseIf type = TopicTableType.ByDateHistory Then
                    Dim pk As String = dr.Item("pk").ToString()
                    col1 = nbsp + name + nbsp
                    col2 = "<a href=TopicHistory.aspx?topic=" + encodedName + "&pk=" + pk + ">" + updatedon + "</a>" + nbsp + nbsp
                Else
                    ' assume by name
                    col1 = "<a href=Default.aspx?topic=" + encodedName + ">" + name + "</a>"
                    col2 = nbsp + updatedon + nbsp
                End If

                t += "<tr class=""" + rowStyle + """>" + _
                    "<td class=""topicTableCellName"">" + col1 + "</td>" + _
                    "<td class=""topicTableCellUpdatedOn"">" + col2 + "</td>" + _
                    "</tr>" + vbCrLf

                oddRow = Not oddRow

            Next

            t += "</table>" + vbCrLf
            Return t

        End Function

    End Class

End Namespace
