' description:  Data services for DotWiki project.
' author:       Sept/2002 - hector@hectorcorrea.com 
' updated:      

Imports System.Data.SqlClient
Imports System.Data
Imports System.Configuration.ConfigurationManager

Namespace DotWiki


    Public Class DataServices

        Public Shared Function ConnectToDB() As SqlConnection
            Dim Conn As SqlConnection
            Dim ConnString As String

            ConnString = AppSettings("ConnectionString")
            If ConnString Is Nothing Then
                Dim errorMessage As String = "ConnectionString setting not found in web.config. " & _
                "A setting like this needs to be added under the appSettings section of your web.config " & _
                "<add key=""ConnectionString"" value=""yourservername;database=dotwiki;uid=yourusername;pwd=yourpassword"" />"
                Throw New Exception(errorMessage)
            End If

            Try
                Conn = New SqlConnection(ConnString)
                Conn.Open()
            Catch ex As Exception
                Conn = Nothing
            End Try

            Return Conn

        End Function

    End Class

End Namespace
