'Imports System.Configuration.ConfigurationSettings
Imports System.Configuration.ConfigurationManager


Namespace DotWiki


    Public Class RootObject

        Private Shared m_HomeTopic As String
        Private Shared m_WikiSet As String
        Private Shared m_LeftMenuTopic As String
        Private Shared m_NewLinkFormat As Integer = -1
        Private Shared m_NewTopicSample As String
        Private Shared m_UseCamelCaseTopics As String

        Public Shared ReadOnly Property HomePage() As String
            Get
                Return "Default.aspx"
            End Get
        End Property

        Public Shared ReadOnly Property SearchPage() As String
            Get
                Return "Search.aspx"
            End Get
        End Property

        Public Shared ReadOnly Property FckEditorMark() As String
            Get
                Return "<!-- fckeditor -->"
            End Get
        End Property

        Public Shared ReadOnly Property HomeTopic() As String
            Get
                If m_HomeTopic Is Nothing Then
                    m_HomeTopic = AppSettings.Item("HomeTopic")
                    If m_HomeTopic Is Nothing Then
                        Throw New Exception("HomeTopic could not be found in web.config")
                    End If
                End If
                Return m_HomeTopic
            End Get
        End Property

        Public Shared ReadOnly Property WikiSet() As String
            Get
                If m_WikiSet Is Nothing Then
                    m_WikiSet = AppSettings.Item("WikiSet")
                    If m_WikiSet Is Nothing Then
                        Throw New Exception("m_WikiSet could not be found in web.config")
                    End If
                End If
                Return m_WikiSet
            End Get
        End Property

        Public Shared ReadOnly Property LeftMenuTopic() As String
            Get
                If m_LeftMenuTopic Is Nothing Then
                    m_LeftMenuTopic = AppSettings.Item("LeftMenuTopic")
                    If m_LeftMenuTopic Is Nothing Then
                        Throw New Exception("LeftMenuTopic could not be found in web.config")
                    End If
                End If
                Return m_LeftMenuTopic
            End Get
        End Property

        Public Shared ReadOnly Property NewLinkFormat() As Integer
            Get
                If m_NewLinkFormat = -1 Then
                    Dim setting As String = AppSettings.Item("NewLinkFormat")
                    If setting Is Nothing Then
                        Throw New Exception("NewLinkFormat could not be found in web.config")
                    End If
                    Integer.TryParse(setting, m_NewLinkFormat)
                End If
                Return m_NewLinkFormat
            End Get
        End Property

        Public Shared ReadOnly Property NewTopicSample() As String
            Get
                If m_NewTopicSample Is Nothing Then
                    m_NewTopicSample = AppSettings.Item("NewTopicSample")
                    If m_NewTopicSample Is Nothing Then
                        m_NewTopicSample = "(e.g. Wikis are cool)"
                    End If
                End If
                Return m_NewTopicSample
            End Get
        End Property

        Public Shared ReadOnly Property UseCamelCaseTopics() As Boolean
            Get
                If m_UseCamelCaseTopics Is Nothing Then
                    m_UseCamelCaseTopics = AppSettings.Item("UseCamelCaseTopics")
                    If m_UseCamelCaseTopics Is Nothing Then
                        m_UseCamelCaseTopics = "no"
                    Else
                        m_UseCamelCaseTopics = m_UseCamelCaseTopics.ToLower()
                    End If
                End If
                Return (m_UseCamelCaseTopics = "yes")
            End Get
        End Property
    End Class

End Namespace
