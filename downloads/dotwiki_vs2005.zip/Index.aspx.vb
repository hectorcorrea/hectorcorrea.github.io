' description: Creates an index of topic.
'              Needs to be rewriten if the number of topics is very large,
'              but for now this is OK.

Imports DotWiki.BusinessServices


Namespace DotWiki


Partial Class Index
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Try

            Me.lblPageContent.Visible = False
            Me.lblErrorMessage.Visible = False
            Me.lblErrorMessage.Text = ""

            Dim ds As DataSet = GetIndexDS()
            If ds Is Nothing Then
                Me.lblErrorMessage.Visible = True
                Me.lblErrorMessage.Text = "Could not find topics."
            Else
                Me.lblPageContent.Visible = True
                Me.lblPageContent.Text = TopicTable.FromDS(ds, TopicTableType.ByName) + "<br><br>"
            End If

        Catch ex As Exception
            Me.lblErrorMessage.Visible = True
            Me.lblErrorMessage.Text = "Error: " & ex.Message

        End Try

    End Sub

End Class

End Namespace
