Imports DotWiki.StringServices
Imports DotWiki.BusinessServices
Imports System.Configuration.ConfigurationManager
Imports System.IO

Namespace DotWiki


    Partial Class FileUpload
        Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Function UploadPassword() As String
            UploadPassword = AppSettings.Item("UploadPassword")
            If UploadPassword Is Nothing Then
                UploadPassword = ""
            End If
        End Function

        Public Sub LoadPicture()

            Dim FileName As String = ""
            Dim FullPath As String = ""
            
            Try

                Dim EnteredPassword As String = Me.txtPassword.Text.Trim
                If EnteredPassword <> UploadPassword() Then
                    Throw New Exception("Invalid Password")
                End If

                Dim SourceFileName As String = txtUpload.PostedFile.FileName
                FileName = Path.GetFileName(SourceFileName).Replace(" "c, "_")
                Dim FileExtension As String = Path.GetExtension(FileName).ToUpper()
                If FileExtension <> ".JPG" And FileExtension <> ".GIF" And FileExtension <> ".PNG" Then
                    Throw New Exception("Invalid file extension. File extension must be JPG, GIF, or PNG.")
                End If

                Dim MaxSizeInKB As Integer= CType(AppSettings("UpLoadMaxSize"), Integer)
                If txtUpload.PostedFile.ContentLength > (MaxSizeInKB * 1024) Then
                    Throw New Exception("File is too big.")
                End If

                Dim BasePath As String = Server.MapPath(".")
                Dim PicturesPath As String = AppSettings("UpLoadPath")
                FullPath = Path.Combine(BasePath, PicturesPath)
                FullPath = Path.Combine(FullPath, FileName)

                'Internet Anonymous User (ANONYMOUS LOGON under XP) must have 
                ' Write (or Full Control) permissions.
                txtUpload.PostedFile.SaveAs(FullPath)
                lblResults.Text = "Upload of File [" & FileName & "] to folder [" & FullPath & "] succeeded"

                Dim TopicName As String = Request.QueryString.Item("topic")
                If Not TopicName Is Nothing Then
                    TopicName = Wiki.CleanTopicName(TopicName)
                    AddPictureToTopic(TopicName, PicturesPath & FileName)
                    Dim GoBackToTopicURL As String
                    GoBackToTopicURL = RootObject.HomePage + "?topic=" + HttpUtility.UrlEncode(TopicName)
                    If Not Me.Page.Trace.IsEnabled Then
                        Response.Redirect(GoBackToTopicURL)
                    End If
                End If

            Catch Ex As Exception
                lblResults.Text = "Upload of file [" & FileName & "] to folder [" & FullPath & "] failed for the following reason: " & Ex.Message
            Finally
                lblResults.Font.Bold = True
                lblResults.Visible = True
            End Try
        End Sub

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            Me.Page.Form.DefaultButton = btnUpload.UniqueID

            If Not IsPostBack() Then

                Dim topicName As String = Request.QueryString.Item("topic")
                If topicName Is Nothing Then
                    Me.Response.Redirect(RootObject.HomePage)
                End If

                topicName = Wiki.CleanTopicName(topicName)
                Me.lblTitle.Text = Me.lblTitle.Text.Replace("{TopicName}", "<b>" & topicName & "</b>")
                Dim MaxSizeInKB As Integer = CType(AppSettings("UpLoadMaxSize"), Integer)
                Me.lblMaxSize.Text = "(Max. " & MaxSizeInKB & "KB)"

                If (UploadPassword.Length > 0) Then
                    Me.lblPassword.Visible = True
                    Me.txtPassword.Visible = True
                End If
            End If
        End Sub
    End Class

End Namespace
