Namespace DotWiki

Partial Class ViewImage
    Inherits System.Web.UI.Page


#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents lblTopicPK As System.Web.UI.WebControls.Label


    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Not IsPostBack() Then

            SetBackground("pictureBlackPage", "pictureBlackText")

            If Not Me.Request.QueryString.Item("TopicName") Is Nothing Then

                Dim TopicName As String = Me.Request.QueryString.Item("TopicName")
                Dim PicturesString As String = BusinessServices.ReadTopicPictures(TopicName)
                If Not PicturesString Is Nothing Then

                    Dim Pictures() As String = PicturesString.Split("|")
                    If Pictures.Length > 0 Then

                        Dim StartUpPicture As String = Me.Request.QueryString.Item("PictureFile")
                        Dim StartUpIndex As Int16
                        If Not StartUpPicture Is Nothing Then
                            StartUpIndex = Array.IndexOf(Pictures, StartUpPicture)
                            If StartUpIndex = -1 Then
                                StartUpIndex = 0
                            End If
                        End If

                        Session("Pictures") = PicturesString
                        Session("PictureNumber") = StartUpIndex
                        Me.UpdateCounter(StartUpIndex + 1, Pictures.Length)
                        Me.lblPictureFile.Text = Pictures(StartUpIndex)

                    End If

                End If

            ElseIf Not Me.Request.QueryString.Item("PictureFile") Is Nothing Then

                Me.lblPictureFile.Text = Me.Request.QueryString.Item("PictureFile")
                Me.UpdateCounter(1, 1)

            Else

                Me.lblPictureFile.Text = ""
                Me.UpdateCounter(1, 1)
            End If

            Me.lblPictureZoom.Text = "Original Size"
            Me.RenderImage()

        End If

    End Sub

    Private Sub RenderImage()

        Dim PictureClass As String = ""
        If BodyTag.Attributes("class") = "pictureBlackPage" Then
            PictureClass = "class=pictureBlack"
        ElseIf BodyTag.Attributes("class") = "pictureWhitePage" Then
            PictureClass = "class=pictureWhite"
        End If

        If Me.lblPictureFile.Text.Length = 0 Then
            Me.lblContent.Text = "<div " + PictureClass + ">" + "No image file available" + "</div>"
            Me.lblCount.Text = ""
            Me.lblPictureZoom.Text = ""
        Else
            Dim PictureTag As String
            Select Case Me.lblPictureZoom.Text
                Case Is = "Fit Horizontal"
                    PictureTag = "<img src=" + Me.lblPictureFile.Text + " width=90%>"
                Case Is = "Fit Vertical"
                    PictureTag = "<img src=" + Me.lblPictureFile.Text + " height=90%>"
                Case Else
                    PictureTag = "<img src=" + Me.lblPictureFile.Text + ">"
            End Select
            Me.lblContent.Text = "<div " + PictureClass + ">" + PictureTag + "</div>"
        End If
    End Sub

    Private Sub UpdateCounter(ByVal CurrentPicture As Int16, ByVal TotalPictures As Int16)

        Me.lblCount.Text = "(" & CurrentPicture & "/" & TotalPictures & ")"

        Me.cmdFirst.Enabled = CurrentPicture > 1
        Me.cmdPrevious.Enabled = CurrentPicture > 1
        Me.cmdNext.Enabled = CurrentPicture < TotalPictures
        Me.cmdLast.Enabled = CurrentPicture < TotalPictures

    End Sub

    Private Sub ShowFirstPicture()
        Dim PicturesString As String = Session("Pictures")
        If Not PicturesString Is Nothing Then
            Dim Pictures() As String = PicturesString.Split("|")
            Session("PictureNumber") = 0
            UpdateCounter(1, Pictures.Length)
            Me.lblPictureFile.Text = Pictures(0)
            RenderImage()
        End If
    End Sub

    Private Sub ShowLastPicture()
        Dim PicturesString As String = Session("Pictures")
        If Not PicturesString Is Nothing Then
            Dim Pictures() As String = PicturesString.Split("|")
            Session("PictureNumber") = Pictures.Length - 1
            UpdateCounter(Pictures.Length, Pictures.Length)
            Me.lblPictureFile.Text = Pictures(Pictures.Length - 1)
            RenderImage()
        End If
    End Sub

    Private Sub ShowPreviousPicture()
        Dim PicturesString As String = Session("Pictures")
        If Not PicturesString Is Nothing Then
            Dim Pictures() As String = PicturesString.Split("|")
            Dim PictureNumber As Int16 = Session("PictureNumber")
            If PictureNumber > 0 Then
                PictureNumber -= 1
                Session("PictureNumber") = PictureNumber
            End If
            UpdateCounter(PictureNumber + 1, Pictures.Length)
            Me.lblPictureFile.Text = Pictures(PictureNumber)
            RenderImage()
        End If
    End Sub

    Private Sub ShowNextPicture()
        Dim PicturesString As String = Session("Pictures")
        If Not PicturesString Is Nothing Then
            Dim Pictures() As String = PicturesString.Split("|")
            Dim PictureNumber As Int16 = Session("PictureNumber")
            If PictureNumber < Pictures.Length - 1 Then
                PictureNumber += 1
                Session("PictureNumber") = PictureNumber
            End If
            UpdateCounter(PictureNumber + 1, Pictures.Length)
            Me.lblPictureFile.Text = Pictures(PictureNumber)
            RenderImage()
        End If
    End Sub

    Private Sub UseOriginalSize()
        Me.lblPictureZoom.Text = "Original Size"
        Me.RenderImage()
    End Sub

    Private Sub FitHorizontal()
        Me.lblPictureZoom.Text = "Fit Horizontal"
        Me.RenderImage()
    End Sub

    Private Sub FitVertical()
        Me.lblPictureZoom.Text = "Fit Vertical"
        Me.RenderImage()
    End Sub

    Private Sub SetBackground(ByVal PageClass As String, ByVal TextClass As String)
        If BodyTag.Attributes("class") Is Nothing Then
            BodyTag.Attributes.Add("class", PageClass)
        Else
            BodyTag.Attributes("class") = PageClass
        End If
        lblCount.CssClass = TextClass
        lblPictureFile.CssClass = TextClass
        lblPictureZoom.CssClass = TextClass
    End Sub

    Private Sub UseBlackBackground()
        SetBackground("pictureBlackPage", "pictureBlackText")
        RenderImage()
    End Sub

    Private Sub UseWhiteBackground()
        SetBackground("pictureWhitePage", "pictureWhiteText")
        RenderImage()
    End Sub

    Private Sub cmdNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdNext.Click
        Me.ShowNextPicture()
    End Sub

    Private Sub cmdPrevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPrevious.Click
        Me.ShowPreviousPicture()
    End Sub

    Private Sub cmdFirst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFirst.Click
        Me.ShowFirstPicture()
    End Sub

    Private Sub cmdLast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdLast.Click
        Me.ShowLastPicture()
    End Sub

    Private Sub cboActions_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboActions.SelectedIndexChanged
        If cboActions.SelectedValue = "OriginalSize" Then
            UseOriginalSize()
        ElseIf cboActions.SelectedValue = "FitHorizontal" Then
            FitHorizontal()
        ElseIf cboActions.SelectedValue = "FitVertical" Then
            FitVertical()
        ElseIf cboActions.SelectedValue = "BlackBackground" Then
            UseBlackBackground()
        ElseIf cboActions.SelectedValue = "WhiteBackground" Then
            UseWhiteBackground()
        End If
        cboActions.SelectedIndex = 0
    End Sub
End Class

End Namespace
