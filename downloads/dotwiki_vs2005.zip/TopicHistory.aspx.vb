Imports DotWiki.BusinessServices
Imports DotWiki.Wiki
'Imports System.Configuration.ConfigurationSettings
Imports System.Configuration.ConfigurationManager

Namespace DotWiki



    Partial Class TopicHistory
        Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            If Not Me.IsPostBack() Then
                If Not Me.Request.QueryString.Item("pk") Is Nothing Then
                    Me.ShowOldVersion()
                Else
                    Me.ShowTopicHistoryList()
                End If
            End If

        End Sub

        Private Sub ShowOldVersion()

            Me.lblHistory.Visible = True
            Me.cmdRestore.Visible = True
            Me.lblHistoryTable.Visible = False

            If AppSettings.Item("RestorePassword").Trim.Length > 0 Then
                Me.lblRestorePassword.Visible = True
                Me.txtRestorePassword.Visible = True
            Else
                Me.lblRestorePassword.Visible = False
                Me.txtRestorePassword.Visible = False
            End If

            Dim HistoryPK, DateTime, TopicName As String
            HistoryPK = Me.Request.QueryString.Item("pk")
            TopicName = Me.Request.QueryString.Item("topic")
            DateTime = ""
            If Not TopicName Is Nothing Then
                Me.lblPageContent.Text = WikiText(ReadTopicHistory(HistoryPK, DateTime))
                Me.lblPageContent.Visible = True
                Me.lblHistory.Text = "History of <b>" + TopicName + "</b> as of " + DateTime.ToString() + "<br><br>"
            End If

        End Sub

        Private Sub ShowTopicHistoryList()

            Me.lblHistory.Visible = False
            Me.lblPageContent.Visible = False
            Me.cmdRestore.Visible = False
            Me.lblRestorePassword.Visible = False
            Me.txtRestorePassword.Visible = False

            Dim TopicName As String = Me.Request.QueryString.Item("topic")
            If Not TopicName Is Nothing Then
                Dim history As DataSet
                history = CreateHistoryTableDS(TopicName)
                If history.Tables(0).Rows.Count = 0 Then
                    Me.lblHistoryTable.Text = "<br>There are no previous versions of topic <b>" + TopicName + "</b><br><br>"
                Else
                    Me.lblHistoryTable.Text = "<br>Select what version of <b>" + TopicName + "</b> you want to review.<br><br>" + _
                        TopicTable.FromDS(history, TopicTableType.ByDateHistory) + _
                        "<br><br>"
                End If
            End If

        End Sub

        Private Sub cmdRestore_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdRestore.Click

            Dim TopicName As String = Me.Request.QueryString.Item("topic").ToString()
            If Not TopicName Is Nothing Then
                If Me.txtRestorePassword.Text = AppSettings.Item("RestorePassword") Then
                    Dim HistoryPK, DateTime As String
                    HistoryPK = Me.Request.QueryString.Item("pk")
                    DateTime = ""
                    Me.lblPageContent.Text = ReadTopicHistory(HistoryPK, DateTime)
                    SaveTopic(TopicName, Me.lblPageContent.Text)
                    Me.Response.Redirect(RootObject.HomePage + "?topic=" & HttpUtility.UrlEncode(TopicName))
                Else
                    Me.lblPasswordMessage.Text = "Invalid password"
                End If
            End If

        End Sub
    End Class

End Namespace
