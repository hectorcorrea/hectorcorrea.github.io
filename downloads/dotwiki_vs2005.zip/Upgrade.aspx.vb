Imports DotWiki

Partial Class Upgrade
    Inherits System.Web.UI.Page

    Protected Sub btnCamelCaseToFreeLink_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCamelCaseToFreeLink.Click
        ConvertCamelCaseTopicToFreeLink()
    End Sub

    Protected Sub ConvertCamelCaseTopicToFreeLink()
        Dim ds As New DataSet()
        ds = BusinessServices.ReadAll(RootObject.WikiSet)

        Dim camelCaseRegEx As String = "(?<!\[\[\[)[A-Z|\?][A-Za-z0-9]*[a-z][A-Za-z0-9]*[A-Z][A-Za-z0-9]*(?!\]\]\])(?=\b)(?![\\]|[/]|[\.]\w)"

        Dim errorMessage As String = ""
        Dim okCount As Integer = 0
        Dim errorCount As Integer = 0
        Dim alreadyProcessedCount As Integer = 0
        Dim row As DataRow
        For Each row In ds.Tables(0).Rows
            Dim topic As String = row("content")
            Dim name As String = row("name").ToString().Trim()
            Dim topicPK As Guid = row("topicpk")
            Dim newTopic As String = Regex.Replace(topic, camelCaseRegEx, AddressOf ReplaceCamelCase)
            Dim topicAlreadyProcesses As Boolean = False

            Dim newName As String = ""
            If name.StartsWith("[[[") Then
                newName = name.Replace("[[[", "").Replace("]]]", "") ' remove free link tags
            Else
                If name.Contains(" ") Then
                    topicAlreadyProcesses = True
                    alreadyProcessedCount += 1
                Else
                    newName = CamelCaseToFreeLink(name)
                End If
            End If

            If Not topicAlreadyProcesses Then
                If name <> newName OrElse topic <> newTopic Then
                    Dim saveError As String = BusinessServices.SaveTopic(topicPK, newName, newTopic)
                    If saveError.Length = 0 Then
                        'lblTopic.Text += String.Format("{0}, OK<br>", newName)
                        okCount += 1
                    Else
                        errorMessage += String.Format("{0} {1}<br>", newName, saveError)
                        errorCount += 1
                    End If
                End If
            End If
        Next

        lblResults.Text = "<b>Result Summary</b><br>"
        lblResults.Text += String.Format("{0} records converted OK, {1} records with problems<br>", okCount, errorCount)
        If alreadyProcessedCount > 0 Then
            lblResults.Text += String.Format("{0} records skipped because they've been processed before<br>", alreadyProcessedCount)
        End If

        If okCount > 0 Then
            lblResults.Text += "<p>Remember to update the value of <b>HomeTopic</b> and <b>LeftMenuTopic</b> " & _
            "in your web.config to point to the topics' new names " & _
            "(e.g. from LeftMenu to Left Menu)</p>"
        End If

        If errorCount > 0 Then
            lblResults.Text += "<p><b><font color=""red"">Errors:</font></b> " + errorMessage + "</p>"
        End If

    End Sub

    Public Shared Function ReplaceCamelCase(ByVal m As Match) As String
        If m.Value.StartsWith("?") Then
            Return m.Value
        End If
        Return "[[[" + CamelCaseToFreeLink(m.Value) + "]]]"
    End Function

    Public Shared Function CamelCaseToFreeLink(ByVal camelCase As String) As String
        Dim lastChar As Char = camelCase.Substring(0)
        Dim isLastUpper As Boolean = (lastChar >= "A" And lastChar <= "Z")
        Dim isLastDigit As Boolean = (lastChar >= "0" And lastChar <= "9")
        Dim i As Integer
        Dim freeLink As String = ""
        For i = 0 To camelCase.Length - 1
            Dim thisChar As Char = camelCase.Substring(i)
            Dim isThisUpper As Boolean = (thisChar >= "A" And thisChar <= "Z")
            Dim isThisDigit As Boolean = (thisChar >= "0" And thisChar <= "9")
            Dim ignoreChar As Boolean = False

            If thisChar = "_" Then
                ignoreChar = True
            ElseIf Not isLastDigit And isThisDigit Then
                freeLink += " "
            ElseIf Not isLastUpper And isThisUpper Then
                freeLink += " "
            End If

            If Not ignoreChar Then
                freeLink += thisChar
            End If

            isLastUpper = isThisUpper
            isLastDigit = isThisDigit
        Next

        freeLink = freeLink.Replace("Dot Wiki", "DotWiki")      ' keep this in camel case notation
        freeLink = freeLink.Replace("Camel Case", "CamelCase")  ' keep this in camel case notation

        Return freeLink.Trim()
    End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lblWikiSet.Text = RootObject.WikiSet
    End Sub
End Class
