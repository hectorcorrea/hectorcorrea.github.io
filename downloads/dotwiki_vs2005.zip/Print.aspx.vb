' description:  Web page where wiki web pages are rendered.
' author:       Sept/2002 - hector@hectorcorrea.com 
'
Imports DotWiki.BusinessServices
Imports DotWiki.Wiki
'Imports System.Configuration.ConfigurationSettings
Imports System.Configuration.ConfigurationManager


Namespace DotWiki


Partial Class WikiPrintPage
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

#Region "Form Events"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.ViewState("TopicName") = Me.Request.QueryString.Item("topic").ToString()
        Me.DisplayTopic()
    End Sub

#End Region

    Private Function GetHomeTopic() As String

        Dim homeTopic As String = AppSettings.Item("HomeTopic")
        If homeTopic.Trim.Length = 0 Then
            homeTopic = "HomeWiki"
        End If

        Return homeTopic

    End Function

    Private Sub DisplayTopic()
        Dim Content As String
        Dim UpdatedOn As String = ""
        If BusinessServices.CheckTopicExists(Me.ViewState("TopicName")) = True Then
            Content = ReadTopic(Me.ViewState("TopicName"), UpdatedOn)
        Else
            Content = "This topic does not yet exist.  Please check back later"
        End If

        Me.lblTopicNameOnHeader.Text = Me.ViewState("TopicName")
        Me.lblUpdatedOn.Text = UpdatedOn
        Me.lblPageContent.Text = WikiText(Content)
    End Sub
End Class

End Namespace
