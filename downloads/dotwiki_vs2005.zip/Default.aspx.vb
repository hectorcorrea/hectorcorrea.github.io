' description:  Web page where wiki web pages are rendered.
' author:       Sept/2002 - hector@hectorcorrea.com 
'
Imports DotWiki.BusinessServices
Imports DotWiki.Wiki
'Imports System.Configuration.ConfigurationSettings
Imports System.Configuration.ConfigurationManager

Namespace DotWiki


    Partial Class WikiTopicPage
        Inherits System.Web.UI.Page
        Protected WithEvents lblDblClick As System.Web.UI.WebControls.Label
        Protected WithEvents cmdHistory As System.Web.UI.WebControls.Button

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

#Region "Form Events"

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            If Not Me.IsPostBack() Then

                If Me.Request.QueryString.Item("topic") Is Nothing Then
                    Me.ViewState("TopicName") = RootObject.HomeTopic
                Else
                    Dim TopicName As String = Wiki.CleanTopicName(Me.Request.QueryString.Item("topic").ToString())
                    Me.ViewState("TopicName") = TopicName
                    If TopicName.StartsWith("Category") Then
                        GoToCategory(TopicName)
                    End If
                End If

                Me.DisplayTopic()

            End If
        End Sub

        Private Sub cmdEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
            Me.EditPage()
        End Sub

        Private Sub cmdSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSave.Click
            Me.SaveChanges()
        End Sub

        Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
            Me.CancelChanges()
        End Sub

        Private Sub cmdSaveAndContinue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSaveAndContinue.Click
            Me.SaveAndContinue()
        End Sub

        Private Sub txtViewHistory_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtViewHistory.PreRender
            txtViewHistory.NavigateUrl = "TopicHistory.aspx?topic=" + HttpUtility.UrlEncode(Me.lblPageTopic.Text)
        End Sub

        Private Sub txtAddPicture_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtViewHistory.PreRender
            txtAddPicture.NavigateUrl = "FileUpload.aspx?topic=" + HttpUtility.UrlEncode(Me.lblPageTopic.Text)
        End Sub

        Private Sub cmdXml_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdXml.Click
            Response.Redirect("BlogTopic.aspx?Topic=" + HttpUtility.UrlEncode(Me.lblPageTopic.Text))
        End Sub

        Private Sub cmdTopicSearch_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles cmdTopicSearch.Click
            Response.Redirect(RootObject.SearchPage & "?SearchString=" + Me.ViewState("TopicName"))
        End Sub

#End Region

        Private Sub DisplayTopic()

            Trace.Write("DisplayTopic begin")
            Dim UpdatedOn As String = ""
            Dim Content As String = ""

            Me.lblPageTopic.Text = Me.ViewState("TopicName")
            Me.lblPageTopic.Visible = False
            Me.lblTopicNameOnHeader.Text = Me.ViewState("TopicName")

            If Me.chkPageInEditMode.Checked Or BusinessServices.CheckTopicExists(Me.ViewState("TopicName")) = False Then

                'Me.txtPageContent.Visible = True
                Me.FCKeditor.Visible = True
                InitializeFCKeditor()
                'Me.txtPageContent.Attributes.Add("onkeydown", "return onKeyDown();")
                Me.lblPageContent.Text = ""
                Me.cmdEdit.Visible = False
                ShowOtherOptions(False)
                Me.txtViewHistory.Visible = False
                Me.txtAddPicture.Visible = False
                Me.cmdXml.Visible = False

                If AppSettings.Item("AllowEdit") = "true" Then
                    Me.cmdSave.Visible = True
                    Me.cmdSaveAndContinue.Visible = True
                    Me.cmdCancel.Visible = True
                Else
                    Me.cmdSave.Visible = False
                    Me.cmdSaveAndContinue.Visible = False
                    Me.cmdCancel.Visible = False
                End If

                'Me.txtPageContent.Text = ReadTopic(Me.ViewState("TopicName"), UpdatedOn)
                Dim TopicContent As String = ReadTopic(Me.ViewState("TopicName"), UpdatedOn)
                If TopicContent.IndexOf(RootObject.FckEditorMark) = -1 Then
                    TopicContent = FckEditTopic.ParseTopic(Me.ViewState("TopicName"), TopicContent)
                End If
                Me.FCKeditor.Value = TopicContent
                Me.lblPageContent.Text = ""

            Else

                Me.txtPrint.NavigateUrl = ("./Print.aspx?topic=" & Me.lblPageTopic.Text)
                'Me.txtPageContent.Visible = False
                Me.FCKeditor.Visible = False
                'Me.txtPageContent.Text = ""
                Me.FCKeditor.Value = ""
                Me.lblPageContent.Visible = True
                Me.cmdSave.Visible = False
                Me.cmdSaveAndContinue.Visible = False
                Me.cmdCancel.Visible = False
                Me.txtViewHistory.Visible = True
                ShowOtherOptions(True)

                If AppSettings.Item("AllowEdit") = "true" Then
                    Me.cmdEdit.Visible = True
                    Me.txtAddPicture.Visible = True
                Else
                    Me.cmdEdit.Visible = False
                    Me.txtAddPicture.Visible = False
                End If

                If BusinessServices.CheckTopicExists(Me.ViewState("TopicName")) = True Then
                    Content = ReadTopic(Me.ViewState("TopicName"), UpdatedOn)
                Else
                    Content = "This topic does not yet exist.  Please check back later"
                End If

                Me.lblPageContent.Text = WikiText(Content)
                Me.lblPageContent.Text = Me.lblPageContent.Text.Replace("{TopicName}", Me.ViewState("TopicName"))
                'Me.txtPageContent.Text = ""
                Me.FCKeditor.Value = ""
                Me.cmdXml.Visible = (AppSettings.Item("BlogEnabled") = "true")

            End If

            Me.lblUpdatedOn.Text = UpdatedOn
            Trace.Write("DisplayTopic end")

            Trace.Write("DisplayLeftMenu begin")
            Me.DisplayLeftMenu()
            Trace.Write("DisplayLeftMenu end")

        End Sub

        Private Sub InitializeFCKeditor()

            Dim position As Integer = Request.Url.AbsoluteUri.ToLower.IndexOf(RootObject.HomePage.ToLower())
            If position <> -1 Then
                Me.FCKeditor.BaseHref = Request.Url.AbsoluteUri.Substring(0, position)
            End If

            Me.FCKeditor.ToolbarSet = "DotWiki"
            'Me.FCKeditor.ImageBrowserURL = "http://localhost/DotWiki/pictures/"

        End Sub

        Private Sub ShowOtherOptions(ByVal visible As Boolean)
            Me.txtAddPicture.Visible = visible
            Me.txtPrint.Visible = visible
            Me.txtViewHistory.Visible = visible
            Me.cmdXml.Visible = visible
        End Sub

        Private Sub CancelChanges()
            Me.chkPageInEditMode.Checked = False
            Me.DisplayTopic()
        End Sub

        Private Sub SaveChanges()
            Dim RetVal As String
            Me.chkPageInEditMode.Checked = False
            'RetVal = SaveTopic(Me.lblPageTopic.Text, Me.txtPageContent.Text)
            If (Me.FCKeditor.Value.IndexOf(RootObject.FckEditorMark) = -1) Then
                Me.FCKeditor.Value += RootObject.FckEditorMark
            End If
            RetVal = SaveTopic(Me.lblPageTopic.Text, Me.FCKeditor.Value)
            Me.lblPageContent.Text = RetVal
            If RetVal = "" Then
                Me.DisplayTopic()
            End If
        End Sub

        Private Sub DisplayLeftMenu()
            Trace.Write("DisplayLeftMenu read topic begins")
            Dim TopicContent As String = ReadTopic(RootObject.LeftMenuTopic, "")
            Trace.Write("DisplayLeftMenu read topic ends")
            Trace.Write("DisplayLeftMenu wikitext begins")
            Me.lblLeftMenu.Text = WikiText(TopicContent)
            Trace.Write("DisplayLeftMenu wikitext ends")
        End Sub

        Private Sub SaveAndContinue()
            'SaveTopic(Me.lblPageTopic.Text, Me.txtPageContent.Text)
            SaveTopic(Me.lblPageTopic.Text, Me.FCKeditor.Value)
            Me.DisplayLeftMenu()
        End Sub

        Private Sub EditPage()
            Me.chkPageInEditMode.Checked = True
            Me.DisplayTopic()
        End Sub

        Private Sub GoToCategory(ByVal category As String)
            Response.Redirect(RootObject.SearchPage & "SearchString=" + category)
        End Sub

    End Class

End Namespace
