Namespace DotWiki

    Partial Class NewTopic
        Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            Page.Form.DefaultButton = cmdAddIt.UniqueID
            lblExample.Text = RootObject.NewTopicSample
        End Sub

        Private Sub cmdAddIt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAddIt.Click
            Me.AddTopic()
        End Sub

        Private Sub AddTopic()
            Dim TopicName As String = Me.txtTopicName.Text
            Select Case TopicName.Length
                Case Is = 0
                    Me.lblMessage.Text = "Please indicate the name of the topic to add."
                    Me.lblMessage.Visible = True
                Case Is > 50
                    Me.lblMessage.Text = "Topic Name cannot be longer than 50 characters."
                    Me.lblMessage.Visible = True
                Case Else
                    Dim URL As String = RootObject.HomePage + "?topic=" + HttpUtility.UrlEncode(Wiki.CleanTopicName(TopicName))
                    Me.Response.Redirect(URL)
            End Select
        End Sub

    End Class

End Namespace
