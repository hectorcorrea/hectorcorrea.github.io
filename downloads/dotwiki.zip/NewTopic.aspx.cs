﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class NewTopic : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        lblSample.Text = RootObject.NewTopicSample;

    }
    protected void cmdAdd_Click(object sender, EventArgs e)
    {
        string topicName = TopicParser.CleanTopicName(txtName.Text);
        string url = string.Format("~/{0}?topic={1}", RootObject.EditPage, topicName);
        Server.Transfer(url);
    }
}
