﻿using System;
using System.Web.Security;
using System.Web.UI;

public partial class Login : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Form.DefaultFocus = "Login1";
        Page.Form.DefaultButton = null;

        string u = Request.QueryString["u"];
        string id = Request.QueryString["id"];
        if (!String.IsNullOrEmpty(u) && !string.IsNullOrEmpty(id))
        {
            UnlockUser(u, id);
        }
    }

    protected void Login1_LoginError(object sender, EventArgs e)
    {
        MembershipUser user = Membership.Provider.GetUser(Login1.UserName, false);
        if (user != null && user.IsLockedOut)
        {
            Login1.FailureText = string.Format("Sorry {0}, " +
                "your account has been locked out.\r\n" +
                "The system administrator has been notified.",
                user.UserName);

            // Store a GUID in the user comments and use it for
            // validation purposes before unlocking the account.
            user.Comment = Guid.NewGuid().ToString();
            Membership.Provider.UpdateUser(user);
            
            NotifyAdmin(user.UserName, user.Comment);
        }
        return;
    }

    private void NotifyAdmin(string userAccount, string id)
    {
        /* Admin gets an e-mail notification with a link that 
         * allows him/her to unlock this account. This is
         * particularly useful if a hacker locks the admin
         * account! :) 
         */
        string subject = string.Format("Account has been locked out");
        string body = string.Format("Account for [{0}] has been locked out.\r\n", userAccount);
        string link = string.Format("{0}?u={1}&id={2}", UnlockUrl, userAccount, id);
        body += string.Format("Use this link to unlock it {0}", link);
        Mailer.SendEmail(RootObject.AdminEmail, subject, body);
    }

    private void UnlockUser(string userName, string id)
    {
        MembershipUser user = Membership.Provider.GetUser(userName, false);
        if (user.IsLockedOut)
        {
            // Make sure the value stored in the comments (unlock id)
            // matches the value passed in the URL.
            if (user.Comment == id)
            {
                user.UnlockUser();
                Membership.Provider.UpdateUser(user);
                Response.Redirect("~/Login.aspx?a=unlocked");
            }
            else
            {
                Response.Redirect("~/Login.aspx?a=lock-does-not-match");
            }
        }
        else
        {
            Response.Redirect("~/Login.aspx?a=user-was-not-locked");
        }

    }

    private string UnlockUrl
    {
        get
        {
            string thisUrl = Request.Url.AbsoluteUri;
            string baseUrl = thisUrl.Substring(0, thisUrl.LastIndexOf('/'));
            return baseUrl + "/Login.aspx";
        }
    }

}
