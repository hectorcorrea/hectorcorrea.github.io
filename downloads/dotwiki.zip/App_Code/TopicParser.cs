﻿using System;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Web;

/// <summary>
/// Summary description for TopicParser
/// </summary>
public static class TopicParser
{
    
    /*
     * (?<!topic\=)   does not start with "topic=" (to prevent nested free links)
     * \[\[\[         3 open square brackets
     * .*?            plus any character (non-greedy)
     * \]\]\]         3 close square brackets
     */
    const string FreeLinkWordRegEx = @"(?<!topic\=)\[\[\[.*?\]\]\]"; // .*? means any character (non-greedy)

    /*
     * Regular expression to detect e-mail addresses:
     * \w+                   One or more word characters (a-z, 0-9, _)
     * [@]                   One @
     * [\w|\.]'              One or more word characters or a dot.
     * [^\s|\<|\>|\""]+      One or more non-space characters or < or > or a double quote
     */
    const string EmailRegEx = @"\w+[@][\w|\.]+";

    /*
     * Regular expression to detect HTTP links:
     * (?<=[^\=|\<|\>|\""]\s*)  Ignore links that are prefixed with =, ", <, >, or spaces
     * http://[^\s|\<]+         http:// followed by one or more non-space characters or an <
     */
    const string HttpRegEx = @"(?<=[^\=|\<|\>|\""]\s*)http://[^\s|\<]+";


	static TopicParser()
	{
	}

    public static string WikiText(string rawText)
    {
        string parsedText = rawText + "\r\n";

        parsedText = Regex.Replace(parsedText, EmailRegEx, EncodeEmailAddress);

        parsedText = Regex.Replace(parsedText, FreeLinkWordRegEx, EvaluateFreeLinkWord);

        parsedText = Regex.Replace(parsedText, @"\<img.*?src=.+?\>", EvaluatePopUpImage);
        parsedText = Regex.Replace(parsedText, @"\<thumbnail=.+?\>", EvaluateThumbnail);

        // Special treatment for programming code (new syntax)
        parsedText = Regex.Replace(parsedText, "<code>.*?</code>", EvaluateCode, RegexOptions.Singleline); // .*? means any character (non-greedy)

        // Special treatment for programming code (old deprecated syntax)
        // parsedText = Regex.Replace(parsedText, "<CDE>.*?</CDE>", EvaluateCDE, RegexOptions.Singleline); // .*? means any character (non-greedy)

        return parsedText;
    }
        
    static string EvaluateFreeLinkWord(Match match)
    {
        string topicName = match.Value;
        topicName = CleanTopicName(topicName);
        string link = string.Empty;
        if (Topic.Exists(topicName))
        {
            link = HyperlinkExistingTopic(topicName);
        }
        else if (topicName.StartsWith("Category"))
        {
            link = HyperlinkCategory(topicName);
        }
        else
        {
            link = HyperlinkNonExistingTopic(topicName);
        }
        return link;
    }

    static string HyperlinkCategory(string topicName)
    {
        string link = string.Format(@"<a href=""{0}?s={1}"" " +
                @"title=""Click to search all topics in this category""> " +
                @"<span class=""categorylink"">{2}</span></a>", 
                RootObject.SearchPage, HttpUtility.UrlEncode(topicName), topicName); // See EvaluateCode if you change this line
        return link;
    }

    static string HyperlinkExistingTopic(string topicName)
    {
        string link = string.Format(@"<a href=""{0}?topic={1}"">{2}</a>", 
                RootObject.HomePage, HttpUtility.UrlEncode(topicName), topicName);
        return link;
    }

    static string HyperlinkNonExistingTopic(string topicName)
    {
        string beginStyle = @"<span class=""nonExistingTopicLink"">";
        string endStyle = "</span>";
        string link = String.Format(@"<a href=""{0}?topic={1}"" title=""Click to add topic"">{2}</a>",
                RootObject.HomePage, HttpUtility.UrlEncode(topicName), beginStyle + topicName + endStyle); // See EvaluateCode if you change this line
        return link;
    }
    
    static string EncodeEmailAddress(Match match)
    {
        return ForceHtmlEncoded(match.Value);
    }
    
    /*
     * Notice that we HTML-encode e-mail addresses to prevent
     * spammers from picking them up from our web site.
     */
    static string HyperlinkEmailAddress(Match match)
    {
        string emailAddress = match.Value;
        string MailTo = "mailto:" + emailAddress;
        string link = string.Format( "<a href=\"{0}\">{1}</a>", ForceHtmlEncoded(MailTo), ForceHtmlEncoded(emailAddress) );
        return link;
    }

    static string HyperlinkHttpReference(Match match)
    {
        return String.Format("<a href=\"{0}\" target=\"_blank\">{0}</a>", match.Value);
    }

    /*
     * Parses HTML IMG SRC tags and surrounds them with an anchor tag.
     * If m.value is equal to <img src=folder\file.ext>
     * Result is equal to <a href=...><img src=folder\file.ext></a>
     */
    static string EvaluatePopUpImage(Match match)
    {
        string newImgTag = string.Empty;
        try
        {
            const string noLink = "alt=\"nolink\"";
            if (match.Value.IndexOf(noLink) >= 0)
            {
                newImgTag = match.Value.Replace(noLink,"");
            }
            else
            {
                // Extract image file name from HTML IMG tag.
                Match match2 = Regex.Match(match.Value, @"src=[\""]*.*?[\""|\s|\>]");
                string pictureFile = match2.Value.Substring(4);
                pictureFile = pictureFile.Replace("\"", "");
                pictureFile = pictureFile.Replace("\\", "/");
                pictureFile = pictureFile.Replace("_thumb.", ".");

                //Define HREF to pop up the image
                string viewPicture = string.Format("javascript:viewpicture('{0}','{1}')", "{TopicName}", pictureFile);

                //Define the new text to render
                newImgTag = string.Format("<a href=\"{0}\">{1}</a>", viewPicture, match.Value);
            }
        }
        catch(Exception ex)
        {
            // something went wrong - don't do any translation
            newImgTag = match.Value;
            Logger.LogError("TopicParser.EvaluetePopUpImage", ex);
        } 
        return newImgTag;
    }

    static string EvaluateThumbnail(Match match)
    {
        string newImgTag = string.Empty;
        try
        {
            // Extract image file name from HTML IMG tag.
            Match match2 = Regex.Match(match.Value, @"=[\w\.\\//]*(?=\b)");
            string pictureFile = match2.Value.Substring(1);
            pictureFile = pictureFile.Replace("\\", "/");

            //Define HREF to pop up the image
            string viewPicture = string.Format("javascript:viewpicture('{0}','{1}')", "{TopicName}", pictureFile);

            //Define the new text to render
            string thumbnail = pictureFile.Replace(".", "_thumb.");
            newImgTag = string.Format("<a href=\"{0}\"><img src={1} border=1></a>", viewPicture, thumbnail); 
        }
        catch (Exception ex)
        {
            // something went wrong - don't do any translation
            newImgTag = match.Value;
            Logger.LogError("TopicParser.EvaluetePopUpImage", ex);
        }
        return newImgTag;
    }
    
    static string EvaluateCode(Match match)
    {
        string code = match.Value;

        // Remove all HTML 
        code = Regex.Replace(code, @"<a[^>]*>\?</a>", "");        // ???
        code = Regex.Replace(code, @"<a[^>]*>(.*?)</a>", "$1");   // remove <a> </a> to prevent links
        code = Regex.Replace(code, "<span class=\"dashedlink\"[^>]*>(.*?)</span>", "$1");   // remove dashedlink span (used for non-existing topics)
        code = Regex.Replace(code, "<span class=\"categorylink\"[^>]*>(.*?)</span>", "$1"); // remove categorylink span (used for categories)
        code = HttpUtility.HtmlEncode(code);

        // ...and then add the ones that we want to preserve
        code =  code.Replace("&lt;br /&gt;", "<br />");
        code =  code.Replace("&lt;code&gt;", "<code>");
        code =  code.Replace("&lt;/code&gt;", "</code>");
        code =  code.Replace("&amp;quot;", "\"");

        return code;
    }

    static string EvaluateCDE(Match match)
    {
        string code = match.Value;

        // Remove all HTML 
        code = code.Replace("<br>", "\r");
        code = code.Replace("<CDE>", "");                    // remove opening tag
        code = code.Replace("</CDE>", "");                   // remove closing tag
        code = Regex.Replace(code, @"<a[^>]*>\?</a>", "");          // ???
        code = Regex.Replace(code, @"<a[^>]*>(.*?)</a>", "$1");     // remove <a> </a> to prevent links
        code = Regex.Replace(code, "<span class=\"dashedlink\"[^>]*>(.*?)</span>", "$1");   // remove dashedlink span (used for non-existing topics)
        code = Regex.Replace(code, "<span class=\"categorylink\"[^>]*>(.*?)</span>", "$1"); // remove categorylink span (used for categories)

        code = string.Format("<table class=\"sourcecode\"><tr><td><PRE>{0}</PRE></td></tr></table>",
            HttpUtility.HtmlEncode(code));

        return code;
    }

    static string ForceHtmlEncoded(string text)
    {
        string encoded = string.Empty;
        for (int i = 0; i < text.Length; i++)
        {
            encoded += "&#" + ((int)text[i]).ToString() + ";";
        }
        return encoded;
    }

    static public string CleanTopicName(string originalName)
    {
        string cleanName = string.Empty;
        for (int i = 0; i < originalName.Length; i++)
        {
            char c = originalName[i];
            cleanName += Char.IsLetterOrDigit(c) ? c : ' ';
        }

        while(cleanName.Contains("  "))
        {
            cleanName = cleanName.Replace("  ", " ");
        }
        return cleanName.Trim();
    }

    static public string CleanUrlTopicName(string originalName)
    {
        string cleanName = HttpUtility.UrlDecode(originalName.Trim());
        return CleanTopicName(cleanName);
    }

    
}
