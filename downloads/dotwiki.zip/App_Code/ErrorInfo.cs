﻿using System;
using Csla;

[Serializable()]
public class ErrorInfo : ReadOnlyBase<ErrorInfo>
{
    #region Business Methods

    private Guid _id;
    private string _name;
    private DateTime _day;
    private string _content;

    public Guid Id
    {
        get { return _id; }
    }

    public string Name
    {
        get { return _name; }
    }

    public DateTime Day
    {
        get { return _day; }
    }

    public string Content
    {
        get { return _content; }
    }

    protected override object GetIdValue()
    {
        return _id;
    }

    public override string ToString()
    {
        return _name;
    }

    #endregion

    #region Constructors

    private ErrorInfo()
    { /* require use of factory methods */ }

    internal ErrorInfo(Guid id, DateTime day, string name)
    {
        _id = id;
        _day = day;
        _name = name;
    }

    internal ErrorInfo(Guid id, DateTime day, string name, string content)
    {
        _id = id;
        _day = day;
        _name = name;
        _content = content;
    }

    #endregion
}
