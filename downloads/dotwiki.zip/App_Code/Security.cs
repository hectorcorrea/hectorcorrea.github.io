﻿using System;
using System.Configuration;
using System.Security.Principal;
using System.Web.Security;


public enum SecureModeEnum
{
    Simple, Full 
}

public static class Security
{

    private static SecureModeEnum _secureMode = SecureModeEnum.Simple;
    private static bool _guestCanEdit;
    private static bool _guestCanAddPicture;
    private static bool _guestCanRestore;
    private static bool _guestCanViewErrorLog;
    private static bool _guestCanAddUser;
    private static bool _useFriendlyPassword;
    private static bool _securitySetup;
    private static bool _hasSecurityBeenInitialized = false;

    public static bool TestSecurity()
    {
        if (!_hasSecurityBeenInitialized)
        {
            string infoMessage = string.Empty;

            string secureModeSetting = ConfigurationManager.AppSettings["SecureMode"].ToString();
            _secureMode = (secureModeSetting == "full") ? SecureModeEnum.Full : SecureModeEnum.Simple;

            string setting;
            setting = ConfigurationManager.AppSettings["GuestCanEdit"].ToString();
            _guestCanEdit = (setting == "true");

            setting = ConfigurationManager.AppSettings["GuestCanAddPicture"].ToString();
            _guestCanAddPicture = (setting == "true");

            setting = ConfigurationManager.AppSettings["GuestCanRestore"].ToString();
            _guestCanRestore = (setting == "true");

            setting = ConfigurationManager.AppSettings["GuestCanViewErrorLog"].ToString();
            _guestCanViewErrorLog = (setting == "true");

            setting = ConfigurationManager.AppSettings["GuestCanAddUser"].ToString();
            _guestCanAddUser = (setting == "true");

            setting = ConfigurationManager.AppSettings["UseFriendlyPassword"].ToString();
            _useFriendlyPassword = (setting == "true");

            if (_secureMode == SecureModeEnum.Simple)
            {
                _securitySetup = true;
                infoMessage = "Security mode is simple";
            }
            else
            {
                infoMessage = "Security mode is full.";
                if (RootObject.IsDatabaseTested)
                {
                    bool adminRoleExist = Roles.RoleExists(Security.AdminRole);
                    bool userRoleExist = Roles.RoleExists(Security.UserRole);
                    int adminUsersCount = Roles.GetUsersInRole(Security.AdminRole).Length;
                    _securitySetup = adminRoleExist && userRoleExist && (adminUsersCount > 0);
                    if (!_securitySetup)
                    {
                        infoMessage += string.Format("\r\nSecurity could not be setup." +
                            "\r\nAdmin role={0} User role={1} Admin count={2}",
                            adminRoleExist, userRoleExist, adminUsersCount);
                        Logger.LogInfo("Initializing Security", infoMessage);
                    }
                    else
                    {
                        infoMessage += "\r\nSecurity has been setup.";
                    }
                }
                else
                {
                    infoMessage += "\r\nDatabase is not setup.";
                    Logger.LogInfo("Initializing Security", infoMessage);
                }
            }

            //Logger.LogInfo("Initializing Security", infoMessage);
            
            _hasSecurityBeenInitialized = true;
        }

        return _hasSecurityBeenInitialized;
    }

    
    public static SecureModeEnum SecureMode
    {
        get { return _secureMode; }
    }

    public static bool UseFriendlyPassword
    {
        get { return _useFriendlyPassword; }
    }

    public static string AdminRole
    {
        get { return "admin"; }
    }

    public static string UserRole
    {
        get { return "user"; }
    }

    public static bool IsSecuritySetup
    {
        get { return _securitySetup;}
    }

    public static bool UserCanEdit(IPrincipal user)
    {
        bool canDoIt = false;
        if (_secureMode == SecureModeEnum.Simple)
        {
            canDoIt = true;
        }
        else
        {
            canDoIt = _guestCanEdit? true: user.Identity.IsAuthenticated;
        }
        return canDoIt;
    }

    public static bool UserCanRestore(IPrincipal user)
    {
        bool canDoIt = false;
        if (_secureMode == SecureModeEnum.Simple)
        {
            canDoIt = true;
        }
        else
        {
            canDoIt = _guestCanRestore? true : user.Identity.IsAuthenticated;
        }
        return canDoIt;
    }

    public static bool UserCanAddPicture(IPrincipal user)
    {
        bool canDoIt = false;
        if (_secureMode == SecureModeEnum.Simple)
        {
            canDoIt = true;
        }
        else
        {
            canDoIt = _guestCanAddPicture ? true : user.Identity.IsAuthenticated;
        }
        return canDoIt;
    }

    public static bool UserCanViewErrorLog(IPrincipal user)
    {
        bool canDoIt = false;
        if (_secureMode == SecureModeEnum.Simple)
        {
            canDoIt = true;
        }
        else
        {
            canDoIt = _guestCanViewErrorLog ? true : user.Identity.IsAuthenticated;
        }
        return canDoIt;
    }

    public static bool UserCanAddUser(IPrincipal user)
    {
        bool canDoIt = false;
        if (_secureMode == SecureModeEnum.Simple)
        {
            // Users are not supported in simple mode.
            canDoIt = false;
        }
        else
        {
            canDoIt = _guestCanAddUser ? true : user.IsInRole(Security.AdminRole);
        }
        return canDoIt;
    }

    public static bool UserCanAddAdminUser(IPrincipal user)
    {
        bool canDoIt = false;
        if (_secureMode == SecureModeEnum.Simple)
        {
            // Users are not supported in simple mode.
            canDoIt = false;
        }
        else
        {
            canDoIt = user.IsInRole(Security.AdminRole);
        }
        return canDoIt;
    }
    
    public static bool UserCanDelete(IPrincipal user)
    {
        bool canDoIt = false;
        if (_secureMode == SecureModeEnum.Simple)
        {
            canDoIt = false;
        }
        else
        {
            canDoIt = user.IsInRole(Security.AdminRole);
        }
        return canDoIt;
    }

    public static bool UserCanChangePassword(IPrincipal user)
    {
        bool canDoIt = false;
        if (_secureMode == SecureModeEnum.Simple)
        {
            // Users not supported in simple mode
            canDoIt = false;
        }
        else
        {
            canDoIt = user.Identity.IsAuthenticated;
        }
        return canDoIt;
    }

    public static void SetupSecurity()
    {
        if (Security.SecureMode == SecureModeEnum.Full)
        {
            SetupRoles();
            SetupDefaultAdmin();
        }
        _securitySetup = true;
    }
    
    private static void SetupRoles()
    {
        if (!Roles.RoleExists(Security.AdminRole))
        {
            Roles.CreateRole(Security.AdminRole);
        }
        if (!Roles.RoleExists(Security.UserRole))
        {
            Roles.CreateRole(Security.UserRole);
        }
    }

    private static void SetupDefaultAdmin()
    {
        if (Roles.GetUsersInRole(Security.AdminRole).Length == 0)
        {
            string defaultAdminUser = ConfigurationManager.AppSettings["DefaultAdminUser"].ToString();
            string defaultAdminPassword = ConfigurationManager.AppSettings["DefaultAdminPassword"].ToString();
            string defaultAdminQuestion = ConfigurationManager.AppSettings["DefaultAdminQuestion"].ToString();
            string defaultAdminAnswer = ConfigurationManager.AppSettings["DefaultAdminAnswer"].ToString();
            MembershipCreateStatus status;
            Membership.CreateUser(defaultAdminUser, defaultAdminPassword, RootObject.AdminEmail,
                defaultAdminQuestion, defaultAdminAnswer, true, out status);
            if (status != MembershipCreateStatus.Success)
            {
                string errorMsg = string.Format("Could not create default admin user. Reason: {0}", status.ToString());
                throw new Exception(errorMsg);
            }
            Roles.AddUserToRole(defaultAdminUser, Security.AdminRole);
        }
    }

    public static string FormatUpdatedOn(string username, DateTime updatedOn)
    {
        return FormatUpdatedOn(username, updatedOn, null);
    }

    public static string FormatUpdatedOn(string username, DateTime updatedOn, string friendlyTime)
    {
        string updateInfo;
        if (Security.SecureMode == SecureModeEnum.Simple)
        {
            updateInfo = string.Format("Last updated on {0}", updatedOn);
        }
        else
        {
            if (String.IsNullOrEmpty(username))
            {
                updateInfo = string.Format("Last updated by guest user on {0}", updatedOn);
            }
            else
            {
                updateInfo = string.Format("Last updated by {0} on {1}", username, updatedOn);
            }
        }
        if (friendlyTime != null)
        {
            updateInfo += string.Format(" ({0})", friendlyTime);
        }
        return updateInfo;
    }

}
