﻿using System;
using System.IO;
using Csla;

[Serializable()]
public class ErrorList : ReadOnlyListBase<ErrorList, ErrorInfo>
{
    #region Factory Methods

    public static ErrorList GetAll(string errorLogPath)
    {
        return DataPortal.Fetch<ErrorList>(new Criteria(errorLogPath));
    }

    public static ErrorList GetAll(string errorLogPath, string logFile)
    {
        return DataPortal.Fetch<ErrorList>(new Criteria(errorLogPath, logFile));
    }

    private ErrorList()
    { /* require use of factory methods */ }

    #endregion

    #region Criteria Class

    [Serializable()]
    private class Criteria
    {
        private string _logPath = null;
        private string _logFile = null;

        public string LogPath { get { return _logPath; } }
        public string LogFile { get { return _logFile; } }

        public Criteria(string path)
        {
            _logPath = path;
        }

        public Criteria(string path, string file)
        {
            _logPath = path;
            _logFile = file;
        }
    }


    #endregion

    #region Data Access

    private void DataPortal_Fetch(Criteria criteria)
    {
        if (criteria.LogFile == null)
            FetchList(criteria.LogPath);
        else
            FetchOne(criteria.LogPath, criteria.LogFile);
    }

    private void FetchList(string path)
    {
        this.RaiseListChangedEvents = false;
        IsReadOnly = false;

        try
        {
            IsReadOnly = false;
            string[] logFiles = Directory.GetFiles(path, "*.txt");
            Array.Reverse(logFiles);

            foreach (string logFile in logFiles)
            {
                Guid id = Guid.NewGuid();
                string name = Path.GetFileName(logFile);
                DateTime day = File.GetCreationTime(logFile);
                ErrorInfo info = new ErrorInfo(id, day, name);
                Add(info);
            }
            IsReadOnly = true;
        }
        catch (Exception ex)
        {
            Logger.LogError("Fetch", ex);
            throw ex;
        }

        IsReadOnly = true;
        this.RaiseListChangedEvents = true;
    }

    //TODO: This should go to a Error class inherited from BusinessBase 
    //      rather than from a ReadOnlyListBase with just one element. 
    private void FetchOne(string path, string logFile)
    {
        this.RaiseListChangedEvents = false;
        IsReadOnly = false;

        try
        {
            IsReadOnly = false;
            Guid id = Guid.NewGuid();
            string name = Path.GetFileName(logFile);
            DateTime day = File.GetCreationTime(logFile);
            string content = File.ReadAllText(Path.Combine(path, logFile));
            ErrorInfo info = new ErrorInfo(id, day, name, content);
            Add(info);
            IsReadOnly = true;
        }
        catch (Exception ex)
        {
            Logger.LogError("Fetch with Details", ex);
            throw ex;
        }

        IsReadOnly = true;
        this.RaiseListChangedEvents = true;
    }

    #endregion
}
