﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Csla;
using Csla.Data;
using System.Configuration;

[Serializable()]
public class TopicHistoryList : ReadOnlyListBase<TopicHistoryList, TopicHistoryInfo>
{
    #region Factory Methods

    public static TopicHistoryList GetAll(Guid topicPK)
    {
        return DataPortal.Fetch<TopicHistoryList>(new Criteria(topicPK));
    }

    public static TopicHistoryList GetLatestChanges(Guid topicPK, int howManyChanges)
    {
        return DataPortal.Fetch<TopicHistoryList>(new Criteria(topicPK, howManyChanges));
    }

    private TopicHistoryList()
    { /* require use of factory methods */ }

    #endregion

    #region Data Access

    [Serializable()]
    private class Criteria
    {
        private int _howManyChanges = -1;
        private Guid _topicPK = Guid.Empty;

        public int HowManyChanges { get { return _howManyChanges; } }
        public Guid TopicPK { get { return _topicPK; } }

        public Criteria(Guid topicPK)
        {
            _topicPK = topicPK;
            _howManyChanges = -1;
        }

        public Criteria(Guid topicPK, int howManyChanges)
        {
            _topicPK = topicPK;
            _howManyChanges = howManyChanges;
        }
    }

    private void DataPortal_Fetch(Criteria criteria)
    {
        this.RaiseListChangedEvents = false;
        IsReadOnly = false;

        try
        {
            string topClause = string.Empty;
            if (criteria.HowManyChanges != -1)
            {
                topClause = string.Format("top {0}", criteria.HowManyChanges);
            }

            string connString = ConfigurationManager.ConnectionStrings["DotWikiDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                using (SqlCommand command = conn.CreateCommand())
                {
                    command.CommandType = CommandType.Text;
                    command.CommandText = string.Format(
                        "select {0} [name], updatedon, topichistorypk, topicfk " +
                        "from topichistory " +
                        "where topicfk = @TopicPK and wikiset = @WikiSet " +
                        "order by updatedon desc", topClause);
                    command.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet);
                    command.Parameters.AddWithValue("@TopicPK", criteria.TopicPK);
                    using (SafeDataReader dr = new SafeDataReader(command.ExecuteReader()))
                    {
                        //bool needToAddCurrent = true;
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            //TODO: finish this to include the current version as part of the history
                            //if (needToAddCurrent)
                            //{
                            //    TopicHistoryInfo info0 = new TopicHistoryInfo(Guid.Empty, "(pending)", DateTime.MaxValue, Guid.Empty);
                            //    Add(info0);
                            //    needToAddCurrent = false;
                            //}
                            Guid id = dr.GetGuid("topichistorypk");
                            Guid fk = dr.GetGuid("topicfk");
                            string topicName = dr.GetString("name").Trim();
                            DateTime updatedOn = dr.GetDateTime("updatedon");
                            TopicHistoryInfo info = new TopicHistoryInfo(id, topicName, updatedOn, fk);
                            Add(info);
                        }
                        IsReadOnly = true;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Logger.LogError("FetchAll", ex);
            throw ex;
        }

        IsReadOnly = true;
        this.RaiseListChangedEvents = true;

    }

    #endregion
}
