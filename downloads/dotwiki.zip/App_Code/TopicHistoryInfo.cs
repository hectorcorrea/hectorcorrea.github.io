﻿using System;
using Csla;

[Serializable()]
public class TopicHistoryInfo : ReadOnlyBase<TopicHistoryInfo>
{
    #region Business Methods

    private Guid _id;
    private string _name;
    private DateTime _updatedOn;
    private Guid _topicFK;

    public Guid Id
    {
        get { return _id; }
    }

    public string Name
    {
        get { return _name; }
    }

    public DateTime UpdatedOn
    {
        get { return _updatedOn; }
    }


    public Guid TopicFK
    {
        get { return _topicFK; }
    }
    
    protected override object GetIdValue()
    {
        return _id;
    }

    public override string ToString()
    {
        return _name;
    }

    #endregion

    #region Constructors

    private TopicHistoryInfo()
    { /* require use of factory methods */ }

    internal TopicHistoryInfo(Guid id, string name, DateTime updatedOn, Guid topicFK)
    {
        _id = id;
        _name = name;
        _updatedOn = updatedOn;
        _topicFK = topicFK;
    }

    #endregion
}
