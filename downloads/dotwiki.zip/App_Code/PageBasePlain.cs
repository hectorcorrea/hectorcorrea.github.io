﻿/// <summary>
/// Base class for pages that do not need the standard style defined via styles.css.
/// </summary>
public class PageBasePlain : PageBase
{
    /// <summary>
    /// Override the Page.StyleSheetTheme property to prevent using the current user's profile.
    /// </summary>
    public override string StyleSheetTheme
    {
        get
        {
            return ""; 
        }
        set
        {
            // do nothing
        }
    }

}
