using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Csla;
using Csla.Data;
using System.Configuration;

public enum GetLatest
{
    Last24Hours = 1,    // 1 day
    Last7Days = 7,
    Last30Days = 30,
    Last50Changes = 50
}

public enum SearchType
{
    All = 1,
    Search = 2,
    Index = 3,
    Recent = 4,
    Trashcan = 5
}

[Serializable()]
public class TopicList : ReadOnlyListBase<TopicList, TopicInfo>
{
    #region Factory Methods
    
    public static TopicList GetAll()
    {
        return DataPortal.Fetch<TopicList>( new Criteria(SearchType.All));
    }

    public static TopicList Search(string textToSearch)
    {
        return DataPortal.Fetch<TopicList>(new Criteria(SearchType.Search, textToSearch));
    }
    
    public static TopicList GetRecentChanges(GetLatest latestChanges)
    {
        return DataPortal.Fetch<TopicList>( new Criteria(SearchType.Recent, latestChanges));
    }

    public static TopicList GetIndex(char letter)
    {
        return DataPortal.Fetch<TopicList>(new Criteria(SearchType.Index, letter));
    }

    public static TopicList GetTrashcan()
    {
        return DataPortal.Fetch<TopicList>(new Criteria(SearchType.Trashcan));
    }

    private TopicList()
    { /* require use of factory methods */ }

    #endregion

    #region Data Access

    [Serializable()]
    private class Criteria
    {
        private SearchType _type = SearchType.All;
        private GetLatest _latest;
        private string _textToSearch = null;
        private char _letterToSearch = ' ';

        public SearchType Type { get { return _type; } }
        public GetLatest Latest { get { return _latest; } }
        public string TextToSearch { get { return _textToSearch; } }
        public char LetterToSearch { get { return _letterToSearch; } }

        public Criteria(SearchType type, GetLatest latest)
        {
            _type = type;
            _latest = latest;
        }

        public Criteria(SearchType type, string textToSearch)
        {
            _type = type;
            _textToSearch = textToSearch;
        }

        public Criteria(SearchType type, char letterToSearch)
        {
            _type = type;
            _letterToSearch = letterToSearch;
        }

        public Criteria(SearchType type)
        {
            _type = type;
        }

    }

    private void DataPortal_Fetch(Criteria criteria)
    {
        switch (criteria.Type)
        {
            case SearchType.All:
                FetchAll();
                break;
            case SearchType.Search:
                FetchSearch(criteria.TextToSearch);
                break;
            case SearchType.Index:
                FetchIndex(criteria.LetterToSearch);
                break;
            case SearchType.Recent:
                if (criteria.Latest == GetLatest.Last50Changes)
                {
                    int count = (int)GetLatest.Last50Changes;
                    FetchLast(count);
                }
                else
                {
                    int days = (int)criteria.Latest;
                    FetchRecent(days);
                }
                break;
            case SearchType.Trashcan:
                FetchTrashcan();
                break;
        }
    }

    private void FetchRecent(int days)
    {
        this.RaiseListChangedEvents = false;
        IsReadOnly = false;

        try
        {
            string connString = ConfigurationManager.ConnectionStrings["DotWikiDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                using (SqlCommand command = conn.CreateCommand())
                {
                    command.CommandType = CommandType.Text;
                    command.CommandText = "select topicpk, name, updatedon, <<usernamefield>> " +
                        "from topic " +
                        "<<getusername>> " +
                        "where DateDiff(d, updatedon, getdate()) <= @Days and WikiSet = @WikiSet " +
                        "order by updatedon desc";
                    command.Parameters.Add("@Days", SqlDbType.Int);
                    command.Parameters["@Days"].Value = days;
                    command.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet);
                    if (Security.SecureMode == SecureModeEnum.Full)
                    {
                        command.CommandText = command.CommandText.Replace("<<usernamefield>>", "u.username as username");
                        command.CommandText = command.CommandText.Replace("<<getusername>>", "left outer join aspnet_users u on topic.userid = u.userid");
                    }
                    else
                    {
                        command.CommandText = command.CommandText.Replace("<<usernamefield>>", "'' as username");
                        command.CommandText = command.CommandText.Replace("<<getusername>>", "");
                    }
                    using (SafeDataReader dr = new SafeDataReader(command.ExecuteReader()))
                    {
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            Add(dr, true);
                        }
                        IsReadOnly = true;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Logger.LogError("FetchRecent", ex);
            throw ex;
        }        

        IsReadOnly = true;
        this.RaiseListChangedEvents = true;

    }

    private void FetchLast(int count)
    {
        this.RaiseListChangedEvents = false;
        IsReadOnly = false;

        try
        {
            string connString = ConfigurationManager.ConnectionStrings["DotWikiDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                using (SqlCommand command = conn.CreateCommand())
                {
                    command.CommandType = CommandType.Text;
                    command.CommandText = string.Format(
                        "select top {0} topicpk, name, updatedon, <<usernamefield>> " +
                        "from topic " +
                        "<<getusername>> " +
                        "where WikiSet = @WikiSet " +
                        "order by updatedon desc", count);
                    command.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet);
                    if (Security.SecureMode == SecureModeEnum.Full)
                    {
                        command.CommandText = command.CommandText.Replace("<<usernamefield>>", "u.username as username");
                        command.CommandText = command.CommandText.Replace("<<getusername>>", "left outer join aspnet_users u on topic.userid = u.userid");
                    }
                    else
                    {
                        command.CommandText = command.CommandText.Replace("<<usernamefield>>", "'' as username");
                        command.CommandText = command.CommandText.Replace("<<getusername>>", "");
                    }
                    using (SafeDataReader dr = new SafeDataReader(command.ExecuteReader()))
                    {
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            Add(dr, true);
                        }
                        IsReadOnly = true;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Logger.LogError("FetchLast", ex);
            throw ex;
        }

        IsReadOnly = true;
        this.RaiseListChangedEvents = true;

    }

    private void FetchSearch(string textToSearch)
    {
        this.RaiseListChangedEvents = false;
        IsReadOnly = false;

        try
        {
            string connString = ConfigurationManager.ConnectionStrings["DotWikiDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                using (SqlCommand command = conn.CreateCommand())
                {
                    command.CommandType = CommandType.Text;
                    command.CommandText = "select topicpk, name, updatedon " +
                        "from topic " +
                        "where (name like @TextToSearch or content like @TextToSearch) and WikiSet = @WikiSet " +
                        "order by updatedon desc";
                    textToSearch = "%" + textToSearch.Trim() + "%";
                    command.Parameters.AddWithValue("@TextToSearch", textToSearch);
                    command.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet);
                    using (SafeDataReader dr = new SafeDataReader(command.ExecuteReader()))
                    {
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            Add(dr);
                        }
                        IsReadOnly = true;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Logger.LogError("FetchSearch", ex);
            throw ex;
        }        

        IsReadOnly = true;
        this.RaiseListChangedEvents = true;

    }

    private void FetchIndex(char letter)
    {
        this.RaiseListChangedEvents = false;
        IsReadOnly = false;

        try
        {
            string connString = ConfigurationManager.ConnectionStrings["DotWikiDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                using (SqlCommand command = conn.CreateCommand())
                {
                    command.CommandType = CommandType.Text;
                    command.CommandText = "select topicpk, name, updatedon " + 
                        "from topic " + 
                        "where WikiSet = @WikiSet and Name like @Name " + 
                        "order by name";
                    command.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet);
                    command.Parameters.AddWithValue("@Name", letter + "%");
                    using (SafeDataReader dr = new SafeDataReader(command.ExecuteReader()))
                    {
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            Add(dr);
                        }
                        IsReadOnly = true;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Logger.LogError("FetchAll", ex);
            throw ex;
        }

        IsReadOnly = true;
        this.RaiseListChangedEvents = true;

    }

    private void FetchAll()
    {
        this.RaiseListChangedEvents = false;
        IsReadOnly = false;

        try
        {
            string connString = ConfigurationManager.ConnectionStrings["DotWikiDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                using (SqlCommand command = conn.CreateCommand())
                {
                    command.CommandType = CommandType.Text;
                    command.CommandText = "select topicpk, name, updatedon from topic where WikiSet = @WikiSet order by name";
                    command.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet);
                    using (SafeDataReader dr = new SafeDataReader(command.ExecuteReader()))
                    {
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            Add(dr);
                        }
                        IsReadOnly = true;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Logger.LogError("FetchAll", ex);
            throw ex;
        }        

        IsReadOnly = true;
        this.RaiseListChangedEvents = true;
        
    }

    private void FetchTrashcan()
    {
        this.RaiseListChangedEvents = false;
        IsReadOnly = false;

        try
        {
            string connString = ConfigurationManager.ConnectionStrings["DotWikiDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                using (SqlCommand command = conn.CreateCommand())
                {
                    command.CommandType = CommandType.Text;
                    command.CommandText = "select name, topicfk as topicpk, max(updatedon) as updatedon " +
                        "from topicHistory " +
                        "where topicfk not in (select topicpk from topic) " +
                        "and wikiset = @WikiSet " +
                        "group by name, topicfk " +
                        "order by 3 desc";   
                    command.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet);
                    using (SafeDataReader dr = new SafeDataReader(command.ExecuteReader()))
                    {
                        IsReadOnly = false;
                        while (dr.Read())
                        {
                            Add(dr);
                        }
                        IsReadOnly = true;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Logger.LogError("FetchTrashcan", ex);
            throw ex;
        }

        IsReadOnly = true;
        this.RaiseListChangedEvents = true;

    }

    private void Add(SafeDataReader dr)
    {
        Add(dr, false);
    }

    private void Add(SafeDataReader dr, bool readUserName)
    {
        Guid id = dr.GetGuid("topicpk");
        string name = dr.GetString("name");
        DateTime updatedOn = dr.GetDateTime("updatedon");
        string updatedBy = "";
        if (readUserName) updatedBy = dr.GetString("username");
        TopicInfo info = new TopicInfo(id, name, updatedOn, updatedBy);
        Add(info);
    }
    #endregion
}
    