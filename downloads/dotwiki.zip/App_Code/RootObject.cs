using System;
using System.Data;
using System.Configuration;
using System.Security.Principal;
using System.Data.SqlClient;

public static class RootObject
{
    private static string _wikiSet = string.Empty;
    private static string _homeTopic = string.Empty;
    private static string _navigationMenuTopic = string.Empty;
    private static string _newTopicSample = string.Empty;
    private static string _fckeditor_BaseHref = string.Empty;
    private static string _uploadPath = string.Empty;
    private static string _uploadPassword = string.Empty;
    private static int _uploadMaxSizeKB = 0;
    private static string _restorePassword = string.Empty;
    private static bool _isDatabaseTested = false;

    public static string HomePage
    {
        get { return "Default.aspx"; }
    }

    public static void TestAccessToDatabase()
    {
        if (!_isDatabaseTested)
        {
            string connString = ConfigurationManager.ConnectionStrings["DotWikiDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                using (SqlCommand command = conn.CreateCommand())
                {
                    command.CommandType = CommandType.Text;
                    command.CommandText = "select topicpk from topic where 2=1";
                    command.ExecuteNonQuery();
                }
            }
            _isDatabaseTested = true;
        }
    }

    public static bool IsDatabaseTested
    {
        get { return _isDatabaseTested; }
    }

    public static string EditPage
    {
        get { return "Edit.aspx"; }
    }

    public static string SearchPage
    {
        get { return "Search.aspx"; }
    }

    public static string PrintPage
    {
        get { return "Print.aspx"; }
    }

    public static string HistoryPage
    {
        get { return "TopicHistory.aspx"; }
    }

    public static string DeletePage
    {
        get { return "DeleteTopic.aspx"; }
    }

    public static string AddPicturePage
    {
        get { return "UploadPicture.aspx"; }
    }

    public static string ErrorLogPage
    {
        get { return "ErrorViewer.aspx"; }
    }

    //public static string FckEditorMark 
    //{
    //    get { return "<!-- fckeditor -->"; } 
    //}

    public static string WikiSet
    {
        get 
        {
            if (_wikiSet == string.Empty)
            {
                _wikiSet = ConfigurationManager.AppSettings["WikiSet"].ToString();
            }
            return _wikiSet;
        }
    }

    public static string HomeTopic
    {
        get
        {
            if (_homeTopic== string.Empty)
            {
                _homeTopic = ConfigurationManager.AppSettings["HomeTopic"].ToString();
            }
            return _homeTopic;
        }
    }


    public static string NavigationMenuTopic
    {
        get
        {
            if (_navigationMenuTopic == string.Empty)
            {
                if (ConfigurationManager.AppSettings["NavigationMenuTopic"] != null)
                {
                    _navigationMenuTopic = ConfigurationManager.AppSettings["NavigationMenuTopic"].ToString();
                }
                else
                {
                    // try with the old setting
                    _navigationMenuTopic = ConfigurationManager.AppSettings["LeftMenuTopic"].ToString();
                }
            }
            return _navigationMenuTopic;
        }
    }

    public static string NewTopicSample
    {
        get
        {
            if (_newTopicSample == string.Empty)
            {
                _newTopicSample = ConfigurationManager.AppSettings["NewTopicSample"].ToString();
            }
            return _newTopicSample;
        }
    }

    public static string TopicUrl(string topicName)
    {
        string url = string.Format("~/{0}?topic={1}", 
            RootObject.HomePage, 
            System.Web.HttpUtility.UrlEncode(topicName));
        return url;
    }

    public static string FCKeditor_BaseHref
    {
        get
        {
            if (_fckeditor_BaseHref == string.Empty)
            {
                _fckeditor_BaseHref = ConfigurationManager.AppSettings["FCKeditor:BaseHref"].ToString();
            }
            return _fckeditor_BaseHref;
        }
    }

    public static string UploadPath
    {
        get
        {
            if (_uploadPath == string.Empty)
            {
                _uploadPath = ConfigurationManager.AppSettings["UpLoadPath"].ToString();
            }
            return _uploadPath;
        }
    }

    public static int UploadMaxSizeKB
    {
        get
        {
            if (_uploadMaxSizeKB == 0)
            {
                Int32.TryParse(ConfigurationManager.AppSettings["UpLoadMaxSize"].ToString(), out _uploadMaxSizeKB);
            }
            return _uploadMaxSizeKB;
        }
    }

    public static string UploadPassword
    {
        get
        {
            if (_uploadPassword == string.Empty)
            {
                _uploadPassword = ConfigurationManager.AppSettings["UploadPassword"].ToString();
            }
            return _uploadPassword;
        }
    }

    public static string RestorePassword
    {
        get
        {
            if (_restorePassword == string.Empty)
            {
                _restorePassword = ConfigurationManager.AppSettings["RestorePassword"].ToString();
            }
            return _restorePassword;
        }
    }


    public static string AdminEmail
    {
        get
        {
            return ConfigurationManager.AppSettings["AdminEmail"].ToString();
        }
    }

    
    public static string HtmlError(string errorMsg, string topicName, IPrincipal user)
    {
        string htmlError = string.Format("<h1>Error</h1>" +
        "<p><b>Description:</b> {0}<br/>" + 
        "<b>Topic:</b> {1}<br/></p>" +
        "<p>The error has been logged for the web site's administrator to review.</p>", errorMsg, topicName);
        if (user != null)
        {
            if(Security.UserCanViewErrorLog(user))
            {
                htmlError += string.Format("<p>Click <a href={0}>here</a> to view the errorlog</p>", RootObject.ErrorLogPage);
            }
        }
        return htmlError; 
    }
}
