using System;
using Csla;

[Serializable()]
public class TopicInfo : ReadOnlyBase<TopicInfo>
{
    #region Business Methods

    private Guid _id;
    private string _name;
    private string _url;
    private DateTime _updatedOn;
    private string _updatedBy;

    public Guid Id
    {
        get { return _id; }
    }

    public string Name
    {
        get { return _name; }
    }

    public DateTime UpdatedOn
    {
        get { return _updatedOn; }
    }

    public string Url
    {
        get { return _url; }
    }

    public string UpdatedBy
    {
        get 
        {
            if (Security.SecureMode == SecureModeEnum.Simple) return "";
            if (string.IsNullOrEmpty(_updatedBy)) return "Guest";
            return _updatedBy; 
        }
    }

    protected override object GetIdValue()
    {
        return _id;
    }

    public override string ToString()
    {
        return _name;
    }

    #endregion

    #region Constructors

    private TopicInfo()
    { /* require use of factory methods */ }

    internal TopicInfo(Guid id, string name, DateTime updatedOn)
    {
        _id = id;
        _name = name;
        _updatedOn = updatedOn;
        _url = System.Web.HttpUtility.UrlEncode(name.Trim());
        _updatedBy = "";
    }

    internal TopicInfo(Guid id, string name, DateTime updatedOn, string updatedBy)
    {
        _id = id;
        _name = name;
        _updatedOn = updatedOn;
        _url = System.Web.HttpUtility.UrlEncode(name.Trim());
        _updatedBy = updatedBy;
    }

#endregion
}
