using System;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Web;

public static class Logger
{

    static private string _logFile = null;
    static private DateTime lastLogDate = DateTime.Today.AddDays(-1);

    static private string LogFile
    {
        get
        {
            if (lastLogDate != DateTime.Today)
            {
                lastLogDate = DateTime.Today;
                //string path = Path.Combine(HttpContext.Current.Request.PhysicalApplicationPath, ConfigurationManager.AppSettings["LoggerPath"]);
                string file = string.Format("Logger{0}.txt", DateTime.Today.Date.ToString("yyyy_MM_dd"));
                _logFile = Path.Combine(LogPath, file);
            }
            return _logFile;
        }
    }
    static public string LogPath
    {
        get
        {
            return Path.Combine(HttpContext.Current.Request.PhysicalApplicationPath, ConfigurationManager.AppSettings["LoggerPath"]);     
        }
    }

    static public void LogError(string caption, object moreInfo)
    {
        if (moreInfo == null)
        {
            LogText("ERROR", caption, "moreInfo is null");
        }
        else if (moreInfo is HttpApplication)
        {
            HttpApplication app = (HttpApplication)moreInfo;
            if (app == null)
            {
                LogText("ERROR", caption, "HttpApplication is null");
            }
            else if (app.Request == null)
            {
                LogText("ERROR", caption, "HttpApplication.Request is null");
            }
            else
            {
                string text = RequestToString(app.Request);
                if (app.Server != null)
                {
                    Exception ex = app.Server.GetLastError();
                    if (ex != null)
                    {
                        text += string.Format("\r\n\t{0}", ex.Message);
                    }
                }
                LogText("ERROR", caption, text);
            }
        }
        else
        {
            LogText("ERROR", caption, moreInfo.GetType().Name);
        }
    }

    static public void LogError(string caption, Exception exception)
    {
        if (exception is SqlException)
        {
            LogError(caption, exception as SqlException, null);
        }
        else
        {
            LogError(caption, exception, null);
        }
    }

    static public void LogInfo(string caption, string info)
    {
        LogText("INFO", caption, info);
    }

    static public void LogError(string caption, Exception exception, HttpRequest request)
    {        
        string text = null;
        if (exception == null)
        {
            text = "NULL exception";
        }
        else
        {
            text = string.Format("\tMessage: {0}\r\n\tSource: {1}\r\n\tStack Trace: {2}",
                exception.Message, exception.Source, exception.StackTrace);
        }
        text += RequestToString(request);
        LogText("ERROR", caption, text);
    }


    static public void LogError(string caption, SqlException exception, HttpRequest request)
    {
        string text = null;
        if (exception == null)
        {
            text = "NULL SQL exception";
        }
        else
        {
            string type = string.Empty;
            if (exception.StackTrace.IndexOf("ExecuteReader") >= 0) 
            {
                type = "Error executing reader.";
            }
            else if (exception.StackTrace.IndexOf("AttemptOneLogin")>=0) 
            {
                type = "Error connecting to server. " +
                    "Are the parameters in the connection string (e.g. Server, Database, User ID, and Password) correct?";
            }
            else if (exception.StackTrace.IndexOf("CreateConnectionOptions") >= 0)
            {
                type = "Error connecting to server. Is the connection string malformed?";
            }
            else
            {
                type = "Could not be determined.";
            }
            text = string.Format("\tMessage: {0}\r\n\tSource: {1}\r\n\tClass: {2}\r\n\tFriendly info: {3}\r\n\tStack Trace: {4}",
                exception.Message, exception.Source, exception.Class, type, exception.StackTrace );
        }
        text += RequestToString(request);
        LogText("ERROR", caption, text);
    }
    
    static private string RequestToString(HttpRequest request)
    {
        string info = "";
        if (request == null)
        {
            info = "\r\nHTTP Request is null\r\n";
        }
        else
        {
            info = "\r\n----- HTTP Request -----\r\n";
            info += string.Format("\tRaw URL = {0}\r\n", request.RawUrl);
            info += string.Format("\tType = {0}\r\n", request.RequestType);
            info += string.Format("\tURL Referrer = {0}\r\n", request.UrlReferrer);
            info += string.Format("\tHost = {0} IP = {1}\r\n", request.UserHostName, request.UserHostAddress);
            info += string.Format("\tBytes = {0}\r\n", request.TotalBytes);
        }
        return info;
    }

    static private void LogText(string type, string caption, string text)
    {
        StreamWriter file = new StreamWriter(LogFile, true);
        string header = string.Format("{0} [{1}] - {2}", DateTime.Now, type, caption);
        file.WriteLine(header);
        file.WriteLine(text);
        file.WriteLine();
        file.Close();
    }

    static private string ExceptionToString(Exception exception)
    {
        string exceptionString = string.Format("\tMessage: {0}\r\n\tSource: {1}\r\n\tStack Trace: {2}",
            exception.Message, exception.Source, exception.StackTrace);
        if (exception.InnerException != null)
        {
            exceptionString += "\r\n\tInner Exception\r\n" + ExceptionToString(exception.InnerException);
        }
        return exceptionString;
    }
}

