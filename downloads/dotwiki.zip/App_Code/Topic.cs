using System;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Web.Security;
using Csla;
using Csla.Data;

[Serializable()]
public class Topic : BusinessBase<Topic>
{
    #region Business Methods

    private Guid _id;
    private string _name = string.Empty;
    private string _content = string.Empty;
    private DateTime _updatedOn = DateTime.MinValue;
    private bool _isCurrent = false;
    private string _updatedByUser = null;

    [DataObjectField(true, true)]
    public Guid Id
    {
        [MethodImpl(MethodImplOptions.NoInlining)]
        get
        {
            CanReadProperty(true);
            return _id;
        }
    }

    public bool IsCurrent
    {
        [MethodImpl(MethodImplOptions.NoInlining)]
        get
        {
            CanReadProperty(true);
            return _isCurrent;
        }
        [MethodImpl(MethodImplOptions.NoInlining)]
        set
        {
            CanWriteProperty(true);
            if (_isCurrent!= value)
            {
                _isCurrent = value;
                PropertyHasChanged();
            }
        }
    }

    public string Name
    {
        [MethodImpl(MethodImplOptions.NoInlining)]
        get
        {
            CanReadProperty(true);
            return _name;
        }
        [MethodImpl(MethodImplOptions.NoInlining)]
        set
        {
            CanWriteProperty(true);
            if (value == null) value = string.Empty;
            if (_name != value)
            {
                _name = value;
                PropertyHasChanged();
            }
        }
    }
    
    public string Content
    {
        [MethodImpl(MethodImplOptions.NoInlining)]
        get
        {
            CanReadProperty(true);
            return _content;
        }
        [MethodImpl(MethodImplOptions.NoInlining)]
        set
        {
            CanWriteProperty(true);
            if (value == null) value = string.Empty;
            if (_content != value)
            {
                _content = value;
                PropertyHasChanged();
            }
        }
    }

    public string DisplayContent
    {
        [MethodImpl(MethodImplOptions.NoInlining)]
        get
        {
            CanReadProperty(true);
            string display = TopicParser.WikiText(_content);
            display = display.Replace("{TopicName}", _name);
            return display;
        }
    }    

    public DateTime UpdatedOn
    {
        [MethodImpl(MethodImplOptions.NoInlining)]
        get
        {
            CanReadProperty(true);
            return _updatedOn;
        }
        [MethodImpl(MethodImplOptions.NoInlining)]
        set
        {
            CanWriteProperty(true);
            if (_updatedOn!= value)
            {
                _updatedOn= value;
                PropertyHasChanged();
            }
        }
    }

    public string UpdatedByUser
    {
        [MethodImpl(MethodImplOptions.NoInlining)]
        get
        {
            CanReadProperty(true);
            return _updatedByUser;
        }
        [MethodImpl(MethodImplOptions.NoInlining)]
        set
        {
            CanWriteProperty(true);
            if (value == null) value = string.Empty;
            if (_updatedByUser != value)
            {
                _updatedByUser = value;
                PropertyHasChanged();
            }
        }
    }

    protected override object GetIdValue()
    {
        return _id;
    }

    #endregion

    #region Security
    public static bool CanAddObject()
    {
        return true;
    }

    public static bool CanGetObject()
    {
        return true;
    }

    public static bool CanDeleteObject()
    {
        return true;
    }

    public static bool CanEditObject()
    {
        return true;
    }

    #endregion

    #region Factory Methods

    public static Topic NewTopic()
    {
        return DataPortal.Create<Topic>();
    }

    public static Topic GetTopic(string topicName)
    {
        return DataPortal.Fetch<Topic>(new Criteria(topicName));
    }

    public static Topic GetTopic(Guid topicPK)
    {
        return DataPortal.Fetch<Topic>(new Criteria(topicPK));
    }

    public static Topic GetHistory(Guid historyPK)
    {
        return DataPortal.Fetch<Topic>(new Criteria(historyPK, false));
    }

    public static string GetPictures(string topicName)
    {
        GetPicturesCommand result = DataPortal.Execute<GetPicturesCommand>(new GetPicturesCommand(topicName));
        return result.Pictures;
    }

    public static bool Exists(string topicName)
    {
        ExistsCommand result = DataPortal.Execute<ExistsCommand>(new ExistsCommand(topicName));
        return result.Exists;
    }

    public static void DeleteTopic(Guid topicPK)
    {
        DataPortal.Delete(new Criteria(topicPK));
    }

    public static void UndoDeleteTopic(Guid topicPK)
    {
        UndoCommand undo = DataPortal.Execute<UndoCommand>(new UndoCommand(topicPK));
        return;
    }

    private Topic()
    { /* require use of factory methods */ }

    #endregion

    #region Exists

    [Serializable()]
    private class ExistsCommand : CommandBase
    {
        private string _topicName;
        private bool _exists;

        public bool Exists
        {
            get { return _exists; }
        }

        public ExistsCommand(string topicName)
        {
            _topicName = topicName;
        }

        protected override void DataPortal_Execute()
        {
            try
            {
                string connString = ConfigurationManager.ConnectionStrings["DotWikiDB"].ConnectionString;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command = conn.CreateCommand())
                    {
                        command.CommandType = CommandType.Text;
                        command.CommandText = "select count(1) from topic where name = @TopicName and wikiset = @WikiSet";
                        command.Parameters.AddWithValue("@TopicName", _topicName);
                        command.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet);
                        int count = (int)command.ExecuteScalar();
                        _exists = (count == 1);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("ExistsCommand.Execute", ex);
                throw ex;
            }        
        }
    }

    #endregion
    
    #region GetPictures

    [Serializable()]
    private class GetPicturesCommand : CommandBase
    {
        private string _topicName;
        private string _pictures  = string.Empty;

        public string Pictures
        {
            get { return _pictures; }
        }

        public GetPicturesCommand(string topicName)
        {
            _topicName = topicName;
        }

        private string ParseTopic(string topicContent)
        {
            string pictures = string.Empty;

            MatchCollection thumbnails= Regex.Matches(topicContent,@"\<thumbnail=.+?\>");
            foreach(Match match in thumbnails)
            {
                try
                {
                    string item = match.Value.Substring(11);
                    if (pictures.Length > 0) pictures += "|";
                    pictures += item.Substring(0, item.Length - 1);
                }
                catch (Exception ex)
                {
                    // ignore exception
                    Logger.LogError("GetPicturesCommand.ParseTopic - Error parsing thumbnails", ex);
                }
            }

            MatchCollection images = Regex.Matches(topicContent, @"\<img.*?src=.+?\>");
            foreach(Match match in images)
            {
                try
                {
                    Match match2 = Regex.Match(match.Value, @"src=[\""]*.*?[\""|\s|\>]");
                    string filename = match2.Value.Substring(4);
                    filename = filename.Replace("\"", "");
                    filename = filename.Replace("\\", "/");
                    filename = filename.Replace("_thumb.", ".");
                    if (pictures.Length > 0) pictures += "|";
                    pictures += filename;
                }
                catch (Exception ex)
                {
                    // ignore exception
                    Logger.LogError("GetPicturesCommand.ParseTopic - Error parsing img", ex);
                }
            }

            return pictures;
        }

        protected override void DataPortal_Execute()
        {
            try
            {
                string connString = ConfigurationManager.ConnectionStrings["DotWikiDB"].ConnectionString;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command = conn.CreateCommand())
                    {
                        command.CommandType = CommandType.Text;
                        command.CommandText = "select content from topic where name = @TopicName and wikiset = @WikiSet";
                        command.Parameters.AddWithValue("@TopicName", _topicName);
                        command.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet);
                        string topicContent = command.ExecuteScalar() as string;
                        _pictures = ParseTopic(topicContent);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("GetPicturesCommand.Execute", ex);
                throw ex;
            }        

        }
    }

    #endregion

    #region Undo Delete
    [Serializable()]
    private class UndoCommand : CommandBase
    {
        private Guid _topicPK;

        public UndoCommand(Guid topicPK)
        {
            _topicPK = topicPK;
        }

        protected override void DataPortal_Execute()
        {
            try
            {
                string connString = ConfigurationManager.ConnectionStrings["DotWikiDB"].ConnectionString;
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    conn.Open();
                    using (SqlCommand command = conn.CreateCommand())
                    {
                        command.CommandType = CommandType.Text;
                        command.CommandText = "insert into topic( topicpk, content, name, updatedon, wikiset, userid) " +
                            "select top 1 topicfk, content, name, updatedon, wikiset, userid " +
                            "from topichistory " +
                            "where topicfk = @topicPK " +
                            "order by updatedon desc";
                        command.Parameters.Add("@topicPK", SqlDbType.UniqueIdentifier);
                        command.Parameters["@topicpk"].Value = _topicPK;
                        int result = command.ExecuteNonQuery();
                        if (result != 1)
                        {
                            string error = string.Format("Undo returned an unexpected number of records for topic PK {0}. " +
                                "Expected: 1, Returned: {1}", _topicPK, result);
                            throw new Exception(error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("UndoCommand.Execute", ex);
                throw ex;
            }        
        }
    }

    #endregion

    #region Data Access

    [Serializable()]
    private class Criteria
    {
        private string _name;
        private Guid _id;
        private bool _currentVersion = true;
        public string Name { get { return _name; } }
        public Guid Id { get { return _id; } }
        public bool CurrentVersion { get { return _currentVersion; } }

        public Criteria(string name)
        { 
            _name = name; 
        }

        public Criteria(Guid id)
        {
            _id = id;
        }

        public Criteria(Guid id, bool currentVersion)
        {
            _id = id;
            _currentVersion = currentVersion;
        }
    }

    [RunLocal()]
    protected override void DataPortal_Create()
    {
        _id = Guid.NewGuid();
        _name = "";
        _content = "";
        _updatedOn = DateTime.Now;
        _updatedByUser = null;
    }

    private void DataPortal_Fetch(Criteria criteria)
    {
        if (criteria.CurrentVersion)
            FetchCurrentVersion(criteria);
        else
            FetchPreviousVersion(criteria);
    }

    protected override void DataPortal_Insert()
    {
        try
        {
            string connString = ConfigurationManager.ConnectionStrings["DotWikiDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                using (SqlCommand command = conn.CreateCommand())
                {
                    command.CommandType = CommandType.Text;
                    command.CommandText = "insert topic( topicPK, name, content, updatedon, wikiset, userid) " +
                        "select @topicPK, @name, @content, getdate(), @wikiset, <<getuserid>>";
                    command.Parameters.Add("@name", SqlDbType.VarChar, 50);
                    command.Parameters.Add("@content", SqlDbType.Text);
                    command.Parameters.Add("@topicPK", SqlDbType.UniqueIdentifier);
                    command.Parameters.Add("@wikiset", SqlDbType.Char, 20);

                    command.Parameters["@name"].Value = _name;
                    command.Parameters["@content"].Value = _content;
                    command.Parameters["@topicPK"].Value = _id;
                    command.Parameters["@wikiset"].Value = RootObject.WikiSet;
                    ReplaceGetUserIdToken(command);

                    command.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            Logger.LogError("Insert", ex);
            throw ex;
        }        

    }

    protected override void DataPortal_Update()
    {
        try
        {
            string connString = ConfigurationManager.ConnectionStrings["DotWikiDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                BackupTopic(conn);
                using (SqlCommand command = conn.CreateCommand())
                {
                    command.CommandType = CommandType.Text;
                    command.CommandText = "update topic " + 
                        "set content=@content, updatedon=getdate(), userid=<<getuserid>> " + 
                        "where topicpk = @topicPK";
                    command.Parameters.Add("@content", SqlDbType.Text);
                    command.Parameters.Add("@topicPK", SqlDbType.UniqueIdentifier);

                    command.Parameters["@content"].Value = _content;
                    command.Parameters["@topicpk"].Value = _id;
                    ReplaceGetUserIdToken(command);
                                        
                    command.ExecuteNonQuery();
                }
            }
        }
        catch (Exception ex)
        {
            Logger.LogError("Update", ex);
            throw ex;
        }        

    }
        
    protected override void DataPortal_DeleteSelf()
    {
        try
        {
            string connString = ConfigurationManager.ConnectionStrings["DotWikiDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                BackupTopic(conn);
                using (SqlCommand command = conn.CreateCommand())
                {
                    command.CommandType = CommandType.Text;
                    command.CommandText = "delete topic where topicpk = @topicPK";
                    command.Parameters.Add("@topicPK", SqlDbType.UniqueIdentifier);
                    command.Parameters["@topicpk"].Value = _id;
                    int result = command.ExecuteNonQuery();
                    if (result != 1)
                    {
                        string error = string.Format("Delete returned an unexpected number of records for topic PK {0}. " +
                            "Expected: 1, Returned: {1}", _id, result);
                        throw new Exception(error);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Logger.LogError("Delete", ex);
            throw ex;
        }        

    }

    private void FetchCurrentVersion(Criteria criteria)
    {
        try
        {
            string connString = ConfigurationManager.ConnectionStrings["DotWikiDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                using (SqlCommand command = conn.CreateCommand())
                {
                    command.CommandType = CommandType.Text;

                    if (Security.SecureMode == SecureModeEnum.Simple)
                    {
                        if (criteria.Id == Guid.Empty)
                        {
                            command.CommandText = "select topicpk, name, content, updatedon, '' as username " +
                                "from topic " +
                                "where name = @Name and wikiset = @WikiSet";
                            command.Parameters.AddWithValue("@Name", criteria.Name);
                            command.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet);
                        }
                        else
                        {
                            command.CommandText = "select topicpk, name, content, updatedon, '' as username " +
                                "from topic " +
                                "where topicPK = @topicPK";
                            command.Parameters.AddWithValue("@topicPK", criteria.Id);
                        }
                    }
                    else
                    {
                        if (criteria.Id == Guid.Empty)
                        {
                            command.CommandText = "select topicpk, name, content, updatedon, users.username " +
                                "from topic " +
                                "left outer join aspnet_users users on topic.userid = users.userid " +
                                "where name = @Name and wikiset = @WikiSet";
                            command.Parameters.AddWithValue("@Name", criteria.Name);
                            command.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet);
                        }
                        else
                        {
                            command.CommandText = "select topicpk, name, content, updatedon, users.username " +
                                "from topic " +
                                "left outer join aspnet_users users on topic.userid = users.userid " +
                                "where topicPK = @topicPK";
                            command.Parameters.AddWithValue("@topicPK", criteria.Id);
                        }
                    }

                    using (SafeDataReader dr = new SafeDataReader(command.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            _id = dr.GetGuid("topicpk");
                            _name = dr.GetString("name").Trim();
                            _content = dr.GetString("content").Trim();
                            _updatedOn = dr.GetDateTime("updatedon");
                            _updatedByUser = dr.GetString("username");
                            _isCurrent = true;
                        }
                        else
                        {
                            _id = Guid.Empty;
                            _isCurrent = true;
                        }
                    }
                }

            }
        }
        catch (Exception ex)
        {
            Logger.LogError("Fetch", ex);
            throw ex;
        }
    }

    private void FetchPreviousVersion(Criteria criteria)
    {
        try
        {
            string connString = ConfigurationManager.ConnectionStrings["DotWikiDB"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                using (SqlCommand command = conn.CreateCommand())
                {
                    command.CommandType = CommandType.Text;

                    if (Security.SecureMode == SecureModeEnum.Simple)
                    {
                        command.CommandText = "select topichistorypk, name, content, updatedon, '' as username " +
                            "from topichistory " +
                            "where topicHistoryPK = @topicHistoryPK and wikiset = @WikiSet";
                        command.Parameters.AddWithValue("@topicHistoryPK", criteria.Id);
                        command.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet);
                    }
                    else
                    {
                        command.CommandText = "select topichistorypk, name, content, updatedon, username " +
                            "from topichistory " +
                            "left outer join aspnet_users on aspnet_users.userid = topichistory.userid " +
                            "where topicHistoryPK = @topicHistoryPK and wikiset = @WikiSet";
                        command.Parameters.AddWithValue("@topicHistoryPK", criteria.Id);
                        command.Parameters.AddWithValue("@WikiSet", RootObject.WikiSet);
                    }

                    using (SafeDataReader dr = new SafeDataReader(command.ExecuteReader()))
                    {
                        if (dr.Read())
                        {
                            _id = dr.GetGuid("topichistorypk");
                            _name = dr.GetString("name").Trim();
                            _content = dr.GetString("content").Trim();
                            _updatedOn = dr.GetDateTime("updatedon");
                            _updatedByUser = dr.GetString("username");
                            _isCurrent = false;
                        }
                        else
                        {
                            _id = Guid.Empty;
                            _isCurrent = false;
                        }
                    }
                }

            }
        }
        catch (Exception ex)
        {
            Logger.LogError("Fetch", ex);
            throw ex;
        }
    }

    private void ReplaceGetUserIdToken(SqlCommand command)
    {
        if (String.IsNullOrEmpty(_updatedByUser))
        {
            command.CommandText = command.CommandText.Replace("<<getuserid>>", "NULL");
        }
        else
        {
            string sql = "(select userid " +
                "from aspnet_users " +
                "inner join aspnet_applications on aspnet_applications.applicationid = aspnet_users.applicationid " +
                "where loweredusername = @username and loweredapplicationname = @applicationname)";
            command.CommandText = command.CommandText.Replace("<<getuserid>>", sql);
            command.Parameters.AddWithValue("@username", _updatedByUser.ToLower());
            command.Parameters.AddWithValue("@applicationname", Membership.ApplicationName.ToLower());
        }
    }

    private void BackupTopic(SqlConnection conn)
    {
        try
        {
            using (SqlCommand command = conn.CreateCommand())
            {
                command.CommandType = CommandType.Text;
                command.CommandText = "insert into topichistory( topicfk, name, content, updatedon, userid, wikiset ) " +
                                      "select topicpk, name, content, updatedon, userid, wikiset " +
                                      "from topic " +
                                      "where topicpk = @TopicPK";

                if (_id == Guid.Empty)
                {
                    throw new Exception("_id is empty.");
                }
                command.Parameters.Add("@topicPK", SqlDbType.UniqueIdentifier);
                command.Parameters["@topicpk"].Value = _id;
                command.ExecuteNonQuery();
            }
        }
        catch (Exception ex)
        {
            Logger.LogError("BackupTopic", ex);
            throw ex;
        }

    }

    #endregion

}
