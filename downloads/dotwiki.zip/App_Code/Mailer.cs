﻿using System;
using System.Configuration;
using System.Net;
using System.Net.Configuration;
using System.Net.Mail;

public static class Mailer
{

    public static void SendEmail(string to, string subject, string body)
    {
        SendEmail(to, subject, body, false);
    }


    public static SmtpSection MailSettings
    {
        get
        {
            SmtpSection smtp = ConfigurationManager.GetSection("system.net/mailSettings/smtp") as SmtpSection;
            if (smtp == null)
            {
                throw new Exception("Could not retrieve system.net/mailSettings/smtp section from web.config");
            }
            return smtp;
        }
    }


    public static void SendEmail(string to, string subject, string body, bool isHtml)
    {
        try
        {
            SmtpSection smtp = Mailer.MailSettings;
            MailMessage message = new MailMessage(smtp.From, to);
            message.Subject = subject;
            message.Body = body;
            message.IsBodyHtml = isHtml;

            SmtpClient mail = new SmtpClient(smtp.Network.Host, smtp.Network.Port);
            mail.DeliveryMethod = SmtpDeliveryMethod.Network;
            mail.EnableSsl = true;  // this value cannot be set via the web config 
            mail.Credentials = new NetworkCredential(smtp.Network.UserName, smtp.Network.Password);

            //mail.Send(smtp.From, to, subject, body);
            mail.Send(message);

        }
        catch (Exception ex)
        {
            Logger.LogError("Mailer.SendEmail()", ex);
            throw;
        }
    }

}
