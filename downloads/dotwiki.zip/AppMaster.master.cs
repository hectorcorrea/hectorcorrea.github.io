using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class AppMaster : System.Web.UI.MasterPage
{
	protected void Themepicker_Command(object sender, CommandEventArgs e)
	{
		//Set the StyleheetTheme in the user's profile to the selected value and 
        //reload the page so the change can be applied.
		Profile.StylesheetTheme = e.CommandName;		
		Response.Redirect(Request.FilePath, false);
	}

    protected override void OnLoad(EventArgs e)
    {
        if (Security.SecureMode == SecureModeEnum.Simple)
        {
            LoginView.Visible = false;
            lblLoginViewNone.Visible = true;
            lblLoginViewNone.Text = ""; // Insert your quote here;
        }
        base.OnLoad(e);
    }  

    protected void cmdSiteSearch_Click(object sender, EventArgs e)
    {
        string url = string.Format("~/{0}?s={1}", RootObject.SearchPage, txtSiteSearch.Text);
        Response.Redirect(url);
    }

}
