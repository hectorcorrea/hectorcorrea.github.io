﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class Search : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string textToSearch = Request.QueryString["s"];
            if (String.IsNullOrEmpty(textToSearch))
            {
                AskForSearchTerm();
            }
            else
            {
                DoSearch(textToSearch);
            }
        }
    }

    private void AskForSearchTerm()
    {
        divAskForSearchTerm.Visible = true;
        divNoTopicsFound.Visible = false;
    }

    private void DoSearch(string textToSearch)
    {
        try
        {
            TopicList list = TopicList.Search(textToSearch);
            gvTopics.DataSource = list;
            gvTopics.DataBind();
            if (list.Count == 0)
            {
                divNoTopicsFound.Visible = true;
                lblSearchTerm.Text = textToSearch;
            }
            else
            {
                divNoTopicsFound.Visible = false;
            }
        }
        catch (Exception ex)
        {
            Logger.LogError(Request.Url.ToString(), ex, Request);
            litError.Text = RootObject.HtmlError("Could not retrieve list of topics", "(Search page)",User);
            litError.Visible = true;
        }
    }

    protected void cmdSearch_Click(object sender, EventArgs e)
    {
        string searchTerm = txtSearchTerm.Text.Trim();
        if (searchTerm.Length > 0)
        {
            DoSearch(searchTerm);
        }
        else
        {
            AskForSearchTerm();
        }
    }
}
