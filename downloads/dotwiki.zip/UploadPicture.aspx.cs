﻿using System;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.IO;
using System.Drawing;

public partial class UploadPicture : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {        
        try
        {
            
            if (Security.SecureMode == SecureModeEnum.Simple)
            {
                if (RootObject.UploadPassword == string.Empty)
                {
                    lblPassword.Visible = false;
                    txtPassword.Visible = false;
                }
            }
            else
            {
                lblPassword.Visible = false;
                txtPassword.Visible = false;
                if (!Security.UserCanAddPicture(User))
                {
                    // Somebody landed in this page even though they 
                    // don't have access rights to add pictures (e.g. 
                    // copying the URL while authenticated and pasting 
                    // it when not authenticated...or a hacker)
                    lblName.Visible = false;
                    FileUploader.Visible = false;
                    cmdUpload.Visible = false;
                    lblNamePrefix.Visible = false;
                    lblFileUploader.Visible = false;
                    throw new Exception("User does not have access rights to add picure");
                }
            }

            Topic topic = Topic.GetTopic(GetTopicPKInUrl());
            lblName.Text = topic.Name;

        }
        catch (System.Threading.ThreadAbortException)
        {
            // Ignore this exception since this is most likely the result of Redirect.            
        }
        catch (Exception ex)
        {
            Logger.LogError(Request.Url.ToString(), ex, Request);
            litError.Text = RootObject.HtmlError(ex.Message, lblName.Text, User);
            litError.Visible = true;
        }
    }

    private Guid GetTopicPKInUrl()
    {
        string pk = Request.QueryString["pk"];
        if (String.IsNullOrEmpty(pk))
        {
            throw new Exception("No topic PK found");
        }

        Guid topicPK = Guid.Empty;
        try
        {
            topicPK = new Guid(pk);
        }
        catch( Exception ex)
        {
            Logger.LogError("Invalid PK found in URL", ex, Request);
            topicPK = Guid.Empty;
        }

        return topicPK;
    }

    protected void cmdUpload_Click(object sender, EventArgs e)
    {
        try
        {

            litError.Text = "";
            litError.Visible = false;

            if (Security.SecureMode == SecureModeEnum.Simple)
            {
                if (RootObject.UploadPassword != string.Empty)
                {
                    if (RootObject.UploadPassword != txtPassword.Text) 
                        throw new ArgumentException("Invalid upload password provided");
                }
            }
            else
            {
                if(!Security.UserCanAddPicture(User))
                    throw new Exception("User does not have access rights to add picure");
            }

            string fullPath = Request.PhysicalApplicationPath + RootObject.UploadPath + FileUploader.FileName;
            fullPath = fullPath.Replace("/", "\\");
            if (FileUploader.HasFile)
            {
                long sizeKB = FileUploader.FileBytes.LongLength / 1024;
                if (sizeKB < RootObject.UploadMaxSizeKB)
                {
                    FileUploader.SaveAs(fullPath);
                }
                else
                {
                    string errorMsg = string.Format("This file is too big. " +
                        "This file {0} KB but the maximum allowed size is {1} KB.", sizeKB, RootObject.UploadMaxSizeKB);
                    throw new ArgumentException(errorMsg);
                }
            }
            else
            {
                string errorMsg = "No file to upload was specified. Please select a file by clicking the \"Browse\" button.";
                throw new ArgumentException(errorMsg);
            }

            Guid topicPK = GetTopicPKInUrl();
            Topic topic = Topic.GetTopic(topicPK);
            if (topic.Id == Guid.Empty)
            {
                string errorMsg = string.Format("Could not find topic PK [{0}]", topicPK);
                throw new Exception(errorMsg);
            }

            // TODO: create thumbnail image

            string src = (RootObject.UploadPath + FileUploader.FileName).Replace("\\","/");
            string imgTag = string.Format("<img src=\"{0}\" />", src);
            topic.Content += imgTag;
            topic.Save();
            Response.Redirect(RootObject.TopicUrl(topic.Name));
            
        }
        catch (System.Threading.ThreadAbortException)
        {
            // Ignore this exception since this is most likely the result of Redirect.            
        }
        catch(ArgumentException ex)
        {
            Logger.LogError(Request.Url.ToString(), ex, Request);
            litError.Text = RootObject.HtmlError(ex.Message, lblName.Text,User);
            litError.Visible = true;
        }
        catch (Exception ex)
        {
            Logger.LogError(Request.Url.ToString(), ex, Request);
            litError.Text = RootObject.HtmlError("Could upload picture to topic", lblName.Text,User);
            litError.Visible = true;
        }
    }
}
