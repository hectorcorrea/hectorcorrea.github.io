﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;


public partial class AddAdminUser : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Security.UserCanAddAdminUser(User))
            {
                throw new Exception("User does not have access to add other admin users");
            }
        }
        catch (System.Threading.ThreadAbortException)
        {
            // Ignore this exception since this is most likely the result of Redirect.            
        }
        catch (Exception ex)
        {
            Logger.LogError("Add Admin User", ex, Request);
            Response.Redirect(RootObject.HomePage);
        }
    }

    protected void CreateUserWizard1_CreatedUser(object sender, EventArgs e)
    {
        string username = CreateUserWizard1.UserName;
        if (!String.IsNullOrEmpty(username))
        {
            Roles.AddUserToRole(username, Security.AdminRole);
        }
    }

}

