﻿using System;

public partial class RecentChanges : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ShowRecentChanges(GetLatest.Last50Changes);
            //if (gvTopics.Rows.Count == 0 && !litError.Visible)
            //{
            //    ShowRecentChanges(GetLatest.Last7Days);
            //}
            //if (gvTopics.Rows.Count == 0 && !litError.Visible)
            //{
            //    ShowRecentChanges(GetLatest.Last30Days);
            //}
        }
    }

    private void ShowRecentChanges(GetLatest range)
    {
        try
        {
            string text = string.Empty;
            string textEmpty = string.Empty;
            switch (range)
            {
                case GetLatest.Last50Changes:
                    text = "Last 50 changes";
                    textEmpty = "No changes were found";
                    break;
                case GetLatest.Last24Hours:
                    text = "Changes made in the last 24 hours";
                    textEmpty = "No changes have been made in the last 24 hours";
                    break;
                case GetLatest.Last7Days:
                    text = "Changes made in the last 7 days";
                    textEmpty = "No changes have been made in the last 7 days";
                    break;
                case GetLatest.Last30Days:
                    text = "Changes made in the last 30 days";
                    textEmpty = "No changes have been made in the last 30 days";
                    break;
            }

            TopicList list = TopicList.GetRecentChanges(range);
            gvTopics.DataSource = list;
            gvTopics.DataBind();
            lblTitle.Text = (list.Count == 0) ? textEmpty : text;
        }
        catch (Exception ex)
        {
            Logger.LogError(Request.Url.ToString(), ex, Request);
            string topicName = string.Format("(Recent Changes {0})", range);
            litError.Text = RootObject.HtmlError("Could not retrieve list of topics", topicName,User);
            litError.Visible = true;
        }

    }
    protected void cmd24Hrs_Click(object sender, EventArgs e)
    {
        ShowRecentChanges(GetLatest.Last24Hours);
    }

    protected void cmd7Days_Click(object sender, EventArgs e)
    {
        ShowRecentChanges(GetLatest.Last7Days);
    }

    protected void cmd30Days_Click(object sender, EventArgs e)
    {
        ShowRecentChanges(GetLatest.Last30Days);
    }
}
