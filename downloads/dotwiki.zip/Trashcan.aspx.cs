﻿using System;
using System.Web;

public partial class Trashcan : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {

            if (!Security.UserCanDelete(User))
            {
                // Somebody landed in this page even though they 
                // don't have access rights to delete topics 
                // (e.g. copying the URL while authenticated and 
                // pasting it when not authenticated...or a hacker)
                throw new Exception("User does not have access to the trashcan.");
            }

            if (!IsPostBack)
            {
                string restore = Request.QueryString["restore"];
                bool isRestore = !String.IsNullOrEmpty(restore) && restore == "yes";
                if (isRestore)
                {
                    string strTopicPK = Request.QueryString["topic"];
                    Guid topicPK = new Guid(strTopicPK);
                    Topic.UndoDeleteTopic(topicPK);
                    Topic topic = Topic.GetTopic(topicPK);
                    Response.Redirect(RootObject.TopicUrl(topic.Name));
                }
                else
                {
                    TopicList topics = TopicList.GetTrashcan();
                    gvTopics.DataSource = topics;
                    gvTopics.DataBind();
                }
            }
        }
        catch (System.Threading.ThreadAbortException)
        {
            // Ignore this exception since this is most likely the result of Redirect.            
        }
        catch (Exception ex)
        {
            Logger.LogError(Request.Url.ToString(), ex, Request);
            litError.Text = RootObject.HtmlError("Error in trashcan", "", User);
            litError.Visible = true;
            lblTitle.Visible = false;
        }

    }

}
