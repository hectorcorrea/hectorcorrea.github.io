﻿using System;

public partial class DeleteTopic : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Security.UserCanDelete(User))
            {
                // Somebody landed in this page even though they 
                // don't have access rights to delete topics 
                // (e.g. copying the URL while authenticated and 
                // pasting it when not authenticated...or a hacker)
                throw new Exception("User does not have access rights to delete this topic");
            }

            if (!IsPostBack)
            {
                Guid topicPK = new Guid(Request.QueryString["pk"]);
                Topic topic = Topic.GetTopic(topicPK);
                lblName.Text = topic.Name;
                divAreYouSure.Visible = true;
                divTopicDeleted.Visible = false;
            }

        }
        catch (Exception ex)
        {
            Logger.LogError(Request.Url.ToString(), ex, Request);
            litError.Text = RootObject.HtmlError("Error deleting topic", "",User);
            litError.Visible = true;
            divAreYouSure.Visible = false;
            divTopicDeleted.Visible = false;
        }
    }
    
    protected void cmdYes_Click(object sender, EventArgs e)
    {
        try
        {
            Guid topicPK = new Guid(Request.QueryString["pk"]);
            Topic topic = Topic.GetTopic(topicPK);
            topic.Content = topic.Content + " ";
            topic.UpdatedByUser = User.Identity.Name;
            topic.Save(); // Save to mark who last updated it (deleted it in this case.)
            topic.Delete();
            topic.Save(); // Save to actually delete it.
            divAreYouSure.Visible = false;
            divTopicDeleted.Visible = true;
        }
        catch (Exception ex)
        {
            Logger.LogError(Request.Url.ToString(), ex, Request);
            litError.Text = RootObject.HtmlError("Error deleting topic", "", User);
            litError.Visible = true;
            divAreYouSure.Visible = false;
            divTopicDeleted.Visible = false;
        }
    }

    protected void cmdNo_Click(object sender, EventArgs e)
    {
        try
        {
            Guid topicPK = new Guid(Request.QueryString["pk"]);
            Topic topic = Topic.GetTopic(topicPK);
            Response.Redirect(RootObject.TopicUrl(topic.Name));
        }
        catch (Exception ex)
        {
            Logger.LogError(Request.Url.ToString(), ex, Request);
            litError.Text = RootObject.HtmlError("Error canceling delete.", "", User);
            litError.Visible = true;
            divAreYouSure.Visible = false;
            divTopicDeleted.Visible = false;
        }
    }

    protected void cmdUndo_Click(object sender, EventArgs e)
    {
        try
        {
            Guid topicPK = new Guid(Request.QueryString["pk"]);
            Topic.UndoDeleteTopic(topicPK);
            Topic topic = Topic.GetTopic(topicPK);
            Response.Redirect(RootObject.TopicUrl(topic.Name));
        }
        catch (Exception ex)
        {
            Logger.LogError(Request.Url.ToString(), ex, Request);
            litError.Text = RootObject.HtmlError("Error undoing delete", "", User);
            litError.Visible = true;
            divAreYouSure.Visible = false;
            divTopicDeleted.Visible = false;
        }
    }


}
