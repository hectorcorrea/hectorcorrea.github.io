﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Mail;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;

public partial class PasswordRecovery : PageBase
{

    const string userRegEx = "<user>.*?</user>";
    const string passwordRegEx = "<password>.*?</password>";
    const string linkRegEx = "<link>.*?</link>";

    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            try
            {
                PasswordRecovery1.MailDefinition.From = Mailer.MailSettings.From;
            }
            catch (Exception ex)
            {
                Logger.LogError("Error reading mail settings", ex, Request);
                litError.Visible = true;
                litError.Text = "Could not reset your password. Please contact your web site adminstrator.";
                PasswordRecovery1.Visible = false;
            }
        }

    }

    protected void PasswordRecovery1_SendingMail(object sender, MailMessageEventArgs e)
    {
        try
        {
            /* Extract user name and auto-generated password from e-mail */
            string mailBody = e.Message.Body;

            Match userMatch = Regex.Match(mailBody, userRegEx);
            string user = userMatch.Value.Replace("<user>", "");
            user = user.Replace("</user>", "");

            Match oldPasswordMatch = Regex.Match(mailBody, passwordRegEx);
            string oldPassword = oldPasswordMatch.Value.Replace("<password>", "");
            oldPassword = oldPassword.Replace("</password>", "");

            string newPassword = oldPassword;
            if (Security.UseFriendlyPassword)
            {
                newPassword = GenerateHumanFriendlyPassword();
                if (!Membership.Provider.ChangePassword(user, oldPassword, newPassword))
                {
                    string error = string.Format("Could not set friendly password for user [{0}]", user);
                    throw new Exception(error);
                }
            }

            /* Update e-mail with new password and login URL */
            mailBody = Regex.Replace(mailBody, userRegEx, user);
            mailBody = Regex.Replace(mailBody, passwordRegEx, newPassword);
            mailBody = Regex.Replace(mailBody, linkRegEx, LoginUrl);

            /* Finally, send the e-mail to the user */
            string mailTo = Membership.Provider.GetUser(user, false).Email;
            Mailer.SendEmail(mailTo, "Your new password", mailBody);

        }
        catch (Exception ex)
        {
            Logger.LogError("mail", ex, Request);
        }

        /* Don't let the membership provider send its own message */
        e.Cancel = true;

    }

    private string GenerateHumanFriendlyPassword()
    {
        string[] passwordRoots = 
        { 
            "Pencil",   "Orange",  "Missouri", "Bonsai",    "Purple",  "Scramble","Chair",  "Shoe",   "Lacuna", "Sylvan",
            "Computer", "Phone",   "Animal",   "Vegetable", "Jocular", "Prolix",  "Repeat", "Turbid", "Crux",   "Enjoy",
            "Mask",     "Window",  "Frame",    "Fire",      "Parse",   "Beetle",  "Music",  "Orchid", "Vacuum", "Carpet",
            "Cable",    "Kitchen", "Rain",     "Labrador",  "Towel",   "Video",   "Street", "Light",  "Forest", "Classic"
        };

        Random r = new Random(DateTime.Now.Millisecond);
        int random = r.Next(1000, 10000);
        int root = random % 30;
        return passwordRoots[root] + random.ToString();
    }

    private string LoginUrl
    {
        get
        {
            string thisUrl = Request.Url.AbsoluteUri;
            string baseUrl = thisUrl.Substring(0, thisUrl.LastIndexOf('/'));
            return baseUrl + "/Login.aspx";
        }
    }

}
