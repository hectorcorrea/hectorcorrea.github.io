﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ViewImage : PageBasePlain
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string topicName = Request.QueryString["TopicName"];
            if (!String.IsNullOrEmpty(topicName))
            {
                LoadTopicPictures(topicName);
                string pictureName = Request.QueryString["PictureFile"];
                if (!String.IsNullOrEmpty(pictureName))
                {
                    LoadPicture(pictureName);
                }
                SetBackground("black");
                SetSize("normal");
                RenderCurrentPicture();
            }
        }
        
    }

    private void LoadTopicPictures(string topicName)
    {
        string picturesString = Topic.GetPictures(topicName);
        Session["Pictures"] = picturesString;
        Session["PictureNumber"] = 0;
    }

    private void LoadPicture(string pictureName)
    {
        string picturesString = (string)Session["Pictures"];
        string[] pictures = picturesString.Split('|');
        for (int i = 0; i < pictures.Length;i++ )
        {
            if (pictures[i] == pictureName)
            {
                Session["PictureNumber"] = i;
                break; 
            }
        }
    }

    private void SetBackground(string bgColor)
    {
        Session["Background"] = bgColor;
    }

    private void SetSize(string size)
    {
        Session["Size"] = size;
    }

    private void RenderCurrentPicture()
    {
        string picturesString = (string)Session["Pictures"];
        string[] pictures = picturesString.Split('|');
        int pictureIndex = (int)Session["PictureNumber"];
        lblName.Text = string.Format("Picture {0}", pictures[pictureIndex]);
        lblCount.Text = string.Format("{0} of {1}", pictureIndex+1, pictures.Length);
        lblSize.Text = "(normal size)";
        Image1.ImageUrl = pictures[pictureIndex];
        
        if (Session["Background"].ToString() == "black")
        {
            BodyTag.Style.Add("background-color", "black");
            lblName.Style.Add("color", "white");
            lblCount.Style.Add("color", "white");
            lblSize.Style.Add("color", "white");
        }
        else
        {
            BodyTag.Style.Add("background-color", "white");
            lblName.Style.Add("color", "black");
            lblCount.Style.Add("color", "black");
            lblSize.Style.Add("color", "black");
        }

        cmdFirst.Enabled = (pictureIndex > 0);
        cmdPrev.Enabled = cmdFirst.Enabled;
        cmdNext.Enabled = (pictureIndex < pictures.Length-1);
        cmdLast.Enabled = cmdNext.Enabled;

        string size = Session["Size"].ToString();
        if (size== "normal")
        {
            Image1.Width = Unit.Empty;
            Image1.Height = Unit.Empty;
        }
        else if (size == "vertical")
        {
            Image1.Width = Unit.Empty;
            Image1.Height = Unit.Percentage(90);
        }
        else if (size == "horizontal")
        {
            Image1.Width = Unit.Percentage(95);
            Image1.Height = Unit.Empty;
        }

    }

    protected void cmdNext_Click(object sender, EventArgs e)
    {
        string picturesString = (string)Session["Pictures"];
        string[] pictures = picturesString.Split('|');

        int pictureIndex = (int)Session["PictureNumber"];
        if (pictureIndex < pictures.Length-1)
        {
            Session["PictureNumber"] = pictureIndex + 1;
            RenderCurrentPicture();
        }
    }

    protected void cmdPrev_Click(object sender, EventArgs e)
    {
        int pictureIndex = (int)Session["PictureNumber"];
        if (pictureIndex > 0)
        {
            Session["PictureNumber"] = pictureIndex - 1;
            RenderCurrentPicture();
        }
    }

    protected void cmdFirst_Click(object sender, EventArgs e)
    {
        Session["PictureNumber"] = 0;
        RenderCurrentPicture();

    }
    
    protected void cmdLast_Click(object sender, EventArgs e)
    {
        string picturesString = (string)Session["Pictures"];
        string[] pictures = picturesString.Split('|');
        Session["PictureNumber"] = pictures.Length-1;
        RenderCurrentPicture();

    }

    protected void cmdBlack_Click(object sender, ImageClickEventArgs e)
    {
        SetBackground("black");
        RenderCurrentPicture();
    }

    protected void cmdWhite_Click(object sender, ImageClickEventArgs e)
    {
        SetBackground("white");
        RenderCurrentPicture();
    }


    protected void cmdNormalSize_Click(object sender, ImageClickEventArgs e)
    {
        Session["Size"] = "normal";
        RenderCurrentPicture();
    }
    protected void cmdHorizontal_Click(object sender, ImageClickEventArgs e)
    {
        Session["Size"] = "horizontal";
        RenderCurrentPicture();
    }
    protected void cmdVertical_Click(object sender, ImageClickEventArgs e)
    {
        Session["Size"] = "vertical";
        RenderCurrentPicture();
    }
}
