﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class ErrorViewer : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Security.UserCanViewErrorLog(User))
        {
            if (!IsPostBack)
            {
                ErrorList list = ErrorList.GetAll(Logger.LogPath);
                gvErrors.DataSource = list;
                gvErrors.DataBind();
                if (list.Count > 0)
                {
                    gvErrors.SelectedIndex = 0;
                    ViewSelectedErrorLog();
                }
            }
        }
        else
        {
            lblErrorDetails.Text = "User not authorized to view the error log files";
        }
    }

    protected void gvErrors_SelectedIndexChanged(object sender, EventArgs e)
    {
        ViewSelectedErrorLog();
    }

    private void ViewSelectedErrorLog()
    {
        if (Security.UserCanViewErrorLog(User))
        {
            GridViewRow row = gvErrors.SelectedRow;
            if (row != null)
            {
                string logFile = row.Cells[1].Text;
                ErrorList errors = ErrorList.GetAll(Logger.LogPath, logFile);
                //txtErrorDetails.Text = HttpUtility.HtmlEncode(errors[0].Content);
                string errorInfo = HttpUtility.HtmlEncode(errors[0].Content);
                errorInfo = errorInfo.Replace("\r\n", "<br/>");
                errorInfo = errorInfo.Replace("[ERROR]", "<b>[ERROR]</b>");
                errorInfo = errorInfo.Replace("[INFO]", "<b>[INFO]</b>");
                errorInfo = errorInfo.Replace("Message:", "<b>Message:</b>");
                errorInfo = errorInfo.Replace("Friendly info:", "<b>Friendly info:</b>");
                lblErrorDetails.Text = errorInfo;
            }
        }
        else
        {
            lblErrorDetails.Text = "User not authorized to view the error log details";
        }
    }
}
