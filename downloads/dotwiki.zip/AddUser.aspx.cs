﻿using System;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class AddUser : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Security.UserCanAddUser(User))
            {
                throw new Exception("User does not have access to add other users");
            }
        }
        catch (System.Threading.ThreadAbortException)
        {
            // Ignore this exception since this is most likely the result of Redirect.            
        }
        catch (Exception ex)
        {
            Logger.LogError("Add User", ex, Request);
            Response.Redirect(RootObject.HomePage);
        }
    }
}
