﻿using System;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class TopicHistory : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ShowTopicVersions();
        }
    }

    protected void gvHistory_SelectedIndexChanged(object sender, EventArgs e)
    {
        DataKey key = gvHistory.SelectedDataKey;
        if (key != null)
        {
            Guid historypk = (Guid)key.Value;
            ShowTopicHistory(historypk);
        }
    }


    private void ShowTopicVersions()
    {
        try
        {

            bool viewAll = false;
            if (!String.IsNullOrEmpty(Request.QueryString["all"]))
            {
                viewAll = (Request.QueryString["all"].ToString() == "yes");
            }

            string pk = Request.QueryString["pk"];
            if (String.IsNullOrEmpty(pk)) throw new Exception("Invalid parameters in query string");
            Guid topicPK = new Guid(pk);
            Topic topic = Topic.GetTopic(topicPK);

            hyperViewAll.NavigateUrl = String.Format("{0}?pk={1}&all=yes", RootObject.HistoryPage, topicPK);

            TopicHistoryList list = viewAll ? TopicHistoryList.GetAll(topicPK) : TopicHistoryList.GetLatestChanges(topicPK, 30);
            gvHistory.DataSource = list;        
            string[] keys = { "Id" };
            gvHistory.DataKeyNames = keys;
            gvHistory.DataBind();

            litContent.Text = string.Format("Select a version of <b>{0}</b> to review from the list to the right", topic.Name);
            cmdRestore.Visible = false;
            lblPrefix.Visible = false;
            lblPassword.Visible = false;
            txtPassword.Visible = false;

        }
        catch (Exception ex)
        {
            Logger.LogError(Request.Url.ToString(), ex, Request);
            litError.Text = RootObject.HtmlError("Error reading topic history", "",User);
            litError.Visible = true;
            divRestore.Visible = false;
        }
    }

    protected void ShowTopicHistory(Guid historyPK)
    {
        Topic history = Topic.GetHistory(historyPK);
        litContent.Text = history.DisplayContent;
        lblName.Text = history.Name;

        string friendlyTime = string.Empty;
        int hours = (int)(DateTime.Now - history.UpdatedOn).TotalHours;
        if (hours < 24)
        {
            bool sameDay = (DateTime.Now.DayOfYear == history.UpdatedOn.DayOfYear);
            friendlyTime = (sameDay) ? "earlier today" : "yesterday";
        }
        else if (hours < 48)
        {
            int daysApart = DateTime.Now.DayOfYear - history.UpdatedOn.DayOfYear;
            friendlyTime = (daysApart == 1) ? "yesterday" : "2 days ago";
        }
        else
        {
            double days = (DateTime.Now - history.UpdatedOn).TotalDays;
            int wholeDays = (int)days;
            if (days > wholeDays) wholeDays++;
            friendlyTime = string.Format("{0} days ago", wholeDays);
        }

        lblUpdatedOn.Text = Security.FormatUpdatedOn(history.UpdatedByUser, history.UpdatedOn, friendlyTime);

        if (Security.SecureMode == SecureModeEnum.Simple)
        {
            lblPassword.Visible = (RootObject.RestorePassword != string.Empty);
            txtPassword.Visible = (RootObject.RestorePassword != string.Empty);
        }
        else
        {
            lblPassword.Visible = false;
            txtPassword.Visible = false;
            cmdRestore.Visible = Security.UserCanRestore(User);
        }

    }

    protected void cmdRestore_Click(object sender, EventArgs e)
    {
        try
        {

            if (Security.SecureMode == SecureModeEnum.Simple)
            {
                if (RootObject.RestorePassword != string.Empty)
                {
                    if (RootObject.RestorePassword != txtPassword.Text)
                        throw new ArgumentException("Invalid restore password");
                }
            }
            else
            {
                if (!Security.UserCanRestore(User))
                    throw new ArgumentException("User does not have rights to restore topic");
            }

            // Load the topic
            string pk = Request.QueryString["pk"];
            if (String.IsNullOrEmpty(pk)) throw new ArgumentException("Invalid parameters in query string");
            Guid topicPK = new Guid(pk);
            Topic topic = Topic.GetTopic(topicPK);

            // Load the historic version to restore
            DataKey key = gvHistory.SelectedDataKey;
            if (key == null) throw new Exception("No history record selected");
            Guid historyPK = (Guid)key.Value;
            Topic history = Topic.GetHistory(historyPK);

            // Replace current version with history version
            topic.Content = history.Content;
            topic.Save();
            Response.Redirect(RootObject.TopicUrl(topic.Name));
        }
        catch (System.Threading.ThreadAbortException)
        {
            // Ignore this exception since this is most likely the result of Redirect.            
        }
        catch (ArgumentException ex)
        {
            Logger.LogError(Request.Url.ToString(), ex, Request);
            litError.Text = RootObject.HtmlError(ex.Message, lblName.Text,User);
            litError.Visible = true;
        }
        catch (Exception ex)
        {
            Logger.LogError(Request.Url.ToString(), ex, Request);
            litError.Text = RootObject.HtmlError("Error restoring topic to a previous version", "",User);
            litError.Visible = true;
        }
    }
}
