﻿using System;

public partial class Security_SetupSecurity : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Security.IsSecuritySetup)
            {
                divSecurityAlreadySetup.Visible = true;
            }
            else
            {
                Security.SetupSecurity();
                divSecuritySetupOK.Visible = true;
            }
        }
        catch (Exception ex)
        {
            Logger.LogError("Error setting up security", ex);
            litError.Text = "There was an error setting up security";
            litError.Visible = true;
        }
    }
}
