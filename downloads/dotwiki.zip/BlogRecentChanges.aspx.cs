﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.ServiceModel.Syndication;
using System.Web;
using System.Xml;

public partial class BlogRecentChanges : PageBasePlain
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //LoadFeed();
        LoadRssFeed();
    }

    private void LoadRssFeed()
    {
        // Code based on Bipin Joshi's article "Using Syndication Classes To Generate RSS Feeds" 
        // http://www.dotnetbips.com/articles/4826711c-3f25-48ef-94d0-5c40b628c203.aspx
        SyndicationFeed feed = new SyndicationFeed();
        feed.Title = new TextSyndicationContent(ConfigurationManager.AppSettings["BlogTitle"]);
        feed.Copyright = new TextSyndicationContent(ConfigurationManager.AppSettings["BlogCopyright"]);
        feed.Description = new TextSyndicationContent(ConfigurationManager.AppSettings["BlogDescription"]);

        SyndicationLink link = new SyndicationLink();
        link.Title = ConfigurationManager.AppSettings["BlogTitle"];
        link.Uri = new Uri(ConfigurationManager.AppSettings["BlogUrl"]);
        feed.Links.Add(link);

        feed.Items = LoadBlogItems();

        Response.Clear();
        Response.ContentEncoding = System.Text.Encoding.UTF8;
        Response.ContentType = "text/xml";

        XmlWriter rssWriter = XmlWriter.Create(Response.Output);
        Rss20FeedFormatter rssFormatter = new Rss20FeedFormatter(feed);
        rssFormatter.WriteTo(rssWriter);
        rssWriter.Flush();
        rssWriter.Close();

        Response.End();
    }

    private List<SyndicationItem> LoadBlogItems()
    {
        List<SyndicationItem> items = new List<SyndicationItem>();

        TopicList topics = TopicList.GetRecentChanges(GetLatest.Last24Hours);
        foreach (TopicInfo topicInfo in topics)
        {
            Topic topic = Topic.GetTopic(topicInfo.Id);

            SyndicationItem item = new SyndicationItem();
            item.Id = topic.Id.ToString();
            item.Title = new TextSyndicationContent(topic.Name);
            item.Content = new TextSyndicationContent(topic.Content);
            item.LastUpdatedTime = topic.UpdatedOn;
            string url = string.Format(ConfigurationManager.AppSettings["BlogTopicUrl"], HttpUtility.UrlEncode(topic.Name));
            item.AddPermalink(new Uri(url));

            SyndicationPerson author = new SyndicationPerson();
            //author.Name = string.IsNullOrEmpty(topic.UpdatedByUser) ? "guest user" : topic.UpdatedByUser;
            author.Email = string.IsNullOrEmpty(topic.UpdatedByUser) ? "guest user" : topic.UpdatedByUser;
            item.Authors.Add(author);

            items.Add(item);
        }
        return items;
    }

    /* Old code using AdamKinney's library */
    //private void LoadFeed()
    //{
    //    string title = ConfigurationManager.AppSettings["BlogTitle"];
    //    string description = ConfigurationManager.AppSettings["BlogDescription"];
    //    string link = ConfigurationManager.AppSettings["BlogUrl"];
    //    AdamKinney.RSS.RSSFeed feed = new AdamKinney.RSS.RSSFeed(title, link, description);
    //    feed.ImplementsSlash = true;
    //    feed.Language = "en-us";
    //    feed.ManagingEditor = RootObject.AdminEmail;
    //    feed.WebMaster = RootObject.AdminEmail;
    //    feed.TTL = "60";

    //    TopicList topics = TopicList.GetRecentChanges(GetLatest.Last24Hours);
    //    foreach (TopicInfo topicInfo in topics)
    //    {
    //        Topic topic = Topic.GetTopic(topicInfo.Id);
    //        AdamKinney.RSS.RSSItem item = new AdamKinney.RSS.RSSItem(topic.Name, "<![CDATA[ " + topic.DisplayContent + " ]]>");
    //        item.Author = string.IsNullOrEmpty(topic.UpdatedByUser) ? "guest user" : topic.UpdatedByUser;
    //        item.Link = string.Format(ConfigurationManager.AppSettings["BlogTopicUrl"], HttpUtility.UrlEncode(topic.Name));
    //        item.SourceUrl = item.Link;
    //        item.Guid = item.Link;
    //        item.GuidIsPermalink = true;
    //        item.PubDate = topic.UpdatedOn.ToString("yyyy-MM-dd hh:mm");
    //        feed.Items.Add(item);
    //    }

    //    Response.ContentType = "text/xml";
    //    Response.Write(feed.ToString());
    //    Response.End();
    //}
}
