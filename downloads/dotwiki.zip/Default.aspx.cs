﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class _Default : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Trace.Write("PageLoad begins");
        try
        {
            RootObject.TestAccessToDatabase();
            Security.TestSecurity();

            try
            {

                //if (!Security.IsSecuritySetup)
                //{
                //    divSecuritySetup.Visible = true;
                //}

                hyperPrinter.Visible = false; //TODO: implement printer friendly page
                hyperViewHistory.Visible = true;
                hyperPicture.Visible = Security.UserCanAddPicture(User);
                hyperDelete.Visible = Security.UserCanDelete(User);
                cmdEdit.Visible = Security.UserCanEdit(User);

                if (!IsPostBack)
                {
                    string topicName = GetTopicNameInUrl();
                    this.Page.Title = "DotWiki - " + topicName;
                    ViewTopic(topicName);
                }
            }
            catch (Exception ex)
            {
                Trace.Write("PageLoad exception caught");
                Logger.LogError(Request.Url.ToString(), ex, Request);
                litContent.Text = RootObject.HtmlError("Error reading topic", "", User);
            }
        }
        catch (Exception ex)
        {
            Trace.Write("PageLoad exception caught");
            Logger.LogError(Request.Url.ToString(), ex, Request);
            string errorFriendly = "Could not connect to the database. Make sure the " +
                "connection string parameters defined in the web.config are correct " + 
                "and that the SQL user account has access to the database.";
            litContent.Text = RootObject.HtmlError(errorFriendly, "(initializing Default.aspx)", User);
        }
        Trace.Write("PageLoad ends");

    }
        
    private string GetTopicNameInUrl()
    {
        Trace.Write("GetTopicNameInUrl begins");
        string topicName = Request.QueryString["topic"];
        if (String.IsNullOrEmpty(topicName))
        {
            topicName = RootObject.HomeTopic;
        }
        string x = TopicParser.CleanUrlTopicName(topicName);
        Trace.Write("GetTopicNameInUrl ends");
        return x;
    }

    private string EditUrl()
    {
        string url = string.Format("{0}?topic={1}", RootObject.EditPage, GetTopicNameInUrl());
        return url;
    }

    private void ViewTopic(string topicName)
    {
        Trace.Write("ViewTopic begins");
        try
        {
            Topic topic = Topic.GetTopic(topicName);
            if (topic.Id == Guid.Empty)
            {
                lblName.Text = topicName;
                lblUpdatedOn.Text = string.Empty;
                litContent.Text = String.Format("<p>[Click <a href=\"{0}\">here</a> to edit this topic]</p>", EditUrl());
                hyperViewHistory.Visible = false;
                hyperPrinter.Visible = false;
                hyperPicture.Visible = false;
            }
            else
            {
                lblName.Text = topic.Name;
                lblUpdatedOn.Text = Security.FormatUpdatedOn(topic.UpdatedByUser, topic.UpdatedOn);
                litContent.Text = TopicParser.WikiText(topic.Content);
                litContent.Text = litContent.Text.Replace("{TopicName}", topicName);
                hyperPrinter.NavigateUrl = string.Format("{0}?pk={1}", RootObject.PrintPage, topic.Id);
                hyperPicture.NavigateUrl = string.Format("{0}?pk={1}", RootObject.AddPicturePage, topic.Id);
                hyperViewHistory.NavigateUrl = string.Format("{0}?pk={1}", RootObject.HistoryPage, topic.Id);
                hyperDelete.NavigateUrl = string.Format("{0}?pk={1}&delete=true", RootObject.DeletePage, topic.Id);
            }
            Trace.Write("ViewTopic ends");
        }
        catch (Exception ex)
        {
            Logger.LogError(Request.Url.ToString(), ex, Request);
            litContent.Text = RootObject.HtmlError("Error reading topic", topicName,User);
        }

        try
        {
            Topic topic2 = Topic.GetTopic(RootObject.NavigationMenuTopic);
            litRightPanel.Text = TopicParser.WikiText(topic2.Content);
        }
        catch (Exception ex)
        {
            string errorTitle = string.Format("{0} (navigation menu)", Request.Url);
            Logger.LogError(errorTitle, ex, Request);
            litRightPanel.Text = RootObject.HtmlError("Error reading topic", RootObject.NavigationMenuTopic,User); 
        }
    }

    private void EditTopic(string topicName)
    {
        Response.Redirect(EditUrl());
    }

    protected void cmdEdit_Click(object sender, EventArgs e)
    {
        EditTopic(GetTopicNameInUrl());
    }

}
