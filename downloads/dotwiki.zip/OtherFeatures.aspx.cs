﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class Admin : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        /* 
         * You might want to use the visible property instead of 
         * the enabled property in your own wikis. However for the 
         * public version of the DotWiki web site is better if I 
         * let the visitors see that there more options available 
         * to them if they were to configure security properly.
         * For example I want users to see that there is a trash can
         * and an option to add admin users even though they don't 
         * have access to them.
         */
        hyperChangePassword.Enabled = Security.UserCanChangePassword(User);
        hyperAddUser.Enabled = Security.UserCanAddUser(User);
        hyperAddAminUser.Enabled = Security.UserCanAddAdminUser(User);
        hyperErrorViewer.Enabled = Security.UserCanViewErrorLog(User);
        hyperTrashcan.Enabled = Security.UserCanDelete(User);
    }
}
