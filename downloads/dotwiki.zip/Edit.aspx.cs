﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class Edit : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {

            if (!Security.UserCanEdit(User))
            {
                // Somebody landed in this page even though they 
                // don't have access rights to edit topics pictures 
                // (e.g. copying the URL while authenticated and 
                // pasting it when not authenticated...or a hacker)
                FCKeditor.Visible = false;
                lblHints.Visible = false;
                lblHintLink.Visible = false;
                lblHintPicture.Visible = false;
                lblHintSave.Visible = false;

                //TODO: This could also be the result of an authentication
                // session that timed out for a legitimate user. We should 
                // handle this scenario more gracefully - for now just save
                // recovery information.
                string recoveryInfo = string.Format("Topic: {0}\r\n\r\nContent:{1}\r\n", lblName.Text, FCKeditor.Value);
                Logger.LogInfo("Topic Save Recovery Info", recoveryInfo);

                throw new Exception("User does not have access rights to edit this topic");
            }


            if (!IsPostBack)
            {
                string topicName = GetTopicNameInUrl();
                lblName.Text = topicName;

                Topic topic = Topic.GetTopic(topicName);
                FCKeditor.BaseHref = RootObject.FCKeditor_BaseHref;

                if (Security.UserCanAddPicture(User))
                {
                    lblHintPicture.Visible = true;
                    FCKeditor.ToolbarSet = "CustomFCKToolbar";
                }
                else
                {
                    lblHintPicture.Visible = false;
                    FCKeditor.ToolbarSet = "CustomFCKToolbarNoPicture";
                }

                if (topic.Id == Guid.Empty)
                {
                    FCKeditor.Value = "[Enter content here]";
                }
                else
                {
                    FCKeditor.Value = topic.Content;
                }
                Session["TopicPK"] = topic.Id;

            }

        }
        catch (Exception ex)
        {
            Logger.LogError(Request.Url.ToString(), ex, Request);
            litError.Text = RootObject.HtmlError("Error editing topic", "",User);
            litError.Visible = true;
            FCKeditor.Visible = false;
            cmdCancel.Visible = false;
            cmdSave.Visible = false;
        }
         
    }

    protected void cmdSave_Click(object sender, EventArgs e)
    {
        SaveTopic();
    }

    protected void cmdCancel_Click(object sender, EventArgs e)
    {
        GoBackToViewMode();
    }

    private string GetTopicNameInUrl()
    {
        string topicName = Request.QueryString["topic"];
        if (String.IsNullOrEmpty(topicName))
        {
            topicName = RootObject.HomeTopic;
        }
        return TopicParser.CleanUrlTopicName(topicName);
    }

    private void SaveTopic()
    {
        try
        {
            if (Session.IsNewSession)
            {
                string errorMsg = string.Format(
                    "Could not save changes to \"{0}\" because your session timed out. " +
                    "Next time please remember to save your changes at least every {1} minutes.",
                    lblName.Text, Session.Timeout);
                litError.Text = RootObject.HtmlError(errorMsg, lblName.Text,User);
                litError.Visible = true;
                FCKeditor.Visible = false;
                cmdCancel.Visible = false;
                cmdSave.Visible = false;

            }
            else
            {
                if (!Security.UserCanEdit(User))
                    throw new Exception("User does not have access rights to edit this topic");
                
                Topic topic;
                Guid topicPK = (Guid)Session["TopicPK"];
                if (topicPK == Guid.Empty)
                {
                    topic = Topic.NewTopic();
                    topic.Name = lblName.Text;
                }
                else
                {
                    topic = Topic.GetTopic(topicPK);
                }
                topic.Content = FCKeditor.Value;
                topic.UpdatedByUser = User.Identity.Name;
                topic.Save();
                GoBackToViewMode();
            }
        }
        catch (System.Threading.ThreadAbortException)
        {
            // Ignore this exception since this is most likely the result of Redirect.            
        }
        catch (Exception ex)
        {
            Logger.LogError(Request.Url.ToString(), ex, Request);
            litError.Text = RootObject.HtmlError("Error saving topic", lblName.Text,User);
            litError.Visible = true;
            FCKeditor.Visible = false;
            cmdCancel.Visible = false;
            cmdSave.Visible = false;
        }
    }

    private void GoBackToViewMode()
    {
        //string url = string.Format("~/{0}?topic={1}", RootObject.HomePage, GetTopicNameInUrl());
        Response.Redirect(RootObject.TopicUrl(GetTopicNameInUrl()));
    }
}
