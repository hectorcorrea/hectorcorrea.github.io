﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;


public partial class Index : PageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            TopicList list;
            string strLetter = Request.QueryString["letter"];
            if (string.IsNullOrEmpty(strLetter))
            {
                list = TopicList.GetAll();
                gvTopics.EmptyDataText = "There are no topics to display.";
            }
            else
            {
                char letter = strLetter.ToUpper()[0];
                if (letter >= 'A' && letter <= 'Z')
                {
                    list = TopicList.GetIndex(letter);
                    gvTopics.EmptyDataText = string.Format("There are no topics to display that start with {0}.", letter);
                }
                else
                {
                    list = TopicList.GetAll();
                    gvTopics.EmptyDataText = "There are no topics to display.";
                }
            }
            gvTopics.DataSource = list;
            gvTopics.DataBind();
        }
        catch(Exception ex)
        {
            Logger.LogError(Request.Url.ToString(), ex, Request);
            litError.Text = RootObject.HtmlError("Could not retrieve list of topics", "(Index page)",User);
            litError.Visible = true;

        }
    }
}
